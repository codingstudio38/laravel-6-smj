@extends('Frontend.employee-report-header')
@extends('Frontend.employee-report-footer')
<body>

        <!--  BEGIN CONTENT AREA  -->
        <div  class="main-content">
                <div class="">
                    <div class="row layout-top-spacing">
                        <div id="tableCaption" class="col-lg-12 col-12 layout-spacing">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12 text-center">
                                            <h5 class="data-heading1">The Samaj<span>Report run on: November 23, 2020 2:14 PM</span></h5>
                                            <h3 class="data-heading">EMPLOYEES LIST(Department  Wise)</h3>
                                        </div>

                                         <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12" >
                                                  
                                                    <form method="get" action="/" class="form-inline report-area">
                                                        <label>Category:</label>
                                                   <select class="col-lg-2 form-control">
                                                      <option>All Category</option>
                                                      <option>All Category</option>
                                                      <option>All Category</option>
                                                   </select>&nbsp;&nbsp;&nbsp;
                                                    <label>Employee Type:</label>
                                                    <select class="col-lg-2 form-control">
                                                      <option>All </option>
                                                      <option>Permanent </option>
                                                      <option>Probation </option>
                                                      
                                                    </select>
                                                    &nbsp;&nbsp;&nbsp;
                                                    <label>Dept. Name:</label>
                                                    <select class="col-lg-3 form-control">
                                                      <option>All Department</option>
                                                      <option>Account </option>
                                                      <option>Administration </option>
                                                    </select>
                                                      &nbsp;&nbsp;
                                                    <button type="submit" class="btn btn-primary report-btn" value="">Search</button>
                                                    </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area"  style="padding-bottom: 0px;">
                                    <h5 style="float: left;">Dept. Name: ACCOUNTS</h5>
                                    <!-- <button class="btn btn-secondary tb-btn" onclick="window.pdf()"><i class="fa fa-file"></i> Save</button>
                                    <button class="btn btn-primary tb-btn" onclick="window.print()" ><i class="fa fa-print" ></i> Print</button> -->
                                    
                                    <div class="table-responsive" style="margin-top: 5px;">
                                        <table class="table mb-4">
                                          <thead>
                                                <tr>
                                                    <th class="text-center">Emp Code</th>
                                                    <th class="">Employee Name</th>
                                                    <th>Designation</th>
                                                    <th>Category</th>
                                                    <th>Emp. Type</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center">035</td>
                                                    <td class="text-primary">SUSHANT KUMAR MOHANTY</td>
                                                    <td>Manager</td>
                                                    <td class="">NON. JOR(A)</td>
                                                    <td>Permanent</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">035</td>
                                                    <td class="text-primary">BIBEKNANDA DAS</td>
                                                    <td>Jr. Assistant</td>
                                                    <td class="">NON. JOR(A)</td>
                                                    <td>Permanent</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">035</td>
                                                    <td class="text-primary">PABITRA MOHAN SAHOO</td>
                                                    <td>Jr. Assistant</td>
                                                    <td class="">NON. JOR(A)</td>
                                                    <td>Permanent</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">035</td>
                                                    <td class="text-primary">KISHORE CHANDRA SATHAPATHY</td>
                                                    <td>Manager</td>
                                                    <td class="">NON. JOR(A)</td>
                                                    <td>Permanent</td>
                                                </tr>
                                            </tbody>
                                        </table>
                              
                                    </div>


                                </div>
                                 <div class="widget-header" id="pg-sec">
                                    <div class="row">
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                            <a href="#">Page 1 of 17</a>
                                        </div>
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                            <div class="pagination">
                                              <a href="#">&laquo;</a>
                                              <a href="#">1</a>
                                              <a href="#" class="active">2</a>
                                              <a href="#">3</a>
                                              <a href="#">4</a>
                                              <a href="#">5</a>
                                              <a href="#">6</a>
                                              <a href="#">&raquo;</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="widget-content widget-content-area"  style="padding-bottom: 0px;">
                                    <h5 style="float: left;">Dept. Name: ADMINISTRATION</h5>
                                    <!-- <button class="btn btn-secondary tb-btn" onclick="window.pdf()"><i class="fa fa-file"></i> Save</button>
                                    <button class="btn btn-primary tb-btn" onclick="window.print()" ><i class="fa fa-print" ></i> Print</button> -->
                                    
                                    <div class="table-responsive" style="margin-top: 5px;">
                                        <table class="table mb-4">
                                          <thead>
                                                <tr>
                                                    <th class="text-center">Emp Code</th>
                                                    <th class="">Employee Name</th>
                                                    <th>Designation</th>
                                                    <th>Category</th>
                                                    <th>Emp. Type</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center">036</td>
                                                    <td class="text-primary">MALAY KUMAR DEY</td>
                                                    <td>O.S</td>
                                                    <td class="">NON. JOR(A)</td>
                                                    <td>Contract</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">035</td>
                                                    <td class="text-primary">BIBEKNANDA DAS</td>
                                                    <td>Jr. Assistant</td>
                                                    <td class="">NON. JOR(A)</td>
                                                    <td>Permanent</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">035</td>
                                                    <td class="text-primary">PABITRA MOHAN SAHOO</td>
                                                    <td>Jr. Assistant</td>
                                                    <td class="">NON. JOR(A)</td>
                                                    <td>Permanent</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">035</td>
                                                    <td class="text-primary">KISHORE CHANDRA SATHAPATHY</td>
                                                    <td>Manager</td>
                                                    <td class="">NON. JOR(A)</td>
                                                    <td>Permanent</td>
                                                </tr>
                                            </tbody>
                                        </table>
                              
                                    </div>


                                </div>
                                 <div class="widget-header" id="pg-sec">
                                    <div class="row">
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                            <a href="#">Page 1 of 17</a>
                                        </div>
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                            <div class="pagination">
                                              <a href="#">&laquo;</a>
                                              <a href="#">1</a>
                                              <a href="#" class="active">2</a>
                                              <a href="#">3</a>
                                              <a href="#">4</a>
                                              <a href="#">5</a>
                                              <a href="#">6</a>
                                              <a href="#">&raquo;</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

        </div>
      