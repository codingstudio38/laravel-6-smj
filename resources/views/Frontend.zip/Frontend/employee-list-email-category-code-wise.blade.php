@extends('Frontend.employee-report-header')
@extends('Frontend.employee-report-footer')
<body>



        <!--  BEGIN CONTENT AREA  -->
        <div  class="main-content">
                <div class="">
                    <div class="row layout-top-spacing">
                        <div id="tableCaption" class="col-lg-12 col-12 layout-spacing">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                    	<div class="col-xl-12 col-md-12 col-sm-12 col-12 text-center">
                                    		<h5 class="data-heading1">The Samaj<span>Report run on: November 23, 2020 2:14 PM</span></h5>
                                            <h3 class="data-heading">EMPLOYEES LIST(Category/Emp Code-Wise)</h3>
                                        </div>
                                         <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                        
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12" >
                                                  
                                                    <form method="get" action="/" class="form-inline report-area">
                                                        <label>Employee Type:</label>
                                                    <select class="col-lg-1 form-control">
                                                      <option>All </option>
                                                      <option>Permanent </option>
                                                      <option>Probation </option>
                                                      
                                                    </select>
                                                    &nbsp;&nbsp;&nbsp;
                                                    	<label>Emp Code Exist(Yes/No/All):</label>
									               <select class="col-lg-2 form-control">
									               	  <option>All</option>
									               	  <option>No </option>
									               	  <option>Yes</option>
									               </select>&nbsp;&nbsp;&nbsp;
									                
                                                    
                                                    <label>Email Id Exist(Yes/No/All):</label>
                                                    <select class="col-lg-1 form-control">
                                                      <option>All</option>
                                                      <option>Yes </option>
                                                      <option>No </option>
                                                    </select>
									               	  &nbsp;&nbsp;
									                <button type="submit" class="btn btn-primary report-btn" value="">Search</button>
									                </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area"  style="padding-bottom: 0px;">
                                 <!--    <button class="btn btn-secondary tb-btn"><i class="fa fa-file"></i> Save</button>
                                	<button class="btn btn-primary tb-btn" onclick="window.print()" ><i class="fa fa-print" ></i> Print</button> -->
                                	
                                    <div class="table-responsive" style="margin-top: 5px;">
                                        <table class="table mb-4">
                                          <thead>
                                                <tr>
                                                    <th class="text-center">No</th>
                                                    <th class="">Code</th>
                                                    <th>Employee Name</th>
                                                    <th>Designation</th>
                                                    <th>Department</th>
                                                    <th>Contact No</th>
                                                    <th>E-mail</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center">020</td>
                                                    <td class="text-primary">026</td>
                                                    <td>PRADEEP KUMAR BEHERA</td>
                                                    <td class="">Manager Systems</td>
                                                    <td>IT</td>
                                                    <td>9438410947</td>
                                                    <td>sysm@samaja.in</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">246</td>
                                                    <td class="text-primary">027</td>
                                                    <td>AJAYA KUMAR PATTANAIK</td>
                                                    <td class="">Software Engineer</td>
                                                    <td>IT</td>
                                                    <td>9438410947</td>
                                                    <td>ajay.pattnaik@thesamaj.com</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">335</td>
                                                    <td class="text-primary">028</td>
                                                    <td>PRIYABRATA MOHANTY</td>
                                                    <td class="">Working General MGR.</td>
                                                    <td>G.M Office</td>
                                                    <td>9437013785</td>
                                                    <td>gm@samaja.in</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">366</td>
                                                    <td class="text-primary">030</td>
                                                    <td>SAMARENDU DAS</td>
                                                    <td class="">Chief Of News Bureau</td>
                                                    <td>Bubaneswar Office</td>
                                                    <td>9437023120</td>
                                                    <td>cnbbsr@samaja.in</td>
                                                </tr>
                                            </tbody>
                                        </table>
                              
                                    </div>


                                </div>
                                 <div class="widget-header" id="pg-sec">
                                    <div class="row">
                                    	<div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<a href="#">Page 1 of 17</a>
                                        </div>
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<div class="pagination">
											  <a href="#">&laquo;</a>
											  <a href="#">1</a>
											  <a href="#" class="active">2</a>
											  <a href="#">3</a>
											  <a href="#">4</a>
											  <a href="#">5</a>
											  <a href="#">6</a>
											  <a href="#">&raquo;</a>
											</div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>

        </div>
