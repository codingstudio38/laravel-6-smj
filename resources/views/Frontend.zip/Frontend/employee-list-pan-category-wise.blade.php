@extends('Frontend.employee-report-header')
@extends('Frontend.employee-report-footer')
<body>
 <!--  BEGIN CONTENT AREA  -->
        <div  class="main-content">
                <div class="">
                    <div class="row layout-top-spacing">
                        <div id="tableCaption" class="col-lg-12 col-12 layout-spacing">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12 text-center">
                                            <h5 class="data-heading1">The Samaj<span>Report run on: November 23, 2020 2:14 PM</span></h5>
                                            <h3 class="data-heading">EMPLOYEES LIST(PAN/ Category Wise)</h3>
                                        </div>

                                           <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12" >
                                                  
                                                    <form method="get" action="/" class="form-inline report-area">

                                                        <label>Employee Type:</label>
                                                    <select class="col-lg-4 form-control">
                                                      <option>All </option>
                                                      <option>Permanent </option>
                                                      <option>Probation </option>
                                                    </select>
                                                      &nbsp;&nbsp;
                                                        <label>PAN Exist(Yes/No/All):</label>
                                                   <select class="col-lg-3 form-control">
                                                      <option>All</option>
                                                      <option>Yes</option>
                                                      <option>No</option>
                                                   </select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    
                                                    <button type="submit" class="btn btn-primary report-btn" value="">Search</button>
                                                    </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area"  style="padding-bottom: 0px;">
                                    <!-- <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                    <button class="btn btn-secondary" onclick="window.pdf()"><i class="fa fa-file"></i> Save</button> -->
                                    <div class="table-responsive" style="margin-top: 5px;">
                                        <table class="table mb-4">
                                          <thead>
                                                <tr>
                                                    <th class="text-center">Code</th>
                                                    <th>Category</th>
                                                    <th class="">Employee Name</th>
                                                    <th>Designation</th>
                                                    <th>Department</th>
                                                    <th>DOB</th>
                                                    <th>Joining Date</th>
                                                    <th>PAN</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center">014</td>
                                                    <td class="text-primary">Working Journalist</td>
                                                    <td>MANAS RANJAN SWAIN</td>
                                                    <td class="">Sub-Editor</td>
                                                    <td class="">Editorial</td>
                                                    <td>20/05/1669</td>
                                                    <td>02/01/2006</td>
                                                    <td>GEOPS52666</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">227</td>
                                                    <td class="text-primary">Working Journalist</td>
                                                    <td>SUDARSAN NAYAK</td>
                                                    <td class="">Sub-Editor</td>
                                                    <td class="">Berhampur Office</td>
                                                    <td>09/08/1968</td>
                                                    <td>05/03/2008</td>
                                                    <td>GEOPS52666</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">237</td>
                                                    <td class="text-primary">Working Journalist</td>
                                                    <td>BHABANI SANKAR MAHAPATRA</td>
                                                    <td class="">Reporter</td>
                                                    <td class="">Berhampur Office</td>
                                                    <td>01/05/1663</td>
                                                    <td>05/03/2008</td>
                                                    <td>GEOPS52666</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">241</td>
                                                    <td class="text-primary">Working Journalist</td>
                                                    <td>DEBEN KUMAR PATEL</td>
                                                    <td class="">Sub-Editor</td>
                                                    <td class="">Sambalpur Office</td>
                                                    <td>20/07/1978</td>
                                                    <td>10/03/2008</td>
                                                    <td>GEOPS52666</td>
                                                </tr>
                                            </tbody>
                                        </table>
                              
                                    </div>


                                </div>
                                 <div class="widget-header" style="padding: 20px;">
                                    <div class="row">
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                            <a href="#">Page 1 of 17</a>
                                        </div>
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                            <div class="pagination">
                                              <a href="#">&laquo;</a>
                                              <a href="#">1</a>
                                              <a href="#" class="active">2</a>
                                              <a href="#">3</a>
                                              <a href="#">4</a>
                                              <a href="#">5</a>
                                              <a href="#">6</a>
                                              <a href="#">&raquo;</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

        </div>
        <!--  END CONTENT AREA  -->

       