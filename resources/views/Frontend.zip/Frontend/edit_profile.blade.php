@extends('Frontend.footer')

@extends('Frontend.inner_master')

@section('content')

 

<style type="text/css">
    #bank
{
    font-size: 13px;
    color: black;
}
#wrong-egn{
  display: none;
  font-size: 12px;
  color: red;
}
#wrong-egn3{
  display: none;
  font-size: 12px;
  color: red;
}
#wrong-egn2{
  display: none;
  font-size: 12px;
  color: red;
}
#wrong-egn1{
  display: none;
  font-size: 12px;
  color: red;
}
.employeemaster{
    color: #f70c0c;
}
</style>

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" integrity="sha512-nMNlpuaDPrqlEls3IX/Q56H36qvBASwb3ipuo3MxeWbsQB1881ox0cRv7UPTgBlriqoynt35KjEwgGUeUXIPnw==" crossorigin="anonymous" />

        <!--  BEGIN CONTENT AREA  -->
<div id="content" class="main-content">
<div class="layout-px-spacing">                

<div class="account-settings-container layout-top-spacing">

<div class="account-content">
<div class="scrollspy-example" data-spy="scroll" data-target="#account-settings-scroll" data-offset="-100">
<div class="row">
<div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
  
<form id="general-info" class="section general-info"
 action="{{url('/')}}/updateEmployeeDetails" method="post" enctype="multipart/form-data" novalidate>
 @if( Auth::user()->role == "Administrator"||Auth::user()->role == "HR Manager"||Auth::user()->role == "Finance Staff") 
<div class="form-group" style="text-align: right;color: white;">
                          <button type="submit" class="btn btn button1"
                           style="background-color: #1b55e2;">
                         Save</button>
                        </div> 
                        @endif
 <input type="hidden" class="form-control mb-4"  name="emp_id"value="{{ $EmployeeAllInfo->id }}">  

{!! csrf_field() !!}  

    <div class="info">

    <h6 class="">EMPLOYEE MASTER</h6>

    <div class="row">
    <div class="col-lg-11 mx-auto">
        <div class="row">
             <div class="col-xl-2 col-lg-12 col-md-4">
                <div class="upload mt-4 pr-md-4">
                   </div>
                @if($EmployeeAllInfo->image!="")
                   
                   
                   <input type="file" id="input-file-max-fs" class="dropify" data-default-file="{{ url('public/image/'.$EmployeeAllInfo->image) }}" data-max-file-size="2M" name="image" / >
                      <input type="hidden" name="old_empImage" value="{{$EmployeeAllInfo->image}}">
                            @else
                            
                            <div class="upload mt-4" >
                          <input type="file" id="input-file-max-fs" class="dropify" data-default-file="{{url('/')}}/public/assets/img/download.jpg" data-max-file-size="2M"  name="image"/ >
                      </div>
                       @endif
            </div>


            <div class="col-xl-10 col-lg-10 col-md-10 mt-md-0 mt-4">
            
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Employee no<span class="employeemaster">*</span></label>
                                <input type="text" class="form-control mb-4"  name="emp_no"value="{{ $EmployeeAllInfo->emp_no }}"readonly="readonly">

                            </div>
                        </div>
                       <div class="col-sm-2">
                            <div class="form-group">
                                <label for="fullName">Employee List</label>
                               <button type="button" class="btn btn-primary mb-2" data-toggle="modal" data-target=".bd-example-modal-xl">List</button>

                            </div>
                        </div>
                        <div class="col-sm-6 ">
                            <label class="dob-input">Active Type<span class="employeemaster">*</span></label>
                      
                                <div class="form-group mr-1">
                                    <select class="form-control" id="exampleFormControlSelect1" name="type" onchange="showfield(this.value)" 
                                    value ="{{$EmployeeAllInfo->active_type }}">
                                      <option <?php if($EmployeeAllInfo->active_type == 'active'){ echo "selected"; } else { echo ""; } ?> value="active">active</option>
                                       <option <?php if($EmployeeAllInfo->active_type == 'inactive'){ echo "selected"; } else { echo ""; } ?> value="inactive">inactive</option>
                                    </select>
                                    <div id="div1"></div>
                                  </div>

                                  @if($EmployeeAllInfo->active_type == 'inactive')
                                    <div class="form-group mt-2">
                                     <div class="row">
                                       <div class="col-6 r_class ">
                                          <select class="form-control" name="inactive_reason" id="reason" >
                                            <option>select</option>
                                            <option <?php if($EmployeeAllInfo->inactive_reason == 'Superannuation'){ echo "selected"; } else { echo ""; } ?> value="Superannuation">Superannuation</option>
                                            <option <?php if($EmployeeAllInfo->inactive_reason == 'Resignation'){ echo "selected"; } else { echo ""; } ?> value="Resignation">Resignation</option>
                                            <option <?php if($EmployeeAllInfo->inactive_reason == 'Termination'){ echo "selected"; } else { echo ""; } ?> value="Termination">Termination</option>
                                            <option <?php if($EmployeeAllInfo->inactive_reason == 'Death'){ echo "selected"; } else { echo ""; } ?> value="Death">Death</option>
                                            <option <?php if($EmployeeAllInfo->inactive_reason == 'Illness'){ echo "selected"; } else { echo ""; } ?> value="Illness">Illness</option>
                                            <option <?php if($EmployeeAllInfo->inactive_reason == 'Others'){ echo "selected"; } else { echo ""; } ?> value="Others">Others</option>
                                            
                                          </select>
                                       </div>
                                       <div class="col-6 r_class" >
                                          <input type="date" class="form-control mb-4"  
                                          name="inactive_date" 
                                          value="{{ $EmployeeAllInfo->inactive_date }}" id="r_dob">
                                       </div>
                                       <div class="col-12 r_class">
                                     
                                         <textarea  class="form-control mb-4" id="r_txtReason" name="reason_desc" rows="2" cols="" placeholder="describe your reason">{{$EmployeeAllInfo->reason_desc }}</textarea>
                                       </div>
                                     </div>
                                  </div>
                                  @elseif($EmployeeAllInfo->active_type == 'active')
                                   <div class="form-group mt-2">
                                     <div class="row">
                                       <div class="col-6 r_class " style="display: none">
                                          <select class="form-control" name="inactive_reason" id="reason" >
                                            <option>Select</option>
                                            <option value="Superannuation">Superannuation</option>
                                            <option value= "Resignation">Resignation</option>
                                            <option value= "Termination">Termination</option>
                                            <option value= "Death">Death</option>
                                            <option value= "Illness">Illness</option>
                                            <option value= "Others">Others</option>
                                            
                                          </select>
                                       </div>
                                       <div class="col-6 r_class"  style="display: none">
                                          <input type="date" class="form-control mb-4"  
                                          name="inactive_date" value="" id="r_dob" required>
                                       </div>
                                       <div class="col-12 r_class" style="display: none">
                                         <textarea  class="form-control mb-4" id="r_txtReason" name="reason_desc" rows="2" cols=""placeholder="describe your reason"></textarea required>
                                       </div>
                                     </div>
                                  </div>
                                  
                                  @endif

                           </div>


                         <div class="col-sm-6">
                            <div class="form-group">
                                <label for="fullName">Employee Name<span class="employeemaster">*</span></label>
                                <input type="text" class="form-control mb-4" name="emp_name"  value="{{ $EmployeeAllInfo->emp_name }}" required>

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="fullName">Employee Code<span class="employeemaster">*</span></label>
                                <input type="text" class="form-control mb-4" name="emp_code"   value="{{ $EmployeeAllInfo->employee_code }}" required>

                            </div>
                        </div>


                         <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Department<span class="employeemaster">*</span></label>
                             <select class="form-control" name="department" id="selectdepartment" required>  <option>Select</option>
                                           @foreach($Department_fetch as $ky=>$val)
                                                <option value="{{$val->id}}"
                                                    {{$val->dept_no==$EmployeeAllInfo->dept_no 
                                                        ? 'selected':''}}>{{$val->dept_name}}
                                                </option>      

                                           @endforeach
                                      </select>
                            </div>
                        </div>


                         <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Employeement Type<span class="employeemaster">*</span></label>
                                <select class="form-control mb-4" id="exampleFormControlSelect1" name="emp_type" required>
                                    <option>Select</option>
                                 @foreach($Employee_type_fetch as $ky=>$val)
                                              <option value="{{$val->id}}"{{$val->id==$EmployeeAllInfo->emp_type 
                                                        ? 'selected':''}}>{{$val->employee_type_name}}</option>
                                           @endforeach
                         
                                    </select>

                            </div>
                        </div>

                          <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Designation<span class="employeemaster">*</span></label>
                                <select class="form-control mb-4" id="selectdesignation" name="designation" required>
                                    <option>Select</option>
                                         @foreach($Designation as $ky=>$val)
                                              <option value="{{$val->id}}"{{$val->desg_code==$EmployeeAllInfo->desg_code 
                                                        ? 'selected':''}}>{{$val->desg_name}}</option>
                                           @endforeach
                                    </select>

                            </div>
                        </div>



                         <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Category<span class="employeemaster">*</span></label>
                                <select class="form-control mb-4" id="exampleFormControlSelect1" name="category" required>
                                    <option>Select</option>
                                @foreach($Category_fetch as $ky=>$val)
                                    <option value="{{$val->id}}"{{$val->id==$EmployeeAllInfo->catg ? 'selected':''}}>{{$val->category_name}}
                                    </option>
                                       @endforeach
                                    </select>

                            </div>
                        </div>
                            <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Workplace<span class="employeemaster">*</span></label>
                                <select class="form-control mb-4" id="selectWorkplace" name="workplace" required>
                                    <option>Select</option>
                                        @foreach($Workplace_fetch as $ky=>$val)
                                              <option value="{{$val->id}}"{{$val->id==$EmployeeAllInfo->work_place ? 'selected':''}}>{{$val->workplace_name}}
                                              </option>
                                           @endforeach
                         
                                    </select>


                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Date Of Birth<span class="employeemaster">*</span></label>
                                <input type="date" class="form-control mb-4"  name="DOB" value="{{ $EmployeeAllInfo->DOB }}">

                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="fullName">Date Of Joining<span class="employeemaster">*</span></label>
                                <input type="date" class="form-control mb-4" name="DOJ"  value="{{ $EmployeeAllInfo->DOJ }}">

                            </div>
                        </div>
                           <div class="col-sm-3">
                            <div class="form-group">
                                <label for="fullName">Date Of Probation<span class="employeemaster">*</span></label>
                                <input type="date" class="form-control mb-4" name="DOP"  value="{{ $EmployeeAllInfo->DOP }}">

                            </div>
                        </div>
                            <div class="col-sm-3">
                            <div class="form-group">
                                <label for="fullName">Date of Confirmation</label>
                                <input type="date" class="form-control mb-4" name="DOC"  value="{{ $EmployeeAllInfo->DOC }}">
                          </div>
                                </div>
                    <div class="col-sm-3">
                            <div class="form-group">
                                <label for="fullName">Retirement Date</label>
                                <input type="date" class="form-control mb-4" name="retirement_date"  value="{{ $EmployeeAllInfo->retirement_date }}">
                          </div>
                                </div>
                              
                               </div>
                            </div>
                        </div>
                    </div>
                </div>
             </div>


                                <div class="statbox widget box box-shadow">
                                  <div class="widget-content widget-content-area border-tab">
                                    
                                    <ul class="nav nav-tabs" id="border-tabs" role="tablist">
                                  @if( Auth::user()->role == "Administrator"||Auth::user()->role == "HR Manager"||Auth::user()->role == "Finance Staff") 
                                        <li class="nav-item">
                                            <a class="nav-link active" id="border-home-tab" data-toggle="tab" href="#tab1" role="tab" aria-controls="border-home" aria-selected="true"> OFFICIAL DETAILS</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="border-profile-tab" data-toggle="tab" href="#tab2" role="tab" aria-controls="border-profile" aria-selected="false"> PERSONNEL DETAILS</a>
                                        </li>
                                        @else
                                        <li class="nav-item">
                                            <a class="nav-link active" id="border-profile-tab" data-toggle="tab" href="#tab2" role="tab" aria-controls="border-profile" aria-selected="false"> PERSONNEL DETAILS</a>
                                        </li>
                                         @endif
                                    
                                        
                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab3" role="tab" aria-controls="border-contact" aria-selected="false"> DEPENDENT</a>
                                        </li>
                                                           <!--    <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab4" role="tab" aria-controls="border-contact" aria-selected="false"> NOMINEE</a>
                                        </li> -->
                                                             <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab4" role="tab" aria-controls="border-contact" aria-selected="false"> QUALIFICATION</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab5" role="tab" aria-controls="border-contact" aria-selected="false">EXPERIENCE</a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab6" role="tab" aria-controls="border-contact" aria-selected="false"> TRANSFER</a>
                                        </li>
                                        <?php if( Auth::user()->role == "Administrator"||Auth::user()->role == "HR Manager"||Auth::user()->role == "Finance Staff") {?>
                                         <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab7" role="tab" aria-controls="border-contact" aria-selected="false"> PROMOTION</a>
                                        </li>
            
                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab8" role="tab" aria-controls="border-contact" aria-selected="false"> PROBATION</a>
                                        </li>
                                         <?php 
                                              }   
                                          ?>

                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab9" role="tab" aria-controls="border-contact" aria-selected="false"> CONTRACT</a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab10" role="tab" aria-controls="border-contact" aria-selected="false"> ANTECEDENT</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab11" role="tab" aria-controls="border-contact" aria-selected="false"> REVOCATION</a>
                                        </li>
                                         <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab12" role="tab" aria-controls="border-contact" aria-selected="false">APPRECIATION</a>
                                        </li>
                                         <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab13" role="tab" aria-controls="border-contact" aria-selected="false"> REWARD </a>
                                        </li>
                                         <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab14" role="tab" aria-controls="border-contact" aria-selected="false"> INITIATION</a>
                                        </li>
                                         <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab15" role="tab" aria-controls="border-contact" aria-selected="false"> ACHIEVEMENT</a>
                                        </li>
                                    </ul>
                <div class="tab-content mb-4 p-sec" id="border-tabsContent">

                @if( Auth::user()->role == "Administrator"||Auth::user()->role == "HR Manager"||Auth::user()->role == "Finance Staff") 
 <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="border-home-tab">

    <div class="col-lg-12 emp-sec">
      <div class="row">
        <div class="col-sm-12">
            <h4 class="mb-4">Pay Scale Details</h4>
         </div>
      

                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label for="fullName"> Grade</label>
                                        <select class="form-control"   id="packageid" name="grade_code_arr">

                                            <option value="">--Select--</option>

                                            @foreach($pay_grade_view as $ky=>$val)
                                              <option value="{{$val->id}}"{{$val->id==$EmployeeAllInfo->grade_code ? 'selected':''}}>{{$val->pay_grade_desc}}
                                              </option>
                                           @endforeach
                                           

                                      </select>
                                     
                                </div>
                            </div>

                        <div class="col-sm-2">
                                <div class="form-group">

                                    <label for="fullName" >Pay Grade</label>
                                    <input type="text" class="form-control mb-4"   value="{{$EmployeeOfficialInfo->pay_grade}}" name ="pay_grade" id='catch_value' style="font-size: 13px;" readonly="readonly">

                                </div>
                            </div>
                             <div class="col-sm-2">
                                <div class="form-group">

                                    <label for="fullName">PF A/C No</label>
                                    <input type="text" class="form-control mb-4"   value="{{$EmployeeAllInfo->pf_ac_no}}" name="pf">

                                </div>
                            </div>

                        <div class="col-sm-2">
                                <div class="form-group">

                                    <label for="fullName">VPF %</label>
                                    <input type="text" class="form-control mb-4"   value="{{$EmployeeAllInfo->vpf_perc}}" name ="vpf">

                                </div>
                            </div>


                        <div class="col-sm-2">
                                <div class="form-group">

                                    <label for="fullName">ESI A/C No</label>
                                    <input type="text" class="form-control mb-4"   value="{{$EmployeeAllInfo->esi_ac_no}}" name ="esi">

                                </div>
                            </div>

                        <div class="col-sm-2">
                                <div class="form-group">

                                    <label for="fullName">PAN No</label>
                                    <input type="text" class="form-control mb-4"   value="{{$EmployeeAllInfo->pan_no}}" name="PAN">

                                </div>
                            </div>


                        <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">UAN</label>
                                    <input type="text" class="form-control mb-4"   value="{{$EmployeeAllInfo->UAN}}" name="uan">

                                </div>
                            </div>

                             <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">Aadhaar No</label>
                                    <input type="number" maxlength="" name="adhar"  placeholder="Adhara number" id="input-payment-egn3" class="form-control" 
                                    value="{{$EmployeeAllInfo->adhara_no}}"/>
                                   <div id="wrong-egn3">Please provide 12 digit  adhara number.</div>
                             

                                </div>
                            </div>
                       
                               <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">Initial Special Allowance</label>
                                     <input type="number" id="initial_allowance" class="form-control mb-4"   name ="intial" readonly="readonly" value="{{$EmployeeOfficialInfo->intial_special}}"  readonly="readonly">
                                    

                                </div>
                            </div>
                              <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">Current  Special Allowance</label>
                                    <input type="number" class="form-control mb-4"   value="{{$EmployeeOfficialInfo->current_special}}" name="current" id="current_allowance"  readonly="readonly" >

                                </div>
                            </div>
                              <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">Initial Other Special Allowance</label>
                                    <input type="number" class="form-control mb-4"   value="{{$EmployeeOfficialInfo->intial_other_special}}" name ="initial_other" id="initial_other"  readonly="readonly">

                                </div>
                            </div>
                              <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">Current Other Special  Allowance</label>
                                    <input type="number" class="form-control mb-4"   value="{{$EmployeeOfficialInfo->current_other_special}}" name="current_other" id="cuurent_other"  readonly="readonly">

                                </div>
                            </div>
                            
                           
                              <div class="col-sm-2">
                                <div class="form-group">
                               <label for="fullName">PF Deduction</label><br>
                                     <label class="radio-inline">
                                          <input type="radio" name="optradio" value="yes" 
                                          {{ ($EmployeeAllInfo->pf_ded=="yes")? "checked" : "" }}> Yes
                                        </label>
                                        <label class="radio-inline">
                                          <input type="radio" name="optradio" value="no" {{ ($EmployeeAllInfo->pf_ded=="no")? "checked" : "" }}> No
                                        </label>
   

                                </div>
                            </div>

                             <div class="col-sm-2">
                                <div class="form-group">

                                    <label for="fullName">ESI Deduction</label><br>
                                    <label class="radio-inline">
                                          <input type="radio" name="optradio1" value="yes"  {{ ($EmployeeAllInfo->esi_ded=="yes")? "checked" : "" }}> Yes
                                        </label>
                                        <label class="radio-inline">
                                          <input type="radio" name="optradio1" value="no" {{ ($EmployeeAllInfo->esi_ded=="no")? "checked" : "" }}> No
                                        </label>

                                </div>
                            </div>

                             <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">Initial Basic</label>
                                    <input type="number" class="form-control mb-4"   value="{{$EmployeeOfficialInfo->intial_basic}}" name="intial_basic" id="intial_basic" >

                                </div>
                            </div>
                                <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">Current Basic</label>
                                    <input type="number" class="form-control mb-4"    value="{{$EmployeeOfficialInfo->current_basic}}" name="current_basic" id="current_basic">

                                </div>
                            </div>

                            <div class="user-info">
                               
                                    
                           </div>
             
                          </div>

                        </div>

       <div class="col-lg-12 emp-sec"> 
      <div class="row b-sec">
   <div class="col-lg-6 "> 
    <div class="card component-card_4">
            <div class="card-body">
              
                <div class="user-info">
                    <h5 class="card-user_name">Bank Details</h5>
                        <div class="col-sm-12">
                                <div class="form-group">

                                    <label for="fullName">Payment Mode </label>
                                    <input type="text" class="form-control mb-4"   value="{{$EmployeeOfficialInfo->payment_bank_mode}}" name="payment_bank_mode" id="current_basic">

                                </div>
                            </div>
               
                                <div class="col-sm-12">
                                    <div class="form-group">
                                    <label for="fullName">Bank: </label>
                                       <lable for="fullName" id="bank"></lable>
                                     <input type="text" class="form-control mb-4"   value="{{$EmployeeOfficialInfo->bank_name}}" name="bank_name" id="current_basic">

                                </div>
                              </div>
                               <div class="col-sm-12">
                                <div class="form-group">

                                    <label for="fullName">Bank A/C No: </label>
                                    <lable for="fullName" id="bank"></lable>
                                    <input type="text" class="form-control mb-4"   value="{{$EmployeeOfficialInfo->account_num}}" \
                                    name="account_num" id="current_basic">

                                </div>
                              </div>
                </div>
            </div>
        </div>
    </div>
     <div class="col-lg-6 "> 
         <div class="card component-card_4">
            <div class="card-body">
              
                <div class="user-info">
                    <h5 class="card-user_name">Increment Details</h5>
                   
                                      <div class="col-sm-12">
                                      <div class="form-group">
                                    <label for="fullName">Increment Due Date :</label>
                                   <lable for="fullName" id="bank"> </lable>
                                    <input type="date" class="form-control mb-4"   value="{{$EmployeeOfficialInfo->incr_date}}" name="incr_date" id="current_basic">
                                 </div>

                                </div>
                                   <div class="col-sm-12">
                                    <div class="form-group">
                                    <label for="fullName">Increment Amount: </label>
                                       <lable for="fullName" id="bank"></lable>
                                       <input type="number" class="form-control mb-4"   value="{{$EmployeeOfficialInfo->incr_amount}}" name="incr_amount" id="current_basic">
                                    </select>

                                </div>
                              </div>
                </div>
            </div>
        </div>
    </div>

                           

             </div>
        </div>


    </div>
    @endif
    @if( Auth::user()->role == "User"||Auth::user()->role == "Authorisor" ||Auth::user()->role == "Supervisor")
    <script>
      // $("#tab2").addClass('Active');
    </script>
    <div class="tab-pane fade show active " id="tab2" role="tabpanel" aria-labelledby="border-profile-tab">
      @else
      <div class="tab-pane fade" id="tab2" role="tabpanel" aria-labelledby="border-profile-tab">
        <script>
      // $("#tab1").addClass('Active');
    </script>
      @endif
    <div class="col-lg-12 emp-sec">
    <div class="row">
    <div class="col-sm-2">
        <div class="form-group">
            <label for="fullName">Gender</label><br>
            <input type="radio"  name="sex" value="male" {{ ($EmployeeAllInfo->sex=="male")? "checked" : "" }}>
            <label for="vehicle1">Male</label>&nbsp;&nbsp;
            <input type="radio" name="sex" value="female" {{ ($EmployeeAllInfo->sex=="female")? "checked" : "" }}>
            <label for="vehicle1">Female</label>

        </div>
    </div>

    <div class="col-sm-3">
        <div class="form-group">
            <label for="fullName">Marital Status</label>
            <select class="form-control" name="marital" id="ddlModels">
             <option <?php if($EmployeeAllInfo->marital_status == 'Married'){ echo "selected"; } else { echo ""; } ?> value="Married">Married</option>
             <option <?php if($EmployeeAllInfo->marital_status == 'UnMarried'){ echo "selected"; } else { echo ""; } ?> value="UnMarried">UnMarried</option>
            </select>
        </div>
    </div>


                                              
    <div class="col-sm-3">
        <div class="form-group">
            <label for="fullName">Blood Group</label>
            <select class="form-control" name="blood">
               <option <?php if($EmployeeAllInfo->blood_group == 'O+'){ echo "selected"; } else { echo ""; } ?> value="O+">O+</option>
            <option <?php if($EmployeeAllInfo->blood_group == 'A+'){ echo "selected"; } else { echo ""; } ?> value="A+">A+</option>
            <option <?php if($EmployeeAllInfo->blood_group == 'A-'){ echo "selected"; } else { echo ""; } ?> value="A-">A-</option>
            <option <?php if($EmployeeAllInfo->blood_group == 'B+'){ echo "selected"; } else { echo ""; } ?> value="B+">B+</option>
            <option <?php if($EmployeeAllInfo->blood_group == 'B-'){ echo "selected"; } else { echo ""; } ?> value="B-">B-</option>
            <option <?php if($EmployeeAllInfo->blood_group == 'AB+'){ echo "selected"; } else { echo ""; } ?> value="AB+">AB+</option>
            <option <?php if($EmployeeAllInfo->blood_group == 'AB-'){ echo "selected"; } else { echo ""; } ?> value="AB-">AB-</option>
            <option <?php if($EmployeeAllInfo->blood_group == 'O+'){ echo "selected"; } else { echo ""; } ?> value="O+">O+</option>
            <option <?php if($EmployeeAllInfo->blood_group == 'O-'){ echo "selected"; } else { echo ""; } ?> value="O-">O-</option>
            </select>
        </div>
    </div>
   <div class="col-sm-4">
      <div class="form-group">
        <label for="fullName">Identification Mark</label>
        <input type="text" class="form-control mb-4" name="id"   value="{{$EmployeeAllInfo->id_mark}}">

      </div>
   </div>
                                 
   <div class="col-sm-2">
      <div class="form-group">
        <label for="fullName">Spouse Name</label>
        <input type="text" class="form-control mb-4" name="spouse"  id="spouseName"  value="{{$EmployeeAllInfo->spouse_name}}">

       </div>
    </div>
    <div class="col-sm-2">
        <div class="form-group">
            <label for="fullName">Spouse's Date Of Birth</label>
            <input type="date" class="form-control mb-4" name="spouse_dob" id="spouseDOB"   value="{{$EmployeeAllInfo->spouse_dob}}">
        </div>
    </div>

    <div class="col-sm-2">
       <div class="form-group">
        <label for="fullName">Father Name</label>
        <input type="text" class="form-control mb-4" name="father"   value="{{$EmployeeAllInfo->father_name}}">
        </div>
   </div>


 <div class="col-sm-2">
        <div class="form-group">

            <label for="fullName">Father's Date Of Birth</label>
            <input type="date" class="form-control mb-4" name="father_dob"  value="{{$EmployeeAllInfo->father_dob}}">

        </div>
 </div>

 <div class="col-sm-2">
        <div class="form-group">

            <label for="fullName">Mother Name</label>
            <input type="text" class="form-control mb-4" name="mother"   value="{{$EmployeeAllInfo->mother_name}}">

        </div>
    </div>


    <div class="col-sm-2">
            <div class="form-group">

                <label for="fullName">Mother's Date Of Birth</label>
                <input type="date" class="form-control mb-4" name="mother_dob"  value="{{$EmployeeAllInfo->mother_dob}}">

            </div>
    </div>

 <div class="col-sm-3">
    <div class="form-group">

        <label for="fullName">Present Address</label>
        <input type="text" class="form-control mb-4"  placeholder="line1"  name="line_11" value="{{$EmployeeAllInfo->present_address1}}">
        <input type="text" class="form-control mb-4" placeholder="line2" name="line_22"  value="{{$EmployeeAllInfo->present_address2}}">
        <input type="text" class="form-control mb-4" placeholder="line3" name="line_33"  value="{{$EmployeeAllInfo->present_address3}}">

    </div>
</div>

 <div class="col-sm-3">
    <div class="form-group">

        <label for="fullName">Permanent Address</label>
        <input type="text" class="form-control mb-4"  placeholder="per_line1" name="per_line1" value="{{$EmployeeAllInfo->permanent_address1}}">
        <input type="text" class="form-control mb-4" placeholder="per_line2" name="per_line2"  value="{{$EmployeeAllInfo->permanent_address2}}">
        <input type="text" class="form-control mb-4" placeholder="per_line3" name="per_line3"  value="{{$EmployeeAllInfo->permanent_address3}}">

    </div>
</div>

 <div class="col-sm-3">
    <div class="form-group">
        <label for="fullName">Contact No</label><br>

        <input type="number"  class="form-control" value="{{$EmployeeAllInfo->ph_no}}" name="contactnumber" id="input-payment-egn">
        <div id="wrong-egn">Please provide 10digit number.</div>
    </div>
</div>
 <div class="col-sm-3">
    <div class="form-group">
        <label for="fullName">Email</label><br>
        <input type="email"   class="form-control" value="{{$EmployeeAllInfo->email}}" name="email">
    </div>
</div>
</div>
</div>
</div>


<div class="tab-pane fade" id="tab3" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
    <div class="offset-lg-11 col-lg-1 new" id="addBtn1">ADD NEW</div>
<table class="table table-bordered table-hover e-table" >
<thead class="e-head">
<tr>

<th>Dependent Name:</th>
<th>Type</th>
<th>Date Of Birth:</th>
<th>Age:</th>
<th>Relationship:</th>
<th>Aadhaar No:</th>
<th>Address</th>
<th>Upload Adhara</th>
<th>Download</th>
<th>Cancel</th>
</tr>
</thead>
<tbody id="e-body">
  @php 
  $ctr=0;
  $i=0;
  $counter=0;
  @endphp
@foreach($EmployeeDependentInfo as $key=>$value)
@php
  $ctr++;
@endphp
<tr>

<td class="td2">
<input type="hidden" class="form-control" name="depedent_sql_id[]" placeholder="enter dependent name" value="{{$value->id}}">
  <input type="text" class="form-control width" name="name[]" placeholder="enter dependent name" value="{{$value->depd_name}}"></td>
  <td><select class="form-control nm" name="dependent_type[] "style="width: 124px"  onchange="nominee_select(this.value,{{$i}})"  value="{{$value->type}}" id="one{{$i}}" >
   
     <option <?php if($value->type == 'Dependent'){ echo "selected"; } else { echo ""; } ?> value="Dependent">Dependent</option>
             <option <?php if($value->type == 'Nominee'){ echo "selected"; } else { echo ""; } ?> value="Nominee">Nominee</option>
  </select></td>
<td><input type="date" class="form-control" name="dob1[]" placeholder="enter DOB" value="{{$value->depd_dob}}"></td>
<td class="td1"><input type="text" class="form-control"  name="age[]" value="{{$value->age}}"style="width: 50px;" ></td>
<td><input type="text" class="form-control" name="relation[]" placeholder="enter your relation" value="{{$value->relationship}}" style="width: 207px;"></td>
<td><input type="number" class="form-control width" name="num[]" placeholder="enter his/her adhara" value="{{$value->depd_adhara_no}}" style="width: 207px;"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="dependent_addr[]" style="width:200px;">{{$value->address}}</textarea></td>
@if($value->upload_adhara!="")
<td class=""><input type="file" class="" placeholder="67%" name="dependent_file[]" style="width: 300px;">
  <td><a href="{{ url('public/dependent/'.$value->upload_adhara) }}" download="{{ $value->upload_adhara }}"><i class="fa fa-download" style="font-size:22px;
"></i></a></td>

 @else

     <td><input type="file" class="" placeholder="67%" name="dependent_file[]"></td> 
      <td></td>     
@endif

<td><button type="button" onclick="deletedependent({{$value->id}});" style="background-color: #7d98da" >X</button></td>
<td></td>
</tr>

@php
$counter =$i;
$i++;
@endphp
@endforeach


@if($ctr==0)
    <tr>
        <input type="hidden" class="form-control" name="depedent_sql_id[]">
<td class="td2"><input type="text" class="form-control width" name="name[]" placeholder="" ></td>
<td><select class="form-control nm" name="dependent_type[] "style="width: 124px"  onchange="nominee_select(this.value,{{$i}})"   id="one{{$i}}" >
    <option>Dependent</option>
    <option>Nominee</option></select></td>
<td><input type="date" class="form-control" name="dob1[]" placeholder="enter DOB"></td>
<td><input type="number" class="form-control  td1"  name="age[]" ></td>
<td class="td2"><input type="text" class="form-control " name="relation[]" placeholder="enter your relation" style="width: 207px;"></td>
<td  class="td2"><input type="number" class="form-control width" name="num[]" placeholder="enter adhara"  ></td>
<td><textarea rows="3" cols="40" class="form-control"  name="dependent_addr[]" style="width:200px;"></textarea></td>
<td><input type="file" class="" placeholder="67%" name="dependent_file[]" multiple></td>
<td></td>
<td>
   <button type="button" class="deletebtn" title="Remove row" style="background-color: #7d98da">X</button>
</td>

</tr>

@endif

</tbody>

</table>

</div>
</div> 

<div class="tab-pane fade show" id="tab4" role="tabpanel" aria-labelledby="border-home-tab">
    <div class="col-lg-12 emp-sec">
      <div class="row">
        <div class="col-sm-12">
            <h4 class="mb-4">Academic</h4>
        </div>
        <div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
 <div class="offset-lg-11 col-lg-1 new" id="addBtnQual">ADD NEW</div>
<table class="table table-bordered table-hover">
<thead>
<tr>

<th>Academic Qualification:</th>
<th>Stream/ Subject:</th>
<th style="padding-left: 22px;"> Board/University </th>
<th>Year Of Passing:</th>
<th>% Of Mark:</th>
<th>Division</th>
<th>Remark</th>
<th>Upload Document:</th>
<th>Download</th>
<th>Remove</th>

</tr>
</thead>

<tbody id="e-body_qual">
  @php 
  $ctr_qual=0;
  @endphp
  @foreach($EmployeeQualificationInfo as $key=>$value)
  @php
  $ctr_qual++;
@endphp
<tr>
<td>
  <input type="hidden" name="qlf_hiddenSqlid[]" value="{{$value->id}}"> 
  <select name="academic[]" class="form-control width">
   <option <?php if($value->qualification_type == 'Primary'){ echo "selected"; } else { echo ""; } ?> value="Primary">Primary</option>
 <option <?php if($value->qualification_type == 'Upper Primary'){ echo "selected"; } else { echo ""; } ?> value="Upper Primary">Upper Primary</option>
  <option <?php if($value->qualification_type == 'Minor'){ echo "selected"; } else { echo ""; } ?> value="Minor">Minor</option>
 <option <?php if($value->qualification_type == 'Under Matric'){ echo "selected"; } else { echo ""; } ?> value="Under Matric">Under Matric</option>
  <option <?php if($value->qualification_type == 'Intermediate'){ echo "selected"; } else { echo ""; } ?> value="Intermediate">Intermediate</option>
 <option <?php if($value->qualification_type == 'Graduate'){ echo "selected"; } else { echo ""; } ?> value="Graduate">Graduate</option>
  <option <?php if($value->qualification_type == 'Post-Graduate'){ echo "selected"; } else { echo ""; } ?> value="Post-Graduate">Post-Graduate</option>
 <option <?php if($value->qualification_type == 'M-Phill'){ echo "selected"; } else { echo ""; } ?> value="M-Phill">M-Phill</option>
  <option <?php if($value->qualification_type == 'PHD'){ echo "selected"; } else { echo ""; } ?> value="PHD">PHD</option>
 <option <?php if($value->qualification_type == 'MS'){ echo "selected"; } else { echo ""; } ?> value="MS">MS</option>
  <option <?php if($value->qualification_type == 'Certificate'){ echo "selected"; } else { echo ""; } ?> value="Certificate">Certificate</option>
 <option <?php if($value->qualification_type == 'Diploma'){ echo "selected"; } else { echo ""; } ?> value="Diploma">Diploma</option>
 <option <?php if($value->qualification_type == 'Post-Diploma'){ echo "selected"; } else { echo ""; } ?> value="Post-Diploma">Post-Diploma</option>
 <option <?php if($value->qualification_type == 'PG-Diploma'){ echo "selected"; } else { echo ""; } ?> value="PG-Diploma">PG-Diploma</option>
  <option <?php if($value->qualification_type == 'Others'){ echo "selected"; } else { echo ""; } ?> value="Others">Others</option>

    </select>
</td>
<td><input type="text" class="form-control width" placeholder="Arts" name="stream[]" value="{{$value->stream_subject}}"> </td>
<td>
     <select class="form-control" name="board_name_ajax1[]" style="    width: 409px;">
         @foreach($Board_view as $ky=>$val) 
             <option value="{{$val->board_name}}"
                    {{$val->board_name==$value->institution
                          ? 'selected':''}}>{{$val->board_name}}
                  </option>      
            
        @endforeach 
    </select>
<!--     <div class="container box">
          <input type="text" class="form-control" name="board_name_ajax1[]" style="width: 409px;margin-left: -16px;" value="{{$value->institution}}">
      <div id="boardList">
  
    </div> -->

</td>
<td><input type="text" class="form-control" placeholder="1890" name="year[]" value="{{$value->year_passing}}"></td>
<td><input type="text" class="form-control"  name="per_mark[]" value="{{$value->mark_perc}}" style="width:54px"></td>
<td><input type="text" class="form-control width2" placeholder="" name="division_qualification[]"
  value="{{$value->division_qualification}}"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="remark_qualification[]" style="width:200px;">{{$value->remark_qualification}}</textarea></td>
@if($value->upload!="")
<td class=""><input type="file" class="" placeholder="67" name="qualification_file[]" style="width: 300px;">
  <td><a href="{{ url('public/qualification/'.$value->upload) }}" download="{{ $value->upload }}"><i class="fa fa-download" style="font-size:22px;
"></i></a></td>
@else
<td><input type="file" class="" placeholder="67%" name="qualification_file[]"></td> 
  <td></td>       
@endif

<td><button type="button" style="background-color: #7d98da" onclick="deletequalification({{$value->id}});" >X</button></td>



</tr>
@endforeach

@if($ctr_qual==0)

  
  <tbody>
  <tr>
    
    <input type="hidden" class="form-control" name="qlf_hiddenSqlid[]"> 
  <td><select class="form-control" name="academic[]">
      <option>Primary</option>
      <option>Upper Primary</option>
      <option>Minor</option>
      <option>Under Matric</option>
      <option>Intermediate</option>
      <option>Graduate</option>
      <option>Post-Graduate</option>
      <option>M-Phill </option>
      <option>PHD</option>
      <option>MS</option>
      <option>Certificate</option>
      <option>Diploma</option>
      <option>Post-Diploma</option>
      <option>PG-Diploma</option>
      <option>Others</option>
  
      </select></td>
  <td><input type="text" class="form-control" placeholder="Arts" name="stream[]"></td>
  <td> 
        <div class="container box">
          <input type="text" class="form-control" name="board_name_ajax1[]" value="">
      <div id="boardList">
  
    </div>
       </td>
  <td><input type="text" class="form-control" placeholder="1890" name="year[]"></td>
  <td><input type="text" class="form-control" placeholder="67" name="per_mark[]"></td>
  <td><input type="text" class="form-control width2" placeholder="" name="division_qualification[]"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="remark_qualification[]" style="width:200px;"></textarea></td>
  <td><input type="file" class="" placeholder="67%" name="qualification_file[]"></td>

  <td></td>
  <td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>

  </tr>
  
@endif

</tbody>
</table>

     
</div>

     </div>
    </div>
<div class="col-lg-12"> 
  <div class="row b-sec">

            

</div>
</div>
</div>   

 

<div class="tab-pane fade" id="tab5" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">

    <div class="offset-lg-11 col-lg-1 new" id="addBtn2">ADD NEW</div>
<table class="table table-bordered table-hover" id="maintable_dependent_exp">
<thead>

<tr>

<th>Organisation Name:</th>
<th>Sector:</th>
<th>Position:</th>
<th>From Date:</th>
<th>To Date:</th>
<th>Reason For Leave</th>
<th>Remark</th>
<th>Upload Document:</th>
<th>Download</th>
<th>Remove</th>
</tr>
</thead>
<tbody id="experience_body">
    @php 
  $ctr_exper=0;
  @endphp
  @foreach($EmployeeExperienceInfo as $key=>$value)
  @php
  $ctr_exper++;
@endphp
<tr>
<input type="hidden" class="form-control" name="experience_sql_id[]"  value="{{$value->id}}">
<td><input type="text" class="form-control" placeholder="The Samad"  name="orgn[]" value="{{$value->orgn_name}}" style="width: 255px;"></td>
<td><input type="text" class="form-control width2" placeholder="Media" name="sect[]" value="{{$value->sector}}"></td>
<td><input type="text" class="form-control width2" placeholder="Editor" name="pos[]" value="{{$value->position}}"></td>
<td><input type="date" class="form-control" placeholder="01/03/2015" name="from[]"  value="{{$value->start_date}}"></td>
<td><input type="date" class="form-control" placeholder="01/03/2017" name="to[]"  value="{{$value->end_date}}"></td>
<td><textarea rows="3" cols="40" class="form-control width"  name="area[]" style="    width: 200px;">{{$value->reason}}</textarea></td>
  <td><textarea rows="3" cols="40" class="form-control"  name="remark_area[]" style="width:250px;">{{$value->remark_area}}</textarea></td>
@if($value->upload!="")
<td><input type="file" class="" placeholder="67" name="e_file[]" ></td>
  <td><a href="{{ url('public/experience/'.$value->upload) }}" download="{{ $value->upload}}"><i class="fa fa-download" style="font-size:22px;
"></i></a></td>


 @else
     <td><input type="file" class="" placeholder="67%" name="e_file[]" ></td>  
     <td></td>      
@endif

<td><button type="button" onclick="deleteorganization({{$value->id}});" style="background-color: #7d98da" >X</button></td>
</tr>
@endforeach

@if($ctr_exper==0)
    <tr>
    <input type="hidden" class="form-control" name="experience_sql_id[]">
<td><input type="text" class="form-control" placeholder="The Samad"  name="orgn[]" style="width: 255px;"></td>
<td><input type="text" class="form-control width2" placeholder="Media" name="sect[]"></td>
<td><input type="text" class="form-control width2" placeholder="Editor" name="pos[]"></td>
<td><input type="date" class="form-control" placeholder="01/03/2015" name="from[]"></td>
<td><input type="date" class="form-control" placeholder="01/03/2017" name="to[]"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="area[]"  style="    width: 200px;"></textarea></td>
 <td><textarea rows="3" cols="40" class="form-control"  name="remark_area[]" style="width:250px;"></textarea></td>
<td><input type="file" name="e_file[]"></td>
<td></td>
<td><button type="button" class="deletebtn" title="Remove row" style="background-color: #7d98da">X</button></td>

</tr>
@endif


</tbody>
</table>

     
</div>
</div>  

<div class="tab-pane fade" id="tab6" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<!-- <div class="offset-lg-11 col-lg-1 ">
    <button class="btn btn-md btn-primary" 
      id="addBtn3" type="button">
        Add new Row
    </button></div> -->

<table class="table table-bordered table-hover" id="maintable_dependent_trans">
<thead>
<tr>

<th>Transfer Order No.</th>
<th>Type</th>
<th>Transfer Date:</th>
<th>From Date:</th>
<th>To Date:</th>
<th>From Department:</th>
<th>To Department:</th>
<th>From Workplace</th>
<th>To Workplace</th>
<th>Reason</th>
<th>Remarks:</th>
<th>Upload Document</th>
<th>Download</th>
<th>Remove</th>


</tr>
</thead>
<tbody id="table_transfer">
  <div class="offset-lg-11 col-lg-1 new" id="add_newtransferno">ADD NEW</div>

      @php 
  $ctr_trans=0;
  $i=0;
  @endphp
@foreach($EmployeeTransferInfo as $key=>$value)
  @php
  $ctr_trans++;
@endphp 
<tr>
<input type="hidden" class="form-control" name="transfer_sql_id[]" value="{{$value->id}}">
<td><input type="text" class="form-control width" name="trans_order[]" width="130px" value="{{$value->tranfer_order_no}}"></td>
<td> <select class="form-control width" width="130px"  name="order_type[]" >
   <option <?php if($value->type == 'Transfer'){ echo "selected"; } else { echo ""; } ?> value="Transfer">Transfer</option>
 <option <?php if($value->type == 'Deputation'){ echo "selected"; } else { echo ""; } ?> value="Deputation">Deputation</option>
    </select></td>
<td><input type="date"  class="form-control" placeholder="05/03/2009" width="130px"  value="{{$value->trans_date}}"  name="transfer_ord_date[]"></td>
<td><input type="date"  class="form-control" placeholder="13/03/2008" value="{{$value->from_date}}" name="from_date[]"></td>
<td><input type="date" class="form-control" placeholder="13/03/2008" value="{{$value->to_date}}" name="to_date[]"></td>
<td><select class="form-control width"  name="f_dept[]">
<option>Select</option>
     @foreach($Department_fetch as $ky=>$val)
   
    <option value="{{$val->dept_no}}" {{$val->dept_no==$value->from_dept 
                                                        ? 'selected':''}}>{{$val->dept_name}}</option>
        @endforeach
  </select></td>
<td><select class="form-control width" name="t_dept[]" onchange="transfer({{$i}})"  id="transferid{{$i}}">
<option>Select</option>
     @foreach($Department_fetch as $ky=>$val)
   
    <option value="{{$val->dept_no}}"  {{$val->dept_no==$value->to_dept 
                                                        ? 'selected':''}}>{{$val->dept_name}}</option>
    @endforeach
  </select></td>
<td><select class="form-control width" name="from_work[]">
<option>Select</option>
@foreach($Workplace_fetch as $ky=>$val)
<option value="{{$val->id}}"{{$val->id==$value->from_work ? 'selected':''}}>{{$val->workplace_name}}
                                              </option>
                                           @endforeach
</select></td>
<td><select class="form-control width" name="to_work[]"  onchange="transferWork({{$i}})"  id="transferWorkid{{$i}}">
<option>Select</option>
@foreach($Workplace_fetch as $ky=>$val)
  <option value="{{$val->id}}"{{$val->id==$value->to_work ? 'selected':''}}>{{$val->workplace_name}}
    </option>
                       @endforeach
</select></td>

<td> <select class="form-control width" name="ord_rea[]">
<option>Select</option>
   <option <?php if($value->reason == 'Reward'){ echo "selected"; } else { echo ""; } ?> value="Reward">Reward</option>
 <option <?php if($value->reason == 'Routine'){ echo "selected"; } else { echo ""; } ?> value="Routine">Routine</option>
  <option <?php if($value->reason == 'Displinary'){ echo "selected"; } else { echo ""; } ?> value="Displinary">Displinary</option>
 <option <?php if($value->reason == 'Other'){ echo "selected"; } else { echo ""; } ?> value="Other">Other</option>

    </select></td>
<td><textarea rows="3" cols="40" class="form-control width" name="reamrks[]">{{$value->remark}} </textarea></td>
@if($value->upload!="")

<td><input type="file" class="" placeholder="67%" name="trans_file[]" style="width: 300px;"></td><td><a href="{{ url('public/transfer/'.$value->upload) }}" download="{{ $value->upload }}"><i class="fa fa-download" style="font-size:22px;
"></i></a></td>
 @else
     <td><input type="file" class="" placeholder="67%" name="trans_file[]"></td> 
     <td></td>       
@endif

<td><button type="button" onclick="deletetransfer({{$value->id}});"style="background-color: #7d98da">X</button></td>
</tr>
@php
$i++;
@endphp
@endforeach
@if($ctr_trans==0)
    <tr>
    <input type="hidden" class="form-control" name="transfer_sql_id[]">
<td><input type="text" class="form-control width" width="130px" name="trans_order[]"></td>
<td> <select class="form-control width" name="order_type[]" >
        <option>Transfer</option>
        <option>Deputation</option>
    </select></td>
<td><input type="date"  class="form-control" placeholder="05/03/2009" width="130px" name="transfer_ord_date[]"></td>
<td><input type="date"  class="form-control" placeholder="13/03/2008" name="from_date[]"></td>
<td><input type="date" class="form-control" placeholder="13/03/2008" name="to_date[]" ></td>
<td> <select class="form-control width"  name="f_dept[]">
<option>Select</option>
     @foreach($Department_fetch as $ky=>$val)
    <option value="{{$val->dept_no}}">{{$val->dept_name}}</option>
        @endforeach
  </select>
</td>
<td><select class="form-control width" name="t_dept[]" onchange="transfer({{$i}})"  id="transferid{{$i}}">
<option>Select</option>
     @foreach($Department_fetch as $ky=>$val)

    <option value="{{$val->dept_no}}">{{$val->dept_name}}</option>
        @endforeach
  </select></td>
<td><select class="form-control width" name="from_work[]">
<option>Select</option>
@foreach($Workplace_fetch as $ky=>$val)

     <option value="{{$val->id}}">{{$val->workplace_name}}</option>
 @endforeach
</select></td>
<td><select class="form-control width" name="to_work[]"  onchange="transferWork({{$i}})"  id="transferWorkid{{$i}}">
<option>Select</option>
@foreach($Workplace_fetch as $ky=>$val)
     <option value="{{$val->id}}">{{$val->workplace_name}}</option>
 @endforeach
</select></td>

<td> <select class="form-control width"   name="ord_rea[]">
        <option>Select</option>
        <option>Reward</option>
        <option>Routine</option>
        <option>Displinary</option>
        <option>Other</option>
    </select></td>
<td><textarea rows="3" cols="40" class="form-control width" name="reamrks[]"></textarea></td>
<td><input type="file" name="trans_file[]" ></td>
<td></td>
<td><button type="button" class="deletebtn" title="Remove row" style="background-color: #7d98da">X</button></td>

</tr>
@endif
</tbody>
</table>

     
</div>
</div>



<div class="tab-pane fade" id="tab7" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">

 
<table class="table table-bordered table-hover" id="maintable_dependent_promo">
<thead>
<tr>

<th>Promotion order no</th>
<th>Promotion Date:</th>
<th>Promotion Effect Date:</th>
<th>From grade</th>
<th>From Designation/Position</th>
<th>From Basic pay</th>
<th>From special allowance</th>
<th>From Other allowance</th>
<th>To Grade:</th>
<th>To Designation/Position </th>
<th>To Basicpay:</th>
<th>To Special allowance:</th>
<th>To Other Allowance:</th>
<th>Remark</th>
<th>Upload Document:</th>
<th>Download</th>
<th>Remove</th>

</tr>
</thead>
<tbody id="promo_tbl">
     <div class="offset-lg-11 col-lg-1 new" id="add_newpromotion">ADD NEW</div>
 @php 
  $ctr_promo=0;
  $i=0;
  @endphp
  @foreach($EmployeePromotionInfo as $key=>$value) 
    @php
  $ctr_promo++;
@endphp 
<tr>
<input type="hidden" class="form-control" name="promotion_sql_id[]" value="{{$value->id}}">
<td><input type="text" class="form-control width" name="promo_order_no[]" value="{{$value->promotion_order_no}}"></td>
<td><input type="date" class="form-control" name="promo_date[]" value="{{$value->promotion_date}}"></td>
<td><input type="date" class="form-control" placeholder="13/03/2008" name="effect_date[]" value="{{$value->promotion_effect_date}}"></td>
<td><select class="form-control width" onchange="promotion({{$i}})"  id="promotionid{{$i}}"  name="from_grade[]">
<option value="">--Select--</option>
@foreach($pay_grade_view as $ky=>$val)
<option value="{{$val->id}}"{{$val->id==$value->from_grade_code ? 'selected':''}}>{{$val->pay_grade_desc}}
</option>
@endforeach
</select></td>

<td>
<select class="form-control width"  name="from_design[]" >
<option value="">--Select--</option>
@foreach($Designation as $ky=>$val)
                                              <option value="{{$val->id}}"{{$val->desg_code==$value->from_desg_code
                                                        ? 'selected':''}}>{{$val->desg_name}}</option>
                                           @endforeach
</select></td>
<td><input type="text" class="form-control width3" name="from_basic[]" value="{{$value->from_basic_pay}}" id='catch_paygrade_value{{$i}}' style="    width: 202px;" readonly="readonly"></td>
<td><input type="number" class="form-control width" name="from_special[]" id="promtion_current_allowance{{$i}}" value="{{$value->special_allownace}}"readonly="readonly" ></td>
<td><input type="number" class="form-control width" name="from_other_special[]"  id="promtion_currentother_allowance{{$i}}" value="{{$value->other_special_allownace}}" readonly="readonly"></td>

<td><select class="form-control width" onchange="topromotion({{$i}})" id="promotiontoid{{$i}}" name="to_grade[]">
<option value="">--Select--</option>
@foreach($pay_grade_view as $ky=>$val)
<option value="{{$val->id}}"{{$val->id==$value->to_grade_code ? 'selected':''}}>{{$val->pay_grade_desc}}
</option>
@endforeach
</select></td>
<td>
<select class="form-control width"   name="to_portion[]" onchange="portionDropdown({{$i}})"  id="portionDropdownid{{$i}}">
<option value="">--Select--</option>
@foreach($Designation as $ky=>$val)
                                              <option value="{{$val->id}}"{{$val->desg_code==$value->to_portion
                                                        ? 'selected':''}}>{{$val->desg_name}}</option>
                                           @endforeach
</select></td>
<td><input type="text" class="form-control width" name="to_basic[]" value="{{$value->to_basic_pay}}" style="width: 202px;" id='catch_topaygrade_value{{$i}}'readonly="readonly"></td>
<td><input type="number" class="form-control width" name="total_allow[]" value="{{$value->total_allowance}}" id="promtion_tocurrent_allowance{{$i}}"readonly="readonly"></td>
<td><input type="number" class="form-control width" name="to_other_allowance[]" value="{{$value->other_allowance}}" id="promtion_tocurrentother_allowance{{$i}}"readonly="readonly"></td>
<!-- <td><input type="text" class="form-control" name="to_oth_allow[]" ></td> -->
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remark[]">{{$value->remark}}</textarea></td>
@if($value->upload!="")
<td><input type="file" class="" placeholder="67%" name="upload_promo[]" style="width: 300px;"></td><td><a href="{{ url('public/promotion/'.$value->upload) }}" download="{{ $value->upload }}"><i class="fa fa-download" style="font-size:22px;
"></i></a></td>
 @else
     <td><input type="file" class="" placeholder="67%" name="upload_promo[]"></td> 
     <td></td>       
@endif

<td><button type="button" onclick="deletepromotion({{$value->id}});" style="background-color: #7d98da">X</button></td>
</tr>
@php
$i++;
@endphp
@endforeach
@if($ctr_promo==0)
    <tr>
    <input type="hidden" class="form-control" name="promotion_sql_id[]">
<td><input type="text" class="form-control width" name="promo_order_no[]"></td>
<td><input type="date" class="form-control" name="promo_date[]"></td>
<td><input type="date" class="form-control" placeholder="13/03/2008" name="effect_date[]"></td>
<td>
<select class="form-control "  name="from_grade[]" onchange="promotion({{$i}})"  id="promotionid{{$i}}"  style="width: 202px;">
   <option value="">--Select--</option>
       @foreach($pay_grade_view as $ky=>$val)
        <option value="{{$val->id}}">{{$val->pay_grade_desc}}
        </option>
       @endforeach
</select>
</td>
<td>
<select class="form-control width"   name="from_design[]">
<option value="">--Select--</option>
                                    @foreach($Designation as $ky=>$val)
                                              <option value="{{$val->desg_code}}">{{$val->desg_name}}</option>
                                           @endforeach
</select></td>

<td><input type="text" class="form-control width" name="from_basic[]" id='catch_paygrade_value{{$i}}' style="    width: 202px;" readonly="readonly"></td>
<td><input type="number" class="form-control width3" name="from_special[]" id="promtion_current_allowance{{$i}}" readonly="readonly" ></td>
<td><input type="number" class="form-control width3" name="from_other_special[]"  id="promtion_currentother_allowance{{$i}}" readonly="readonly" ></td>
<td> <select class="form-control "  onchange="topromotion({{$i}})" id="promotiontoid{{$i}}" name="to_grade[]" style="width: 202px;">
   <option value="">--Select--</option>
       @foreach($pay_grade_view as $ky=>$val)
        <option value="{{$val->id}}">{{$val->pay_grade_desc}}
        </option>
       @endforeach
</select>
</td>
<td>
<select class="form-control width"   name="to_portion[]" onchange="portionDropdown({{$i}})"  id="portionDropdownid{{$i}}">
<option value="">--Select--</option>
                                    @foreach($Designation as $ky=>$val)
                                              <option value="{{$val->desg_code}}">{{$val->desg_name}}</option>
                                           @endforeach
</select></td>
<td><input type="text" class="form-control width" name="to_basic[]" id='catch_topaygrade_value{{$i}}' readonly="readonly"></td>
<td><input type="number" class="form-control width3" name="total_allow[]" id="promtion_tocurrent_allowance{{$i}}" readonly="readonly" ></td>
<td><input type="number" class="form-control width3" name="to_other_allowance[]" id="promtion_tocurrentother_allowance{{$i}}" readonly="readonly"></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remark[]"></textarea></td>
<td><input type="file" name="upload_promo[]"></td>

<td></td>
<td><button type="button" class="deletebtn" title="Remove row" style="background-color: #7d98da">X</button></td>

</tr>
@endif
</tbody>
</table>     
</div>
</div>  
<div class="tab-pane fade" id="tab8" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<!-- <div class="offset-lg-11 col-lg-1 ">
    <button class="btn btn-md btn-primary" 
      id="probation_add" type="button">
        Add new Row
    </button></div> -->
    <div class="offset-lg-11 col-lg-1 new"     id="add_newprobation" type="button">
ADD NEW</div>
<table class="table table-bordered table-hover">
<thead>
<tr>

<th>Probation Order No:</th>
<th>Probation Start Date:</th>
<th>Probation End Date:</th>
<th>Pay Grade:</th>
<th>Initial Basic:</th>
<th>Special Allowance:</th>
<th>Other Allowance:</th>
<th>Remarks:</th>
<th>Upload Document:</th>
<th>Download</th>
<th>Remove</th>
</tr>
</thead>
<tbody id="probationtable">
   @php 
  $ctrprob=0;
    $i=0;
  @endphp
  @foreach($EmployeeProbationInfo as $key=>$value)
      @php
  $ctrprob++;
@endphp  
<tr>
<input type="hidden" name="prob_sqli_id[]" value="{{$value->id}}">
<td><input type="text" class="form-control width" name="prob_order[]" value="{{$value->prob_order_no}}"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="prob_start[]"value="{{$value->prob_start_date}}"></td>
<td><input type="date" class="form-control"  placeholder="13/07/2008" name="prob_end[]"value="{{$value->prob_end_date}}"></td>
<td><select class="form-control " onchange="probation({{$i}})"  id="probationid{{$i}}" name="pay_grade1[]" style="width: 202px;">
   <option value="">--Select--</option>
     @foreach($pay_grade_view as $ky=>$val)
<option value="{{$val->id}}"{{$val->id==$value->pay_grade ? 'selected':''}}>{{$val->pay_grade_desc}}
</option>
@endforeach
</select></td>
<td><input type="text" class="form-control width2" name="initial[]"   value="{{$value->intial_basic}}" id="promotion_catch_topaygrade_value{{$i}}" readonly="readonly" style="width: 219px;"></td>
<td><input type="number" class="form-control width2" name="special_allowance[]"value="{{$value->special_allowance}}" id="probation_current_allowance{{$i}}" readonly="readonly"></td>
<td><input type="number" class="form-control width2" name="other_allownace[]"value="{{$value->other_allowance}}" id="probation_tocurrentother_allowance{{$i}}" readonly="readonly" ></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remark_prob[]">{{$value->remarks}}</textarea></td>

@if($value->upload!="")
<td><input type="file" class="" placeholder="67%" name="prob_upload[]" style="width: 215px;"></td><td><a href="{{ url('public/probation/'.$value->upload) }}" download="{{ $value->upload }}"><i class="fa fa-download" style="font-size:22px;
"></i></a></td>
 @else
     <td><input type="file" class="" placeholder="67%" name="prob_upload[]"></td> 
     <td></td>       
@endif

<td><button type="button" onclick="deleteprobation({{$value->id}});" style="background-color: #7d98da">X</button></td>
</tr>
@php
$i++;
@endphp
@endforeach
@if($ctrprob==0)
    <tr>
    <input type="hidden" name="prob_sqli_id[]">

<td><input type="text" class="form-control width" name="prob_order[]"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="prob_start[]"></td>
<td><input type="date" class="form-control"  placeholder="13/07/2008" name="prob end[]"></td>
<td>
<select class="form-control " onchange="probation({{$i}})"  id="probationid{{$i}}" name="pay_grade1[]" style="width: 202px;">
   <option value="">--Select--</option>
       @foreach($pay_grade_view as $ky=>$val)
        <option value="{{$val->id}}">{{$val->pay_grade_desc}}
        </option>
       @endforeach
</select></td>
<td><input type="text" class="form-control width2" name="initial[]" id="promotion_catch_topaygrade_value{{$i}}"  readonly="readonly" style="width: 220px;"></td>
<td><input type="number" class="form-control width2" name="special_allowance[]"id="probation_current_allowance{{$i}}" readonly="readonly"></td>
<td><input type="number" class="form-control width2" name="other_allownace[]"id="probation_tocurrentother_allowance{{$i}}" readonly="readonly" ></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remark_prob[]"></textarea></td>
<td><input type="file" name="prob_upload[]"></td>
<td></td>
<td><button type="button" class="deletebtn" title="Remove row" style="background-color: #7d98da"> X</button></td>

</tr>
@endif
</tbody>
</table>     
</div>
</div>  

<div class="tab-pane fade" id="tab9" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<!-- <div class="offset-lg-11 col-lg-1 ">
    <button class="btn btn-md btn-primary" 
      id="add_new_contract" type="button">
        Add new Row
    </button></div> -->
    <div class="offset-lg-11 col-lg-1 new" id="add_new_contract">ADD NEW</div>

<table class="table table-bordered table-hover">
<thead>
<tr>

<th>Contract Order No.</th>
<th>Contract Start Date:</th>
<th>Contract End Date:</th>
<th>Consolidated Pay</th>
<th>Special Allowance</th>
<th>Other Allowance</th>
<th>Remarks:</th>
<th>Upload Document:</th>
<th>Download</th>
<th>Remove</th>
</tr>
</thead>
<tbody id="tbody_contract">
<tr>
      @php 
  $ctr_cont=0;
  @endphp
@foreach($EmployeeContractInfo as $key=>$value)
     @php
  $ctr_cont++;
@endphp  
<input type="hidden"  name="contract_sqli_id[]" value="{{$value->id}}" >
<td><input type="text" class="form-control width" name="cont_order[]" value="{{$value->cont_order_no}}"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="cont_start_date[]" value="{{$value->cont_start_date}}"></td>
<td><input type="date" class="form-control"  name="cont_end_date[]"value="{{$value->cont_end_date}}"></td>
<td><input type="number" class="form-control width2" name="con_pay[]"value="{{$value->consolidated_pay}}"></td>
<td><input type="number" class="form-control width2" name="special[]"value="{{$value->special_allowance}}"></td>
<td><input type="number" class="form-control width2" name="other[]"value="{{$value->other_allowance}}"></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remarks[]">{{$value->remarks}}</textarea></td>

@if($value->upload!="")
<td><input type="file" class="" placeholder="67%" name="cont_file[]" style="width: 215px;"></td>
  <td><a href="{{ url('public/contract/'.$value->upload) }}" download="{{ $value->upload }}"><i class="fa fa-download" style="font-size:22px;"></i></a></td>


 @else
     <td><input type="file" class="" placeholder="67%" name="cont_file[]"></td>
     <td></td>        
@endif

<td><button type="button" onclick="deletecontract({{$value->id}});" 
style="background-color: #7d98da">X</button></td>
</tr>
@endforeach
@if($ctr_cont==0)
<tr>
<input type="hidden"  name="contract_sqli_id[]">
<td><input type="text" class="form-control width" name="cont_order[]"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="cont_start_date[]"></td>
<td><input type="date" class="form-control" value="13/03/2008" name="cont_end_date[]"></td>
<td><input type="number" class="form-control width2" name="con_pay[]"></td>
<td><input type="number" class="form-control width2" name="special[]"></td>
<td><input type="number" class="form-control width2" name="other[]"></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remarks[]"></textarea></td>

<td><input type="file" name="cont_file[]"></td>
<td></td>
<td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>

</tr>
@endif
</tbody>
</table>     
</div>
</div>  






<div class="tab-pane fade" id="tab10" role="tabpanel" aria-labelledby="border-contact-tab" >
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<!-- <div class="offset-lg-11 col-lg-1 ">
    <button class="btn btn-md btn-primary" 
      id="addBtn" type="button">
        Add new Row
    </button></div> -->
    <div class="offset-lg-11 col-lg-1 new" id="addBtn">ADD NEW</div>
<table class="table table-bordered table-hover"  id="maintable_dependent_ante" width="50%" cellpadding="0" cellspacing="0" class="pdzn_tbl1" border="#729111 1px solid" >
<thead>
<tr>

<th>Order No:</th>
<th>Order Date:</th>
<th>Type:</th>
<th>W.E.E Date:</th>
<th>W.E.T Date:</th>
<th>Remarks</th>
<th>Uploads</th>
<th>Download</th>
<th>remove</th>


</tr>
</thead>

<tbody id="tbody">
<tr>
 @php 
  $ctr_ante=0;
  @endphp
 @foreach($EmployeeAntecedentInfo as $key=>$value) 
      @php
  $ctr_ante++;
@endphp 
</head>
 <body>

  </div>
</body>
  
</html>
<input type="hidden" class="form-control" name="antecedent_sql_id[]"  value="{{$value->id}}">
<td><input type="text" class="form-control width" name="ante_order_no[]" value="{{$value->order_no}}"></td>
<td><input type="date" class="form-control" name="ante_order_date[]"
  value="{{$value->order_date}}"></td>
<td>   <select class="form-control  width" name="ante_type[]">

     <option <?php if($value->type == 'Explanation'){ echo "selected"; } else { echo ""; } ?> value="Explanation">Explanation</option>
 <option <?php if($value->type == 'Termination'){ echo "selected"; } else { echo ""; } ?> value="Termination">Termination</option>
  <option <?php if($value->type == 'Warning'){ echo "selected"; } else { echo ""; } ?> value="Warning">Warning</option>
 <option <?php if($value->type == 'Salary Deduction'){ echo "selected"; } else { echo ""; } ?> value="Salary Deduction">Salary Deduction</option>
  <option <?php if($value->type == 'Demotion'){ echo "selected"; } else { echo ""; } ?> value="Demotion">Demotion</option>
 <option <?php if($value->type == 'Charge Sheet'){ echo "selected"; } else { echo ""; } ?> value="Charge Sheet">Charge Sheet</option>
  <option <?php if($value->type == 'Suspension'){ echo "selected"; } else { echo ""; } ?> value="Suspension">Suspension</option>
 <option <?php if($value->type == 'Others'){ echo "selected"; } else { echo ""; } ?> value="Others">Others</option>
        
    </select></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="ante_w_e_e[]" value="{{$value->WEE_date}}"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="ante_w_e_t[]" value="{{$value->WET_date}}"></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="ante_remarks[]">{{$value->remarks}}</textarea> </td>

@if($value->upload!="")
<td><input type="file" class="" placeholder="67%" name="antecedent_upload[]" style="width: 215px;"></td>
  <td><a href="{{ url('public/antecedent/'.$value->upload) }}" download="{{ $value->upload }}"><i class="fa fa-download" style="font-size:22px;"></i></a></td>


 @else
     <td><input type="file" class="" placeholder="67%" name="antecedent_upload[]"></td>
     <td></td>        
@endif
<td><button type="button" onclick="deleteantecedent({{$value->id}});"  
style="background-color: #7d98da">X</button></td>

</tr>
@endforeach
@if($ctr_ante==0)
<tr>
<input type="hidden" class="form-control" name="antecedent_sql_id[]" >
<td><input type="text" class="form-control width" name="ante_order_no[]"></td>
<td><input type="date" class="form-control" value="13/03/2008" name="ante_order_date[]"></td>
<td>   <select class="form-control  width" name="ante_type[]">
        <option>Explanation</option>
        <option>Termination</option>
        <option>Warning</option>
        <option>Salary Deduction</option>
        <option>Demotion</option>
        <option>Charge Sheet</option>
        <option>Suspension</option>
        <option>Others</option>
    </select></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="ante_w_e_e[]"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="ante_w_e_t[]"></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="ante_remarks[]"></textarea></td>

<td><input type="file" class="" placeholder="67%" name="antecedent_upload[]"></td>
<td></td>
<td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>

</tr>
@endif
<br>


</tbody>
</table>     
</div>
</div>  


<div class="tab-pane fade" id="tab11" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<!-- <div class="offset-lg-11 col-lg-1 ">
    <button class="btn btn-md btn-primary" 
      id="add_new_revocation" type="button">
        Add new Row
    </button></div> -->
    <div class="offset-lg-11 col-lg-1 new" id="add_new_revocation">ADD NEW</div>
<table class="table table-bordered table-hover" >
<thead>
<tr>

<th>Revocation Order No:</th>
<th>Revocation Order Date:</th>
<th>Antecedent Order no:</th>
<th>Antecedent Order Date:</th>
<th>Antecedent Type:</th>
<th>Antecedent W.E.F date:</th>
<th>Antecedent W.E.T Date:</th>
<th>Revocation Effected date:</th>
<th>Remarks:</th>
<th>Upload</th>
<th>Download</th>
<th>Remove</th>

</tr>
</thead>
<tbody id="maintable_dependent_revocation">
<tr>
          @php 
  $ctr_revo=0;
  @endphp
   @foreach($EmployeeRevocationInfo as $key=>$value) 
         @php
  $ctr_revo++;
@endphp 
<input type="hidden" class="form-control" name="revocation_sql_id[]"  value="{{$value->id}}">
<td><input type="text" class="form-control width" name="revo_order_no[]" value="{{$value->revocation_order_no}}"></td>
<td><input type="date" class="form-control width" value="{{$value->revocation_order_date}}" name="revo_order_date[]"></td>
<td><select class="form-control width" name="ant_ord_no[]"value="{{$value->antecedent_order_no}}" >
   @foreach($antecendent_fetch as $ky=>$val)
                  <option value="{{$val->id}}"
                     {{$val->id==$value->antecedent_order_no
                          ? 'selected':''}}>{{$val->order_no}}
                  </option>      
            
             @endforeach

</select></td>
<td><select class="form-control width" name="ant_ord_dat[]"value="{{$value->antecedent_order_date}}">
        @foreach($antecendent_fetch as $ky=>$val)
                  <option value="{{$val->order_date}}"
                     {{$val->order_date==$value->antecedent_order_date
                          ? 'selected':''}}>{{$val->order_date}}
                  </option>      
            
             @endforeach
</select></td>
<td><select class="form-control width" name="ant_ord_type[]"value="{{$value->antecedent_type}}">
     <option <?php if($value->antecedent_type == 'Explanation'){ echo "selected"; } else { echo ""; } ?> value="Explanation">Explanation</option>
 <option <?php if($value->antecedent_type == 'Termination'){ echo "selected"; } else { echo ""; } ?> value="Termination">Termination</option>
  <option <?php if($value->antecedent_type == 'Warning'){ echo "selected"; } else { echo ""; } ?> value="Warning">Warning</option>
 <option <?php if($value->antecedent_type == 'Salary Deduction'){ echo "selected"; } else { echo ""; } ?> value="Salary Deduction">Salary Deduction</option>
  <option <?php if($value->antecedent_type == 'Demotion'){ echo "selected"; } else { echo ""; } ?> value="Demotion">Demotion</option>
 <option <?php if($value->antecedent_type == 'Charge Sheet'){ echo "selected"; } else { echo ""; } ?> value="Charge Sheet">Charge Sheet</option>
  <option <?php if($value->antecedent_type == 'Suspension'){ echo "selected"; } else { echo ""; } ?> value="Suspension">Suspension</option>
 <option <?php if($value->antecedent_type == 'Others'){ echo "selected"; } else { echo ""; } ?> value="Others">Others</option>
</select></td>
<td><select class="form-control width" name="ant_WEF[]"value="{{$value->antecedent_WEE_date}}">
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->WEE_date}}">{{ date('d/m/Y', strtotime($val->WEE_date)) }}</option>
      @endforeach
</select></td>
<td><select class="form-control width" name="ant_WET[]"value="{{$value->antecedent_WET_date}}">
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->WET_date}}">{{ date('d/m/Y', strtotime($val->WET_date)) }}</option>
      @endforeach
</select></td>
<td><input type="date" class="form-control" name="revo_effected_date[]"value="{{$value->revocation_effected_date}}" ></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="revo_remark[]">{{$value->remarks}}</textarea></td>

@if($value->upload!="")
<td><input type="file" class="" placeholder="67%" name="revocation_upload[]" style="width: 215px;"></td>
  <td><a href="{{ url('public/revocation/'.$value->upload) }}" download="{{ $value->upload }}"><i class="fa fa-download" style="font-size:22px;"></i></a></td>
@else
     <td><input type="file" class="" placeholder="67%" name="revocation_upload[]"></td>
     <td></td>        
@endif
<td><button type="button" onclick="deleterevocation({{$value->id}});" 
style="background-color: #7d98da">X</button></td>
</tr>
@endforeach
@if($ctr_revo==0)
<tr>
<input type="hidden" class="form-control" name="revocation_sql_id[]">

<td><input type="text" class="form-control width" name="revo_order_no[]"></td>
<td><input type="date" class="form-control width" value="13/03/2008" name="revo_order_date[]"></td>
<td><select class="form-control width" name="ant_ord_no[]">
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->order_no}}">{{$val->order_no}}</option>
      @endforeach
</select></td>
<td><select class="form-control width" name="ant_ord_dat[]">
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->order_date}}">{{$val->order_date}}</option>
      @endforeach
</select></td>
<td><select class="form-control width" name="ant_ord_type[]">
   <option>Explanation</option>
        <option>Termination</option>
        <option>Warning</option>
        <option>Salary Deduction</option>
        <option>Demotion</option>
        <option>Charge Sheet</option>
        <option>Suspension</option>
        <option>Others</option>
    </select>
</select></td>
<td><select class="form-control width" name="ant_WEF[]">
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->WEE_date}}">{{$val->WEE_date}}</option>
      @endforeach
</select></td>
<td><select class="form-control width" name="ant_WET[]">
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->WET_date}}">{{$val->WET_date}}</option>
      @endforeach
</select></td>
<td><input type="date" class="form-control" name="revo_effected_date[]" ></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="revo_remark[]"></textarea></td>
     <td><input type="file" class="" placeholder="67%" name="revocation_upload[]"></td>
     <td></td>
<td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>
</tr>


@endif

</tbody>
</table>     
</div>
</div>  
<div class="tab-pane fade" id="tab12" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<div class="offset-lg-11 col-lg-1 new" id="add_new_appreciation">ADD NEW</div>
<table class="table table-bordered table-hover"  id="table_appreciation">
<thead>
<tr>

<th>Order No:</th>
<th>Order Date:</th>
<th>Appriciation Type:</th>
<th>Recommended By</th>
<th>Description</th>
<th>Remarks</th>
<th>Upload</th>
<th>Download</th>
<th>Remove</th>


</tr>
</thead>
<tbody>
<tr>
@php 
  $ctr_revo=0;
  @endphp
   @foreach($EmployeeAppreciationInfo as $key=>$value) 
         @php
  $ctr_revo++;
@endphp 

<input type="hidden" class="form-control" name="appr_sqli_id[]" value="{{$value->id}}">
<td><input type="text" class="form-control width" name="app_order_no[]" value="{{$value->order_no}}"></td>
<td><input type="date" class="form-control width"  name="app_order_date[]" value="{{$value->order_date}}"></td>
<td><select class="form-control width" name="appreciation_type[]">
<option>--select--</option>
    <option <?php if($value->appreciation_type == 'Cost-saving'){ echo "selected"; } else { echo ""; } ?> value="Cost-saving">Cost Saving</option>
    <option <?php if($value->appreciation_type == 'Process_Improvemnt'){ echo "selected"; } else { echo ""; } ?> value="Process_Improvemnt">Process Improvemnt</option>
 
</select></td>
<td><input type="text" class="form-control width" name="recommended_by[]" value="{{$value->recommended_by}}"></td>
<td><textarea rows="3" cols="40" class="form-control" name="app_description[]" style="width:200px;">{{$value->app_description}}</textarea></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150"name="app_remarks[]">{{$value->app_remarks}}</textarea></td>
@if($value->upload!="")
<td><input type="file" class="" placeholder="67%" name="appriciation_upload[]" style="width: 215px;"></td>
  <td><a href="{{ url('public/appreciation/'.$value->upload) }}" download="{{ $value->upload }}"><i class="fa fa-download" style="font-size:22px;"></i></a></td>
@else
     <td><input type="file"  placeholder="67%" name="appriciation_upload[]"></td>
     <td></td>        
@endif
<td><button type="button" onclick="deleteAppreciation({{$value->id}});" 
style="background-color: #7d98da">X</button></td>
</tr>
@endforeach
@if($ctr_revo==0)
<tr>
  <input type="hidden" class="form-control" name="appr_sqli_id[]">
<td><input type="text" class="form-control width" name="app_order_no[]"></td>
<td><input type="date" class="form-control width"  name="app_order_date[]"></td>
<td><select class="form-control width" name="appreciation_type[]">
    <option>--select--</option>
    <option value="Cost-saving">Cost Saving</option>
    <option value="Process_Improvemnt">Process Improvemnt</option>
 
</select></td>
<td><input type="text" class="form-control width" name="recommended_by[]"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="app_description[]" style="width:200px;"></textarea></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="app_remarks[]"></textarea></td>
<td><input type="file" name="appriciation_upload[]"></td>
</tr>

@endif


   </tbody>
 </table>     
</div>
</div> 

<div class="tab-pane fade" id="tab13" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<div class="offset-lg-11 col-lg-1 new" id="add_new_reward">ADD NEW</div>
<table class="table table-bordered table-hover" id="tablereward">
<thead>
<tr>

<th>Order No:</th>
<th>Order Date:</th>
<th>Reward Type:</th>
<th>Recommended By</th>
<th>Description</th>
<th>Remarks</th>
<th>Upload</th>
<th>Download</th>
<th>Remove</th>

</tr>
</thead>
 <tbody id="table_reward">

<tr>
@php 
  $ctr_revo=0;
  @endphp
   @foreach($EmployeeRewardInfo as $key=>$value) 
         @php
  $ctr_revo++;
@endphp 

<input type="hidden" class="form-control" name="reward_sqli_id[]" value="{{$value->id}}">
<td><input type="text" class="form-control width" name="reorder_no[]" value="{{$value->reorder_no}}"></td>
<td><input type="date" class="form-control width"  name="reorder_date[]"  value="{{$value->reorder_date}}"></td>
<td><select class="form-control width" name="reward_type[]">
     <option>--select--</option>
    <option <?php if($value->reward_type == 'Cost-saving'){ echo "selected"; } else { echo ""; } ?>  value="Cost-saving">Cost Saving</option>
    <option <?php if($value->reward_type == 'Process_Improvemnt'){ echo "selected"; } else { echo ""; } ?> value="Process_Improvemnt">Process Improvemnt</option>
 
</select></td>
<td><input type="text" class="form-control width" name="re_recommended_by[]" value="{{$value->re_recommended_by}}"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="re_description[]" style="width:200px;">{{$value->re_description}}</textarea></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="re_remarks[]">{{$value->re_remarks}}</textarea></td>

@if($value->upload!="")
<td><input type="file" class="" placeholder="67%" name="remark_upload[]" style="width: 215px;"></td>
  <td><a href="{{ url('public/reward/'.$value->upload) }}" download="{{ $value->upload }}"><i class="fa fa-download" style="font-size:22px;"></i></a></td>
@else
     <td><input type="file"  placeholder="67%" name="remark_upload[]"></td>
     <td></td>        
@endif

<td><button type="button" onclick="deleteReward({{$value->id}});" 
style="background-color: #7d98da">X</button></td>
</tr>
@endforeach
@if($ctr_revo==0)

<tr>
<input type="hidden" class="form-control" name="reward_sqli_id[]" >
<td><input type="text" class="form-control width" name="reorder_no[]"></td>
<td><input type="date" class="form-control width"  name="reorder_date[]"></td>
<td><select class="form-control width" name="reward_type[]">
     <option>--select--</option>
    <option value="Cost-saving">Cost Saving</option>
    <option value="Process_Improvemnt">Process Improvemnt</option>
 
</select></td>
<td><input type="text" class="form-control width" name="re_recommended_by[]"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="re_description[]" style="width:200px;"></textarea></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="re_remarks[]"></textarea></td>
<td><input type="file" name="remark_upload[]"></td>
<td></td>
<td><button type="button" style="background-color: #7d98da">X</button></td>
</tr>
@endif


   </tbody>
 </table>     
</div>
</div> 

<div class="tab-pane fade" id="tab14" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">

<div class="offset-lg-11 col-lg-1 new" id="add_new7">ADD NEW</div>
<table class="table table-bordered table-hover" id="tableintiation">
<thead>
<tr>


<th>Initiative Date</th>
<th>Type</th>
<th>Description</th>
<th>Remarks</th>
<th>Upload</th>
<th>Download</th>
<th>Remove</th>


</tr>
</thead>
<tbody>


<tr>
@php 
$ctr_inti=0;
@endphp
   @foreach($EmployeeIntitionInfo as $key=>$value) 
@php
$ctr_inti++;
@endphp 
<input type="hidden" class="form-control" name="intiation_sql_id[]"  value="{{$value->id}}">
<td><input type="date" class="form-control width" name="initiative_date[]" value="{{$value->initiative_date}}"></td>

<td><select class="form-control width" name="inti_type[]" value="{{$value->type}}">
<option>--select--</option>
<option <?php if($value->type == 'Cost Saving'){ echo "selected"; } else { echo ""; } ?> value="Cost Saving">Cost Saving</option>
<option <?php if($value->type == 'Process Improvemnt'){ echo "selected"; } else { echo ""; } ?> value="Process Improvemnt">Process Improvemnt</option>
  </select>
</td>

<td><textarea rows="3" cols="40" class="form-control"  name="inti_description[]" style="width:200px;">{{$value->description}}</textarea></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="inti_remark[]">{{$value->remark}}</textarea></td>

@if($value->upload!="")
<td><input type="file" class="" placeholder="67%" name="Initiative_upload[]" style="width: 215px;"></td>
  <td><a href="{{ url('public/Initiative/'.$value->upload) }}" download="{{ $value->upload }}"><i class="fa fa-download" style="font-size:22px;"></i></a></td>
@else
     <td><input type="file" class="" placeholder="67%" name="Initiative_upload[]"></td>
     <td></td>        
@endif
<td><button type="button" onclick="deleteintiation({{$value->id}});" 
style="background-color: #7d98da">X</button></td>
</tr>
@endforeach
@if($ctr_inti==0)
<tr>
<input type="hidden" class="form-control" name="intiation_sql_id[]">

<td><input type="date" class="form-control width" value="13/03/2008" name="initiative_date[]"></td>
<td><select class="form-control width" name="inti_type[]">
    <option>--select--</option>
    <option>Cost Saving</option>
    <option>Process Improvemnt</option>
 
</select></td>

<td><textarea rows="3" cols="40" class="form-control"  name="inti_description[]" style="width:200px;"></textarea></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="inti_remark[]"></textarea></td>
<td><input type="file" name="Initiative_upload[]"></td>
<td></td>
<td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>
</tr>
@endif


</tbody>
 </table>     
</div>
</div>

<div class="tab-pane fade" id="tab15" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<div class="offset-lg-11 col-lg-1 new" id="add_new8">ADD NEW</div>
<table class="table table-bordered table-hover" id="tableachievemnt">
<thead>
<tr>


<th>Achievement Date</th>
<th>Achievement Type</th>
<th>Achivement Period</th>
<th>Remarks</th>
<th>Upload</th>
<th>Download</th>
<th>Remove</th>

</tr>
</thead>
<tbody>

<tr>
@php 
$ctr_achi=0;
@endphp
   @foreach($EmployeeAchievementInfo as $key=>$value) 
@php
$ctr_achi++;
@endphp 
<input type="hidden" class="form-control" name="Achievement_sql_id[]" value="{{$value->id}}">
<td><input type="date" class="form-control width"  name="achievement_date[]" value="{{$value->achievement_date}}"></td>
<td><select class="form-control width" name="achievement_type[]" value="{{$value->achievement_type}}">
    <option>--select--</option>
    <option <?php if($value->achievement_type == 'Cost Saving'){ echo "selected"; } else { echo ""; } ?> value="Cost Saving">Cost Saving</option>
<option <?php if($value->achievement_type == 'Process Improvemnt'){ echo "selected"; } else { echo ""; } ?> value="Process Improvemnt">Process Improvemnt</option>
 
 
</select></td>

<td><input type="text" class="form-control width"  name="achievement_period[]" value="{{$value->achievement_period}}"></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="achievement_remark[]">{{$value->remark}}</textarea></td>

@if($value->upload!="")
<td><input type="file" class="" placeholder="67%" name="achievement_upload[]" style="width: 215px;"></td>
  <td><a href="{{ url('public/achievement/'.$value->upload) }}" download="{{ $value->upload }}"><i class="fa fa-download" style="font-size:22px;"></i></a></td>
@else
     <td><input type="file" class="" placeholder="67%" name="achievement_upload[]"></td>
     <td></td>        
@endif
<td><button type="button" onclick="deleteachievement({{$value->id}});" 
style="background-color: #7d98da">X</button></td>
</tr>
@endforeach
@if($ctr_achi==0)
<tr>
<input type="hidden" class="form-control" name="Achievement_sql_id[]">

<td><input type="date" class="form-control width" value="13/03/2008" name="achievement_date[]"></td>
<td><select class="form-control width" name="achievement_type[]">
    <option>--select--</option>
    <option>Cost Saving</option>
    <option>Process Improvemnt</option>
 
</select></td>

<td><input type="text" class="form-control width"  name="achievement_period[]"></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="achievement_remark[]"></textarea></td>
<td><input type="file" name="achievement_upload[]"></td>
<td></td>
<td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>
</tr>
@endif
</tbody>
 </table>     
</div>
</div>                  
</div>

                    </div>
                  </div>
            
            </div>
        </div>
    </div>
</div>
</div>

</div>




            <div id="modalOptionalSizes" class="col-lg-12 layout-spacing">
                            <div class="statbox box box-shadow">
                                <div class="widget-content">
                                    <div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
                                      <div class="modal-dialog modal-xl" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myExtraLargeModalLabel">Employee List</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                  <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                                </button>
                                            </div>
                          <div class="layout-px-spacing">

                <div class="row layout-top-spacing" id="cancel-row">
                    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                        <div class="widget-content widget-content-area br-6">
                            <div class="table-responsive mb-4 mt-4">
                                <div class="offset-xl-8 col-xl-4 col-lg-4 col-sm-4" style="text-align: right;">
                                <input class="form-control" id="myInput" type="text" placeholder="Search..">
                              </div>

                                <br><br>
                                <table id="html5-extension" class="table" style="width:100%">
                                    <thead>
                                        <tr>
                                          <th>Employee No</th>
                                            <th>Employee Name</th>
                                            <th>Employee Code</th>
                                            <th>Edit</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody id="myTable">
                                  @foreach($Employee_fetch1 as $ky=>$val)
                                           <tr>
                                                <td>{{$val->emp_no}}</td>
                                                 
                                                <td>{{$val->emp_name}}</td> 
                                                <td>{{$val->employee_code}}</td>
                                                <td>    <a href="{{url('/')}}/employee_edit_master/?search_emp={{ $val->emp_no }}"  title="Edit" class="editbtn" class="btn btn-success editbtn" ><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-2 text-success"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg></a></td>
                                              
                                                 
                                            
                                            </tr>
                                             @endforeach
                                    </tbody>
                                         
                                </table>
                            </div>
                        </div>
                    </div>

                </div>

                </div>
<!--                                             <div class="modal-footer">
                                                <button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Discard</button>
                                                <button type="button" class="btn btn-primary">Save</button>
                                            </div> -->
                                        </div>
                                      </div>
                                    </div>
        
       
                                </div>
                            </div>
                        </div>




            <div id="modalOptionalSizes" class="col-lg-6 layout-spacing">
                            <div class="statbox box box-shadow">
                                <div class="widget-content">
                                    <div class="modal fade bd-example-modal" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
                                      <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                               <!--  <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                                                  <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                                </button> -->
                                    
                                                    <div class="modal-body">
                       <form action=""  method="post">
                   
                   <div class="form-group">
                            
                              <input type="hidden" class="form-control" name="pro_id" id="pro_id" aria-describedby="textHelp">
                              
                            </div>
                            <div class="form-group">
                              <label for="exampleInputtext1">Board/University Name</label>
                              <input type="text" class="form-control" id="pro_name" name="pro_name" aria-describedby="textHelp">
                              
                            </div>
                           
                             <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Add</button>
                      </div>
                          
                          
                       
                          </form>
                      
                      </div>
                                       
                                        </div>
                                      </div>
                                    </div>
        
       
                                </div>
                            </div>
                        </div></div></div>
                        </form>
        <!--  END CONTENT AREA  -->
</div>
 <script>
var v = 0;  
    function transfer(id){
    var transfer_id = $('#transferid'+id).val();
    if(id>=v){
        $('#selectdepartment').val(transfer_id);
        v=id;
    }
    }
    var w = 0;  
    function transferWork(id){
    var work_id = $('#transferWorkid'+id).val();
    console.log(work_id);
    if(id>=w){
        $('#selectWorkplace').val(work_id);
        w=id;
    }
} 
var p = 0;  
    function portionDropdown(id){
    var portion_id = $('#portionDropdownid'+id).val();
    console.log(portion_id);
    if(id>=p){
        $('#selectdesignation').val(portion_id);
        p=id;
    }
} 
  function promotion(id)
{
 // alert(id);
      var pkid = $('#promotionid'+id).val();
      // alert(pkid);
      $('#promotionid'+id).val(pkid);
     $.ajax({
         type:'POST',
          url: "{{url('/getPromotion')}}",
          dataType: "json",
         data:{
       '_token':$('input[name=_token]').val(),        
       'selectedid': pkid
        },
        success: function(data){
         // console.log(data);
         $('#catch_paygrade_value'+id).val(data[0].pay_scale);
         $('#promtion_current_allowance'+id).val(data[0].special_allowance);
         $('#promtion_currentother_allowance'+id).val(data[0].other_special_allowance);
          }

      });
 // alert(id);
}
function topromotion(id)
{
   var pkid = $('#promotiontoid'+id).val();
    $.ajax({
         type:'POST',
          url: "{{url('/gettoPromotion')}}",
          dataType: "json",
         data:{
       '_token':$('input[name=_token]').val(),        
       'selectedid': pkid
        },
        success: function(data){
         // console.log(data);
         $('#catch_topaygrade_value'+id).val(data[0].pay_scale);
         $('#promtion_tocurrent_allowance'+id).val(data[0].special_allowance);
         $('#promtion_tocurrentother_allowance'+id).val(data[0].other_special_allowance);
          }

      });
}
  function probation(id)
{
      var pkid = $('#probationid'+id).val();
       //alert(pkid);
      $('#probationid'+id).val(pkid);
     $.ajax({
         type:'POST',
          url: "{{url('/getProbation')}}",
          dataType: "json",
         data:{
       '_token':$('input[name=_token]').val(),        
       'selectedid': pkid
        },
        success: function(data){
         // console.log(data);
         $('#promotion_catch_topaygrade_value'+id).val(data[0].pay_scale);
         $('#probation_current_allowance'+id).val(data[0].special_allowance);
         $('#probation_tocurrentother_allowance'+id).val(data[0].other_special_allowance);
          }

      });
 // alert(id);
} 
 function deletedependent(did)
    {
      var conf = confirm("Do you want to delete this permanetly?");
      if(conf)
      {
      var token = '{{ csrf_token() }}';
      var dependent_id = did;
      console.log(dependent_id)
        $.ajax({
            url: "{{url('/delete_dependent')}}",
            type: "POST",
            data: {'_token': token,'did':dependent_id},
            dataType: "json",
            success: function (data)
            { //alert(data);
                if(data=='1')
                {
                     window.location.reload();
                }else 
                {
                return false;
            }
            },
        });
      }
    }
    function deletequalification(qid)
    {
      var conf = confirm("Do you want to delete this permanetly?");
      if(conf)
      {
      var token = '{{ csrf_token() }}';
      var qualification_id = qid;
      //console.log(dependent_id)
        $.ajax({
            url: "{{url('/delete_qualification')}}",
            type: "POST",
            data: {'_token': token,'qid':qualification_id},
            dataType: "json",
            success: function (data)
            { //alert(data);
                if(data=='1')
                {
                     window.location.reload();
                }else 
                {
                return false;
            }
            },
        });
      }
    }
    function deleteorganization(qid)
    {
      var conf = confirm("Do you want to delete this permanetly?");
      if(conf)
      {
      var token = '{{ csrf_token() }}';
      var qualification_id = qid;
      //console.log(dependent_id)
        $.ajax({
            url: "{{url('/delete_organization')}}",
            type: "POST",
            data: {'_token': token,'qid':qualification_id},
            dataType: "json",
            success: function (data)
            { //alert(data);
                if(data=='1')
                {
                     window.location.reload();
                }else 
                {
                return false;
            }
            },
        });
      }
    }
    function deletetransfer(qid)
    {
      var conf = confirm("Do you want to delete this permanetly?");
      if(conf)
      {
      var token = '{{ csrf_token() }}';
      var qualification_id = qid;
      //console.log(dependent_id)
        $.ajax({
            url: "{{url('/delete_transfer')}}",
            type: "POST",
            data: {'_token': token,'qid':qualification_id},
            dataType: "json",
            success: function (data)
            { //alert(data);
                if(data=='1')
                {
                     window.location.reload();
                }else 
                {
                return false;
            }
            },
        });
      }
    }
    //promotion
    function deletepromotion(pid)
    {
      var conf = confirm("Do you want to delete this permanetly?");
      if(conf)
      {
      var token = '{{ csrf_token() }}';
      var promotion_id = pid;
      //console.log(dependent_id)
        $.ajax({
            url: "{{url('/delete_promotion')}}",
            type: "POST",
            data: {'_token': token,'pid':promotion_id},
            dataType: "json",
            success: function (data)
            { //alert(data);
                if(data=='1')
                {
                     window.location.reload();
                }else 
                {
                return false;
            }
            },
        });
      }
    }
    //probation
    function deleteprobation(pid)
    {
      var conf = confirm("Do you want to delete this permanetly?");
      if(conf)
      {
      var token = '{{ csrf_token() }}';
      var promotion_id = pid;
      //console.log(dependent_id)
        $.ajax({
            url: "{{url('/delete_probation')}}",
            type: "POST",
            data: {'_token': token,'pid':promotion_id},
            dataType: "json",
            success: function (data)
            { //alert(data);
                if(data=='1')
                {
                     window.location.reload();
                }else 
                {
                return false;
            }
            },
        });
      }
    }
    function deletecontract(cid)
    {
      var conf = confirm("Do you want to delete this permanetly?");
      if(conf)
      {
      var token = '{{ csrf_token() }}';
      var contract_id = cid;
      //console.log(dependent_id)
        $.ajax({
            url: "{{url('/delete_contract')}}",
            type: "POST",
            data: {'_token': token,'cid':contract_id},
            dataType: "json",
            success: function (data)
            { //alert(data);
                if(data=='1')
                {
                     window.location.reload();
                }else 
                {
                return false;
            }
            },
        });
      }
    }
    function deleteantecedent(cid)
    {
      var conf = confirm("Do you want to delete this permanetly?");
      if(conf)
      {
      var token = '{{ csrf_token() }}';
      var contract_id = cid;
      //console.log(dependent_id)
        $.ajax({
            url: "{{url('/delete_antecedent')}}",
            type: "POST",
            data: {'_token': token,'cid':contract_id},
            dataType: "json",
            success: function (data)
            { //alert(data);
                if(data=='1')
                {
                     window.location.reload();
                }else 
                {
                return false;
            }
            },
        });
      }
    }
    function deleterevocation(cid)
    {
      var conf = confirm("Do you want to delete this permanetly?");
      if(conf)
      {
      var token = '{{ csrf_token() }}';
      var contract_id = cid;
      //console.log(dependent_id)
        $.ajax({
            url: "{{url('/delete_revocation')}}",
            type: "POST",
            data: {'_token': token,'cid':contract_id},
            dataType: "json",
            success: function (data)
            { //alert(data);
                if(data=='1')
                {
                     window.location.reload();
                }else 
                {
                return false;
            }
            },
        });
      }
    }
    function deleteintiation(inti_id)
    {
      //salert(inti_id);
      var conf = confirm("Do you want to delete this permanetly?");
      if(conf)
      {
      var token = '{{ csrf_token() }}';
      var intiation_id = inti_id;
      //console.log(dependent_id)
        $.ajax({
            url: "{{url('/delete_intiation')}}",
            type: "POST",
            data: {'_token': token,'inti_id':intiation_id},
            dataType: "json",
            success: function (data)
            { //alert(data);
                if(data=='1')
                {
                     window.location.reload();
                }else 
                {
                return false;
            }
            },
        });
      }
    }
        function deleteachievement(achievement_id)
    {
      //alert(achievement_id);
      var conf = confirm("Do you want to delete this permanetly?");
      if(conf)
      {
      var token = '{{ csrf_token() }}';
      var achievement_id = achievement_id;
      //console.log(dependent_id)
        $.ajax({
            url: "{{url('/deleteachievement')}}",
            type: "POST",
            data: {'_token': token,'achievement_id':achievement_id},
            dataType: "json",
            success: function (data)
            { //alert(data);
                if(data=='1')
                {
                     window.location.reload();
                }else 
                {
                return false;
            }
            },
        });
      }
    }
    function deleteAppreciation(cid)
    {
      var conf = confirm("Do you want to delete this permanetly?");
      if(conf)
      {
      var token = '{{ csrf_token() }}';
      var contract_id = cid;
      //console.log(dependent_id)
        $.ajax({
            url: "{{url('/delete_appreciation')}}",
            type: "POST",
            data: {'_token': token,'cid':contract_id},
            dataType: "json",
            success: function (data)
            { //alert(data);
                if(data=='1')
                {
                     window.location.reload();
                }else 
                {
                return false;
            }
            },
        });
      }
    }

function deleteReward(cid)
    {
      var conf = confirm("Do you want to delete this permanetly?");
      if(conf)
      {
      var token = '{{ csrf_token() }}';
      var contract_id = cid;
      //console.log(dependent_id)
        $.ajax({
            url: "{{url('/delete_reward')}}",
            type: "POST",
            data: {'_token': token,'cid':contract_id},
            dataType: "json",
            success: function (data)
            { //alert(data);
                if(data=='1')
                {
                     window.location.reload();
                }else 
                {
                return false;
            }
            },
        });
      }
    }
 </script> 
   
<script>
    $(function(){
        $("#board_name_ajax_id").select2();
        $(".select2_dynamic").select2();
    });
function showfield(name){
//  alert(name);
    if(name != 'active') {
      $(".r_class").show();
       $("#reason,#r_dob,#r_txtReason").prop("disabled",false);  
    }else{
       $(".r_class").hide();  
       $("#reason,#r_dob,#r_txtReason").prop("disabled",true);
    }
 
}
</script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script>

  $(document).on('change', '#packageid', function(e) { 
       e.preventDefault(); 
       var pkid = $(this).val();
       //alert(pkid);
     $.ajax({
         type:'POST',
          url: "{{url('/getPackage')}}",
          dataType: "json",
         data:{
       '_token':$('input[name=_token]').val(),        
       'selectedid': pkid
        },
        success: function(data){
          if(data!=""){
         $('#catch_value').val(data[0].pay_scale);
         $('#current_allowance').val(data[0].special_allowance);
         $('#initial_allowance').val(data[0].special_allowance);
         $('#initial_other').val(data[0].other_special_allowance);
         $('#cuurent_other').val(data[0].other_special_allowance);
           }
          else{
           $('#catch_value').val("");
           $('#current_allowance').val("");
           $('#initial_allowance').val("");
           $('#initial_other').val("");
           $('#cuurent_other').val("");
           }

      }
   });
 });
      $(function () {
        $("#ddlModels").change(function () {
            if ($(this).val() == 'Married') {
                $("#spouseName").prop("disabled", false).focus();
                $("#spouseDOB").prop("disabled", false);
            } else {
                $("#spouseName").prop("disabled", true).val("");
                $("#spouseDOB").prop("disabled", true).val("");
            }
        });
    });
</script>

  <script>
    $(document).ready(function () {
       let ms = $("#ddlModels").val();
      if (ms == 'Married') {
                $("#spouseName").prop("disabled", false).focus();
                $("#spouseDOB").prop("disabled", false);
            } else {
                $("#spouseName").prop("disabled", true).val("");
                $("#spouseDOB").prop("disabled", true).val("");
            }
      // Denotes total number of rows
      var rowIdx = 0;
  
      // jQuery button click event to add a row
      $('#addBtn').on('click', function () {
  
        // Adding a row inside the tbody.
        $('#tbody').append(`<tr id="R${++rowIdx}">
                 <p>Row ${rowIdx}</p>
<td>
<input type="hidden" class="form-control width" name="antecedent_sql_id[]">
<input type="text" class="form-control width" name="ante_order_no[]"></td>
<td><input type="date" class="form-control" value="13/03/2008" name="ante_order_date[]"></td>
<td>   <select class="form-control  width" name="ante_type[]">
        <option>Explanation</option>
        <option>Termination</option>
        <option>Warning</option>
        <option>Salary Deduction</option>
        <option>Demotion</option>
        <option>Charge Sheet</option>
        <option>Suspension</option>
        <option>Others</option>
    </select></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="ante_w_e_e[]"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="ante_w_e_t[]"></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="ante_remarks[]"></textarea></td>
 <td><input type="file" class="" placeholder="67%" name="antecedent_upload[]"></td>
     <td></td>  

<td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>

</tr>`
              );
      });
  
      // jQuery button click event to remove a row.
      $('#tbody').on('click', '.remove', function () {
  
        // Getting all the rows next to the row
        // containing the clicked button
        var child = $(this).closest('tr').nextAll();
  
        // Iterating across all the rows 
        // obtained to change the index
        child.each(function () {
  
          // Getting <tr> id.
          var id = $(this).attr('id');
  
          // Getting the <p> inside the .row-index class.
          var idx = $(this).children('.row-index').children('p');
  
          // Gets the row number from <tr> id.
          var dig = parseInt(id.substring(1));
  
          // Modifying row index.
          idx.html(`Row ${dig - 1}`);
  
          // Modifying row id.
          $(this).attr('id', `R${dig - 1}`);
        });
  
  
      });
    });

  let l=<?=$counter?>;
    
$("#addBtn1").click(function () { 
  l++;
  $("#e-body").append(`<tr>
    <input type="hidden" class="form-control" name="depedent_sql_id[]">
<td class="td2"><input type="text" class="form-control width" name="name[]" placeholder=""  ></td>
<td><select class="form-control nm" name="dependent_type[] "style="width: 124px" id="one${l}" onchange="nominee_select(this.value,${l})" >
    <option value="Dependent">Dependent</option>
    <option value="Nominee" >Nominee</option></select></td>
<td><input type="date" class="form-control" name="dob1[]" placeholder="enter DOB"></td>
<td><input type="number" class="form-control  td1"  name="age[]" ></td>
<td class="td2"><input type="text" class="form-control width" name="relation[]" placeholder="enter your relation" style="    width: 207px;"></td>
<td  class="td2"><input type="number" class="form-control width" name="num[]" placeholder="enter adhara"  style="    width: 207px;"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="dependent_addr[]" style="width:200px;"></textarea></td>
<td><input type="file" class="" placeholder="67%" name="dependent_file[]" multiple></td>
<td></td>
<td>
   <button type="button" class="deletebtn" title="Remove row" style="background-color: #7d98da">X</button>
</td>

</tr>`);

});
 var dept_select = "";
$(function(){
  let c = {{$counter}};
  for(let h = 0;h<=c;h++){
    if($("#one"+h).val()=="Nominee"){
       dept_select = "Nominee";
       break;
     }else{
       dept_select = "";
     }
  }
})
//alert(l);. 
// dept_select="";  
function nominee_select(dependent_type,dept_selector){
//   if($(".nm").val() ==  "Nominee"){
//   dept_select = "Nominee";
//     alert(1);
// }else{
 

// }
  //alert(dept_select);
    if(dept_select=="" && dependent_type=="Nominee")
    {
       $("#one"+dept_selector+" option[value='Nominee']").attr('selected',true);
       dept_select = "Nominee";
    }
    else if(dept_select!="" && dependent_type=="Nominee")
    {
      alert("Nominee has already selected");
      // $("#one"+dept_selector+" option[value='Dependent']").attr('selected',true);
      $("#one"+dept_selector).val("Dependent");
    }
    else if(dept_select!="" && $("#one"+dept_selector+" :selected").text()=="Nominee")
    {
        $("#one"+dept_selector+" option[value='Dependent']").attr('selected',true);
        dept_select = "";
    }else if( dependent_type=="Dependent"){
       dept_select = "";
    }

  }

   
     $(document).ready(function () {
  
      // Denotes total number of rows
      var rowIdx = 0;
  
      // jQuery button click event to add a row
      $('#addBtnQual').on('click', function () {
  
        // Adding a row inside the tbody.
        $('#e-body_qual').append(`<tr id="R${++rowIdx}">
                 <p>Row ${rowIdx}</p>

 <input type="hidden" name="qlf_hiddenSqlid[]"> 
  <td><select class="form-control" name="academic[]">
      <option>Primary</option>
      <option>Upper Primary</option>
      <option>Minor</option>
      <option>Under Matric</option>
      <option>Intermediate</option>
      <option>Graduate</option>
      <option>Post-Graduate</option>
      <option>M-Phill </option>
      <option>PHD</option>
      <option>MS</option>
      <option>Certificate</option>
      <option>Diploma</option>
      <option>Post-Diploma</option>
      <option>PG-Diploma</option>
      <option>Others</option>
  
      </select></td>
  <td><input type="text" class="form-control width" placeholder="Arts" name="stream[]"></td>
  <td>
       <div class="container box">
          <input type="text" class="form-control" name="board_name_ajax1[]" value="" style="    width: 409px;margin-left: -16px;">
      <div id="boardList">
  
    </div>

</td>
  <td><input type="text" class="form-control" placeholder="1890" name="year[]"></td>
  <td><input type="text" class="form-control" name="per_mark[]" style="width:54px"></td>
  <td><input type="text" class="form-control width2" placeholder="" name="division_qualification[]"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="remark_qualification[]" style="width:200px;"></textarea></td>
  <td><input type="file" class="" placeholder="67%" name="qualification_file[]"></td>
  <td></td>
  <td><button type="button" class="deletebtn" title="Remove row" style="background-color: #7d98da">X</button></td>
</tr>`
              );
      });
  
      // jQuery button click event to remove a row.
      $('#e-body_qual').on('click', '.remove', function () {
  
        // Getting all the rows next to the row
        // containing the clicked button
        var child = $(this).closest('tr').nextAll();
  
        // Iterating across all the rows 
        // obtained to change the index
        child.each(function () {
  
          // Getting <tr> id.
          var id = $(this).attr('id');
  
          // Getting the <p> inside the .row-index class.
          var idx = $(this).children('.row-index').children('p');
  
          // Gets the row number from <tr> id.
          var dig = parseInt(id.substring(1));
  
          // Modifying row index.
          idx.html(`Row ${dig - 1}`);
  
          // Modifying row id.
          $(this).attr('id', `R${dig - 1}`);
        });
  
  
      });
    });




      $(document).ready(function () {
  
      // Denotes total number of rows
      var rowIdx = 0;
  
      // jQuery button click event to add a row
      $('#addBtn2').on('click', function () {
  
        // Adding a row inside the tbody.
        $('#experience_body').append(`<tr id="R${++rowIdx}">
                 <p>Row ${rowIdx}</p>
<td><input type="hidden" class="form-control" name="experience_sql_id[]"><input type="text" class="form-control" placeholder="The Samad"  name="orgn[]" style="width: 255px;"></td>
<td><input type="text" class="form-control width2" placeholder="Media" name="sect[]"></td>
<td><input type="text" class="form-control width2" placeholder="Editor" name="pos[]"></td>
<td><input type="date" class="form-control" placeholder="01/03/2015" name="from[]"></td>
<td><input type="date" class="form-control" placeholder="01/03/2017" name="to[]"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="area[]"></textarea></td>
<td><textarea rows="3" cols="40" class="form-control"  name="remark_area[]" style="width:250px;"></textarea></td>
<td><input type="file" name="e_file[]"></td>
  <td></td>
 <td><button type="button" class="deletebtn" title="Remove row" style="background-color: #7d98da">X</button></td>
</tr>`
              );
      });
  
      // jQuery button click event to remove a row.
      $('#experience_body').on('click', '.remove', function () {
  
        // Getting all the rows next to the row
        // containing the clicked button
        var child = $(this).closest('tr').nextAll();
  
        // Iterating across all the rows 
        // obtained to change the index
        child.each(function () {
  
          // Getting <tr> id.
          var id = $(this).attr('id');
  
          // Getting the <p> inside the .row-index class.
          var idx = $(this).children('.row-index').children('p');
  
          // Gets the row number from <tr> id.
          var dig = parseInt(id.substring(1));
  
          // Modifying row index.
          idx.html(`Row ${dig - 1}`);
  
          // Modifying row id.
          $(this).attr('id', `R${dig - 1}`);
        });
  
  
      });
    });
     $(document).ready(function () {
  
  // Denotes total number of rows
  var rowIdx = 0;

  // jQuery button click event to add a row
  $('#add_new_appreciation').on('click', function () {

    // Adding a row inside the tbody.
    $('#table_appreciation').append(`<tr id="R${++rowIdx}">
             <p>Row ${rowIdx}</p>
             <input type="hidden" class="form-control" name="appr_sqli_id[]">
             <td><input type="text" class="form-control width" name="app_order_no[]"></td>
<td><input type="date" class="form-control width"  name="app_order_date[]"></td>
<td><select class="form-control width" name="appreciation_type[]">
    <option>--select--</option>
    <option value="Cost-saving">Cost Saving</option>
    <option value="Process_Improvemnt">Process Improvemnt</option>
 
</select></td>
<td><input type="text" class="form-control width" name="recommended_by[]"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="app_description[]" style="width:200px;"></textarea></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="app_remarks[]"></textarea></td>
<td><input type="file" name="appriciation_upload[]"></td>
 <td></td>  

<td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>

</tr>`
          );
  });

  // jQuery button click event to remove a row.
  $('#table_appreciation').on('click', '.remove', function () {

    // Getting all the rows next to the row
    // containing the clicked button
    var child = $(this).closest('tr').nextAll();

    // Iterating across all the rows 
    // obtained to change the index
    child.each(function () {

      // Getting <tr> id.
      var id = $(this).attr('id');

      // Getting the <p> inside the .row-index class.
      var idx = $(this).children('.row-index').children('p');

      // Gets the row number from <tr> id.
      var dig = parseInt(id.substring(1));

      // Modifying row index.
      idx.html(`Row ${dig - 1}`);

      // Modifying row id.
      $(this).attr('id', `R${dig - 1}`);
    });


  });
});

var j=20;
      $("#add_newtransferno").click(function () {  
        j++;
    $("#table_transfer").append(`<tr>
       <input type="hidden" class="form-control" name="transfer_sql_id[]">
    <td><input type="text" class="form-control width" width="130px" name="trans_order[]"></td>
<td> <select class="form-control width" name="order_type[]" >
        <option>Transfer</option>
        <option>Deputation</option>
    </select></td>
<td><input type="date"  class="form-control" placeholder="05/03/2009" width="130px" name="transfer_ord_date[]"></td>
<td><input type="date"  class="form-control" placeholder="13/03/2008" name="from_date[]"></td>
<td><input type="date" class="form-control" placeholder="13/03/2008" name="to_date[]" ></td>
<td> <select class="form-control width"  name="f_dept[]">
<option>Select</option>
     @foreach($Department_fetch as $ky=>$val)
    <option value="{{$val->dept_no}}">{{$val->dept_name}}</option>
        @endforeach
  </select>
</td>
<td><select class="form-control width" name="t_dept[]" onchange="transfer(${j})"  id="transferid${j}">
<option>Select</option>
     @foreach($Department_fetch as $ky=>$val)

    <option value="{{$val->dept_no}}">{{$val->dept_name}}</option>
        @endforeach
  </select></td>
<td><select class="form-control width" name="from_work[]">
<option>Select</option>
@foreach($Workplace_fetch as $ky=>$val)

     <option value="{{$val->id}}">{{$val->workplace_name}}</option>
 @endforeach
</select></td>
<td><select class="form-control width" name="to_work[]"  onchange="transferWork(${j})"  id="transferWorkid${j}">
<option>Select</option>
@foreach($Workplace_fetch as $ky=>$val)
     <option value="{{$val->id}}">{{$val->workplace_name}}</option>
 @endforeach
</select></td>

<td> <select class="form-control width"   name="ord_rea[]">
        <option>Select</option>
        <option>Reward</option>
        <option>Routine</option>
        <option>Displinary</option>
        <option>Other</option>
    </select></td>
<td><textarea rows="3" cols="40" class="form-control width" name="reamrks[]"></textarea></td>
<td><input type="file" name="trans_file[]" ></td>
<td></td>

<td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>
              
                </tr>`);
           
});

     $(document).ready(function () {
  
  // Denotes total number of rows
  var rowIdx = 0;

  // jQuery button click event to add a row
  $('#add_new_reward').on('click', function () {

    // Adding a row inside the tbody.
    $('#table_reward').append(`<tr id="R${++rowIdx}">
             <p>Row ${rowIdx}</p>
<input type="hidden" class="form-control" name="reward_sqli_id[]">
<td><input type="text" class="form-control width" name="reorder_no[]"></td>
<td><input type="date" class="form-control width"  name="reorder_date[]"></td>
<td><select class="form-control width" name="reward_type[]">
     <option>--select--</option>
    <option value="Cost-saving">Cost Saving</option>
    <option value="Process_Improvemnt">Process Improvemnt</option>
</select></td>
<td><input type="text" class="form-control width" name="re_recommended_by[]"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="re_description[]" style="width:200px;"></textarea></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="re_remarks[]"></textarea></td>
<td><input type="file" name="remark_upload[]"></td>
<td></td>

<td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>
</tr>`
          );
  });

  // jQuery button click event to remove a row.
  $('#table_reward').on('click', '.remove', function () {

    // Getting all the rows next to the row
    // containing the clicked button
    var child = $(this).closest('tr').nextAll();

    // Iterating across all the rows 
    // obtained to change the index
    child.each(function () {

      // Getting <tr> id.
      var id = $(this).attr('id');

      // Getting the <p> inside the .row-index class.
      var idx = $(this).children('.row-index').children('p');

      // Gets the row number from <tr> id.
      var dig = parseInt(id.substring(1));

      // Modifying row index.
      idx.html(`Row ${dig - 1}`);

      // Modifying row id.
      $(this).attr('id', `R${dig - 1}`);
    });


  });
}); 
var k=20;
$("#add_newpromotion").click(function () {
k++; 
//alert(k);
  $("#promo_tbl").append(`<tr>

<input type="hidden" class="form-control" name="promotion_sql_id[]">
<td><input type="text" class="form-control width" name="promo_order_no[]"></td>
<td><input type="date" class="form-control" name="promo_date[]"></td>
<td><input type="date" class="form-control" placeholder="13/03/2008" name="effect_date[]"></td>
<td>
<select class="form-control " onchange="promotion(${k})"  id="promotionid${k}" name="from_grade[]" style="width: 202px;">
   <option value="">--Select--</option>
       @foreach($pay_grade_view as $ky=>$val)
        <option value="{{$val->id}}">{{$val->pay_grade_desc}}
        </option>
       @endforeach
</select>
</td>
<td><select class="form-control width"   name="from_design[]">
<option value="">--Select--</option>
                                    @foreach($Designation as $ky=>$val)
                                              <option value="{{$val->desg_code}}">{{$val->desg_name}}</option>
                                           @endforeach
</select></td>

<td><input type="text" class="form-control width" name="from_basic[]" id='catch_paygrade_value${k}' style="    width: 202px;" readonly></td>
<td><input type="number" class="form-control width" name="from_special[]" id="promtion_current_allowance${k}" readonly ></td>
<td><input type="number" class="form-control width" name="from_other_special[]"  id="promtion_currentother_allowance${k}" readonly ></td>
<td> <select class="form-control "  onchange="topromotion(${k})" id="promotiontoid${k}" name="to_grade[]" style="width: 202px;">
   <option value="">--Select--</option>
       @foreach($pay_grade_view as $ky=>$val)
        <option value="{{$val->id}}">{{$val->pay_grade_desc}}
        </option>
       @endforeach
</select>
</td>
<td>
<select class="form-control width"   name="to_portion[]" onchange="portionDropdown(${k})"  id="portionDropdownid${k}">
<option value="">--Select--</option>
                                    @foreach($Designation as $ky=>$val)
                                              <option value="{{$val->desg_code}}">{{$val->desg_name}}</option>
                                           @endforeach
</select></td>
<td><input type="text" class="form-control width" name="to_basic[]" id='catch_topaygrade_value${k}'readonly></td>
<td><input type="number" class="form-control width" name="total_allow[]" id="promtion_tocurrent_allowance${k}" readonly></td>
<td><input type="number" class="form-control width" name="to_other_allowance[]" id="promtion_tocurrentother_allowance${k}"readonly></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remark[]"></textarea></td>
<td><input type="file" name="upload_promo[]"></td>
<td></td>
<td><button type="button" style="background-color: #7d98da">X</button></td>
</tr>`);
});

var i=20;
$("#add_newprobation").click(function () { 
  i++;
  $("#probationtable").append(`<tr>
<input type="hidden" name="prob_sqli_id[]">
<td><input type="text" class="form-control width" name="prob_order[]"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="prob_start[]"></td>
<td><input type="date" class="form-control"  placeholder="13/07/2008" name="prob end[]"></td>
<td>
<select class="form-control " onchange="probation(${i})"  id="probationid${i}" name="pay_grade1[]" style="width: 202px;">
   <option value="">--Select--</option>
       @foreach($pay_grade_view as $ky=>$val)
        <option value="{{$val->id}}">{{$val->pay_grade_desc}}
        </option>
       @endforeach
</select></td>
<td><input type="text" class="form-control width2" name="initial[]" id="promotion_catch_topaygrade_value${i}"  readonly="readonly" style="width: 219px;"></td>
<td><input type="number" class="form-control width2" name="special_allowance[]"id="probation_current_allowance${i}" readonly="readonly"></td>
<td><input type="number" class="form-control width2" name="other_allownace[]"id="probation_tocurrentother_allowance${i}" readonly="readonly" ></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remark_prob[]"></textarea></td>
<td><input type="file" name="prob_upload[]"></td>
<td></td>
<td><button type="button" style="background-color: #7d98da">X</button></td>
</tr>`);

}); 
    // revocation
    $(document).ready(function () {

// Denotes total number of rows
var rowIdx = 0;

// jQuery button click event to add a row
$('#add_new_revocation').on('click', function () {

// Adding a row inside the tbody.
$('#maintable_dependent_revocation').append(`<tr id="R${++rowIdx}">
<p>Row ${rowIdx}</p>
<input type="hidden" class="form-control width" name="revocation_sql_id[]">

<<input type="hidden" class="form-control" name="revocation_sql_id[]">

<td><input type="text" class="form-control width" name="revo_order_no[]"></td>
<td><input type="date" class="form-control width" value="13/03/2008" name="revo_order_date[]"></td>
<td><select class="form-control width" name="ant_ord_no[]">
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->id}}">{{$val->order_no}}</option>
      @endforeach
</select></td>
<td><select class="form-control width" name="ant_ord_dat[]">
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->order_date}}">{{$val->order_date}}</option>
      @endforeach
</select></td>
<td><select class="form-control width" name="ant_ord_type[]">
   <option>Explanation</option>
        <option>Termination</option>
        <option>Warning</option>
        <option>Salary Deduction</option>
        <option>Demotion</option>
        <option>Charge Sheet</option>
        <option>Suspension</option>
        <option>Others</option>
    </select>
</select></td>
<td><select class="form-control width" name="ant_WEF[]">
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->WEE_date}}">{{$val->WEE_date}}</option>
      @endforeach
</select></td>
<td><select class="form-control width" name="ant_WET[]">
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->WET_date}}">{{$val->WET_date}}</option>
      @endforeach
</select></td>
<td><input type="date" class="form-control" name="revo_effected_date[]" ></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="revo_remark[]"></textarea></td>
   <td><input type="file" class="" placeholder="67%" name="revocation_upload[]"></td>
   <td></td>
<td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>

</tr>`
);
});

// jQuery button click event to remove a row.
$('#maintable_dependent_revocation').on('click', '.remove', function () {

// Getting all the rows next to the row
// containing the clicked button
var child = $(this).closest('tr').nextAll();

// Iterating across all the rows
// obtained to change the index
child.each(function () {

// Getting <tr> id.
var id = $(this).attr('id');

// Getting the <p> inside the .row-index class.
var idx = $(this).children('.row-index').children('p');

// Gets the row number from <tr> id.
var dig = parseInt(id.substring(1));

// Modifying row index.
idx.html(`Row ${dig - 1}`);

// Modifying row id.
$(this).attr('id', `R${dig - 1}`);
});


});
});  
//contract
$(document).ready(function () {

// Denotes total number of rows
var rowIdx = 0;

// jQuery button click event to add a row
$('#add_new_contract').on('click', function () {

// Adding a row inside the tbody.
$('#tbody_contract').append(`<tr id="R${++rowIdx}">
<p>Row ${rowIdx}</p>

<td>
<input type="hidden"  name="contract_sqli_id[]"  class="form-control" >
<input type="text" class="form-control width" name="cont_order[]"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="cont_start_date[]"></td>
<td><input type="date" class="form-control" value="13/03/2008" name="cont_end_date[]"></td>
<td><input type="number" class="form-control width2" name="con_pay[]"></td>
<td><input type="number" class="form-control width2" name="special[]"></td>
<td><input type="number" class="form-control width2" name="other[]"></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remarks[]"></textarea></td>

<td><input type="file" name="cont_file[]"></td>
<td></td>
<td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>


</tr>`
);
});

// jQuery button click event to remove a row.
$('#tbody_contract').on('click', '.remove', function () {

// Getting all the rows next to the row
// containing the clicked button
var child = $(this).closest('tr').nextAll();

// Iterating across all the rows
// obtained to change the index
child.each(function () {

// Getting <tr> id.
var id = $(this).attr('id');

// Getting the <p> inside the .row-index class.
var idx = $(this).children('.row-index').children('p');

// Gets the row number from <tr> id.
var dig = parseInt(id.substring(1));

// Modifying row index.
idx.html(`Row ${dig - 1}`);

// Modifying row id.
$(this).attr('id', `R${dig - 1}`);
});


});
});
$(document).ready(function () {
  
      // Denotes total number of rows
      var rowIdx = 0;
  
      // jQuery button click event to add a row
      $('#add_new7').on('click', function () {
  
        // Adding a row inside the tbody.
        $('#tableintiation').append(`<tr id="R${++rowIdx}">
                 <p>Row ${rowIdx}</p>
<td><input type="hidden" class="form-control" name="intiation_sql_id[]">

<input type="date" class="form-control width" value="13/03/2008" name="initiative_date[]"></td>
<td><select class="form-control width" name="inti_type[]">
    <option>--select--</option>
    <option>Cost Saving</option>
    <option>Process Improvemnt</option>
 
</select></td>

<td><textarea rows="3" cols="40" class="form-control"  name="inti_description[]" style="width:200px;"></textarea></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="inti_remark[]"></textarea></td>
<td><input type="file" name="Initiative_upload[]"></td>
<td></td>
<td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>
</tr>`
              );
      });
  
      // jQuery button click event to remove a row.
      $('#tableintiation').on('click', '.remove', function () {
  
        // Getting all the rows next to the row
        // containing the clicked button
        var child = $(this).closest('tr').nextAll();
  
        // Iterating across all the rows 
        // obtained to change the index
        child.each(function () {
  
          // Getting <tr> id.
          var id = $(this).attr('id');
  
          // Getting the <p> inside the .row-index class.
          var idx = $(this).children('.row-index').children('p');
  
          // Gets the row number from <tr> id.
          var dig = parseInt(id.substring(1));
  
          // Modifying row index.
          idx.html(`Row ${dig - 1}`);
  
          // Modifying row id.
          $(this).attr('id', `R${dig - 1}`);
        });
  
  
      });
    }); 
    //probation 



    $(document).ready(function () {
  
      // Denotes total number of rows
      var rowIdx = 0;
  
      // jQuery button click event to add a row
      $('#add_new8').on('click', function () {
  
        // Adding a row inside the tbody.
        $('#tableachievemnt').append(`<tr id="R${++rowIdx}">
                 <p>Row ${rowIdx}</p>
<td><input type="hidden" class="form-control" name="Achievement_sql_id[]">

<input type="date" class="form-control width" value="13/03/2008" name="achievement_date[]"></td>
<td><select class="form-control width" name="achievement_type[]">
    <option>--select--</option>
    <option>Cost Saving</option>
    <option>Process Improvemnt</option>
 
</select></td>

<td><input type="text" class="form-control width"  name="achievement_period[]"></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="achievement_remark[]"></textarea></td>
<td><input type="file" name="achievement_upload[]"></td>
<td></td>
<td><button type="button" class="deletebtn" title="Remove row" 
style="background-color: #7d98da">X</button></td>
</tr>`
              );
      });
  
      // jQuery button click event to remove a row.
      $('#tableachievemnt').on('click', '.remove', function () {
  
        // Getting all the rows next to the row
        // containing the clicked button
        var child = $(this).closest('tr').nextAll();
  
        // Iterating across all the rows 
        // obtained to change the index
        child.each(function () {
  
          // Getting <tr> id.
          var id = $(this).attr('id');
  
          // Getting the <p> inside the .row-index class.
          var idx = $(this).children('.row-index').children('p');
  
          // Gets the row number from <tr> id.
          var dig = parseInt(id.substring(1));
  
          // Modifying row index.
          idx.html(`Row ${dig - 1}`);
  
          // Modifying row id.
          $(this).attr('id', `R${dig - 1}`);
        });
  
  
      });
    }); 
  </script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>

 $(document).on('click', 'button.deletebtn', function () {
     $(this).closest('tr').remove();
     return false;
 });
</script>

 


<script type = "text/javascript">
$('#input-payment-egn').keyup(function(e){
  if($(this).val().length === 10){
    e.preventDefault();
    $('#wrong-egn').slideUp();
  } else {
    $('#wrong-egn').slideDown();
  }     
});
$('#input-payment-egn1').keyup(function(e){
  if($(this).val().length === 10){
    e.preventDefault();
    $('#wrong-egn1').slideUp();
  } else {
    $('#wrong-egn1').slideDown();
  }     
});
$('#input-payment-egn3').keyup(function(e){
  if($(this).val().length === 12){
    e.preventDefault();
    $('#wrong-egn3').slideUp();
  } else {
    $('#wrong-egn3').slideDown();
  }   
});
$('#input-payment-egn2').keyup(function(e){
  if($(this).val().length === 12){
    e.preventDefault();
    $('#wrong-egn2').slideUp();
  } else {
    $('#wrong-egn2').slideDown();
  }   
});


</script>



<script>
                 

$(document).ready(function(){
$("#myInput").on("keyup", function() {
var value = $(this).val().toLowerCase();
$("#myTable tr").filter(function() {
$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
});
});
});

    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="{{url('/')}}/public/assets/js/libs/jquery-3.1.1.min.js"></script>
    <script src="{{url('/')}}/public/bootstrap/js/popper.min.js"></script>
    <script src="{{url('/')}}/public/bootstrap/js/bootstrap.min.js"></script>
    <script src="{{url('/')}}/public/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="{{url('/')}}/public/assets/js/app.js"></script>
    
    <script>
        $(document).ready(function() {
            App.init();
        });
    </script>
    <script src="{{url('/')}}/public/assets/js/custom.js"></script>
    <!-- END GLOBAL MANDATORY SCRIPTS -->


    <!-- BEGIN PAGE LEVEL SCRIPTS -->
    <script src="plugins/table/datatable/datatables.js"></script>
    <script>
        $('#zero-config').DataTable({
            "oLanguage": {
                "oPaginate": { "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>', "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>' },
                "sInfo": "Showing page _PAGE_ of _PAGES_",
                "sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
                "sSearchPlaceholder": "Search...",
               "sLengthMenu": "Results :  _MENU_",
            },
            "stripeClasses": [],
            "lengthMenu": [7, 10, 20, 50],
            "pageLength": 7 
        });
    </script>
    <!-- END PAGE LEVEL SCRIPTS -->
    <!--  BEGIN CUSTOM SCRIPTS FILE  -->

    <script src="{{url('/')}}/public/plugins/dropify/dropify.min.js"></script>
    <script src="{{url('/')}}/public/plugins/blockui/jquery.blockUI.min.js"></script>
    <!-- <script src="plugins/tagInput/tags-input.js"></script> -->
    <script src="{{url('/')}}/public/assets/js/users/account-settings.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A==" crossorigin="anonymous">
 </script>

</body>
</html>

                 <script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>

@endsection