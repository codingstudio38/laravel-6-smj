@extends('Frontend.employee-report-header')
@extends('Frontend.employee-report-footer')

        <!--  BEGIN CONTENT AREA  -->
        <div  class="main-content">
                <div class="">
                    <div class="row layout-top-spacing">
                        <div id="tableCaption" class="col-lg-12 col-12 layout-spacing">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                    	<div class="col-xl-12 col-md-12 col-sm-12 col-12 text-center">
                                    		<h5 class="data-heading1">The Samaj<span>Report run on: November 23, 2020 2:14 PM</span></h5>
                                            <h3 class="data-heading">EMPLOYEE QUALIFICATION AND EXPERIENCE DETAILS REPORT</h3>
                                        </div>
                                           <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12" >
                                                  
                                                    <form method="get" action="/" class="form-inline report-area">
                                                    <label>Employee Type:</label>
                                                    <select class="col-lg-4 form-control">
                                                      <option>All </option>
                                                      <option>Permanent </option>
                                                      <option>Probation </option>
                                                    </select>
                                                      &nbsp;&nbsp;
                                                    	<label>Category:</label>
                                                   <select class="col-lg-4 form-control">
                                                      <option>All Category</option>
                                                      <option>All Category</option>
                                                      <option>All Category</option>
                                                   </select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    
									                <button type="submit" class="btn btn-primary report-btn" value="">Search</button>
									                </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area"  style="padding-bottom: 0px;">
                                	<!-- <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                	<button class="btn btn-secondary" onclick="window.pdf()"><i class="fa fa-file"></i> Save</button> -->
                                    <div class="table-responsive" style="margin-top: 5px;">
                                        <table class="table mb-4">
                                          <thead>
                                                <tr>
                                                <th class="t-th" rowspan="2">Sl.No</th>
                                                <th class="t-th" rowspan="2" >Employee Name</th>
                                                <th class="t-th" rowspan="2">Designation</th>
                                                <th class="t-th" rowspan="2">Department</th>
                                                <th class="t-th" colspan="5" style="horizontal-align : middle;text-align:center; width: 50%;">Educational  Details</th>
                                                <th class="t-th" colspan="5" style="horizontal-align : middle;text-align:center; width: 50%;">Experience Details</th>
                                            </tr>
                                            <tr>
                                                <th class="t-th" scope="col">Academic-Degree/Details</th>

                                                <th class="t-th" scope="col">Professional/Technical Degree/Details</th>
                                                <th class="t-th" scope="col">Board/University</th>
                                                <th class="t-th" scope="col">Year Of Passing</th>
                                                <th class="t-th" scope="col">% Of Mark</th>
                                                <th class="t-th" scope="col">Organisation Name</th>
                                                <th class="t-th" scope="col">Position</th>
                                                <th class="t-th" scope="col">from Date</th>
                                                <th class="t-th" scope="col">To Date</th>
                                                <th class="t-th" scope="col">Sector </th>
                                            </tr>
                                            <tr>

                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center">01  </td>
                                                    <td class="text-primary">SUSANTA KUMAR MOHANTY</td>
                                                    <td> Executive Editor</td>
                                                    <td class="">Editorial</td>
                                                    <td>
                                                        <span>1 LLB</span><br>
                                                        <span>2 MA</span>

                                                    </td>

                                                    <td>
                                                        <span>DCA</span><br>
                                                        <span>MCA</span>

                                                    </td>

                                                    <td><span>Utkal University</span>
                                                        <span>Utkal University</span>
                                                    </td>
                                                    <td><span>1984</span><br>
                                                        <span>1984</span>

                                                    </td>
                                                    <td><span>67%</span><br>
                                                        <span>88%</span>

                                                    </td>
                                                    
                                                    <td><span>Pragatibadi</span><br>
                                                        <span>Prajatantra</span>
                                                    </td>

                                                    <td><span>Editor</span><br>
                                                        <span>Editor</span>
                                                    </td>

                                                    <td><span> 01/05/2001</span><br>
                                                        <span>01/05/2008</span>
                                                    </td>
                                                    <td><span> 01/05/2008</span><br>
                                                        <span>01/05/2010</span>
                                                    </td>
                                                    <td><span> Media</span><br>
                                                        <span>Media </span>
                                                    </td>
                                                 
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                              
                                    </div>


                                </div>
                                 <div class="widget-header" style="padding: 20px;">
                                    <div class="row">
                                    	<div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<a href="#">Page 1 of 17</a>
                                        </div>
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<div class="pagination">
											  <a href="#">&laquo;</a>
											  <a href="#">1</a>
											  <a href="#" class="active">2</a>
											  <a href="#">3</a>
											  <a href="#">4</a>
											  <a href="#">5</a>
											  <a href="#">6</a>
											  <a href="#">&raquo;</a>
											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

        </div>
        <!--  END CONTENT AREA  -->

     
       <script src="{{url('/')}}/public/assets/js/libs/jquery-3.1.1.min.js"></script>
    <script src="{{url('/')}}/public/bootstrap/js/popper.min.js"></script>
    <script src="{{url('/')}}/public/bootstrap/js/bootstrap.min.js"></script>
    <script src="{{url('/')}}/public/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="{{url('/')}}/public/assets/js/app.js"></script>
    <script type="text/javascript">
        var doc = new jsPDF();
    var specialElementHandlers = {
        '#editor': function (element, renderer) {
            return true;
        }
    };

    $('#cmd').click(function () {
        doc.fromHTML($('#content').html(), 15, 15, {
            'width': 170,
                'elementHandlers': specialElementHandlers
        });
        doc.save('sample-file.pdf');
    });
    </script>
    <script>
        $(document).ready(function() {
            App.init();
        });
    </script>
    <script src="{{url('/')}}/public/plugins/highlight/highlight.pack.js"></script>
    <script src="{{url('/')}}/public/assets/js/custom.js"></script>
    <!-- END GLOBAL MANDATORY SCRIPTS -->

    <!-- BEGIN PAGE LEVEL CUSTOM SCRIPTS -->
    <script src="{{url('/')}}/public/assets/js/scrollspyNav.js"></script>
    <script>
        checkall('todoAll', 'todochkbox');
        $('[data-toggle="tooltip"]').tooltip()
    </script>
    <!-- END PAGE LEVEL CUSTOM SCRIPTS -->
</body>
</html>