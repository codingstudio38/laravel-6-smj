@extends('Frontend.employee-report-header')
@extends('Frontend.employee-report-footer')
<body>


        <!--  BEGIN CONTENT AREA  -->
        <div  class="main-content">
                <div class="">
                    <div class="row layout-top-spacing">
                        <div id="tableCaption" class="col-lg-12 col-12 layout-spacing">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                    	<div class="col-xl-12 col-md-12 col-sm-12 col-12 text-center">
                                    		<h5 class="data-heading1">The Samaj<span>Report run on: November 23, 2020 2:14 PM</span></h5>
                                            <h3 class="data-heading">RETIRED EMPLOYEES DETAIL REPORTS</h3>
                                        </div>

                                           <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12" >
                                                  
                                                    <form method="get" action="/" class="form-inline report-area">
                                                    	<label>From Date:</label>
									               <input type="date" class="col-lg-4 form-control" name="" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									                <label>To Date:</label>
									                <input type="date" class="col-lg-4 form-control" name="" >
									               	  &nbsp;&nbsp;
									                <button type="submit" class="btn btn-primary report-btn" value="">Search</button>
									                </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area"  style="padding-bottom: 0px;">
                                	<!-- <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                	<button class="btn btn-secondary" onclick="window.pdf()"><i class="fa fa-file"></i> Save</button> -->
                                    <div class="table-responsive" style="margin-top: 5px;">
                                        <table class="table mb-4">
                                          <thead>
                                                <tr>
                                                    <th class="text-center">Sl. No</th>
                                                    <th>Employee Name</th>
                                                    <th>Designation</th>
                                                    <th class="">Department</th>
                                                    <th>DOB</th>
                                                    <th>DOJ</th>
                                                    <th>Retirement Date</th>
                                                    <th>Category</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center">01</td>
                                                    <td class="text-primary">BISWESWAR RATH</td>
                                                    <td>Jr. Assistant</td>
                                                    <td class="">Circulation</td>
                                                    <td>11/01/1961</td>
                                                    <td>01/09/1988</td>
                                                    <td>10/01/2019</td>
                                                    <td>Non.Jor(A)</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">02</td>
                                                    <td class="text-primary">ARABINDA ROUTRAY</td>
                                                    <td>Sub-Editor</td>
                                                    <td class="">Editorial</td>
                                                    <td>18/02/1962</td>
                                                    <td>02/03/1962</td>
                                                    <td>17/02/2020</td>
                                                    <td>Journalist</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">03</td>
                                                    <td class="text-primary">NIHAR RANJAN PATTNAILK(FY)</td>
                                                    <td>Sr. Paster</td>
                                                    <td class="">Production</td>
                                                    <td>18/02/1962</td>
                                                    <td>01/02/2013</td>
                                                    <td>17/02/2020</td>
                                                    <td>Non.Jor(F)</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">04</td>
                                                    <td class="text-primary">KAILASH CHANDRA SAMAL</td>
                                                    <td>Driver</td>
                                                    <td class="">Angul Office</td>
                                                    <td>18/02/1962</td>
                                                    <td>01/02/2013</td>
                                                    <td>17/02/2020</td>
                                                    <td>Non.Jor(A)</td>
                                                </tr>
                                            </tbody>
                                        </table>
                              
                                    </div>


                                </div>
                                 <div class="widget-header" style="padding: 20px;">
                                    <div class="row">
                                    	<div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<a href="#">Page 1 of 17</a>
                                        </div>
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<div class="pagination">
											  <a href="#">&laquo;</a>
											  <a href="#">1</a>
											  <a href="#" class="active">2</a>
											  <a href="#">3</a>
											  <a href="#">4</a>
											  <a href="#">5</a>
											  <a href="#">6</a>
											  <a href="#">&raquo;</a>
											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

        </div>
        <!--  END CONTENT AREA  -->
        <!--  END CONTENT AREA  -->
    
</body>
</html>