@extends('Frontend.employee-report-header')
@extends('Frontend.employee-report-footer')
<body>
        <!--  BEGIN CONTENT AREA  -->
        <div  class="main-content">
                <div class="">
                    <div class="row layout-top-spacing">
                        <div id="tableCaption" class="col-lg-12 col-12 layout-spacing">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                    	<div class="col-xl-12 col-md-12 col-sm-12 col-12 text-center">
                                    		<h5 class="data-heading1">The Samaj<span>Report run on: November 23, 2020 2:14 PM</span></h5>
                                            <h3 class="data-heading">EMPLOYEE CONTRACT RENEWAL DETAILS REPORT</h3>
                                        </div>
                                         <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12" >
                                                  
                                                    <form method="get" action="/" class="form-inline report-area">
                                                   <label>Category:</label>
                                                   <select class="col-lg-2 form-control">
                                                      <option>All Category</option>
                                                      <option>All Category</option>
                                                      <option>All Category</option>
                                                   </select>&nbsp;&nbsp;&nbsp;
                                                   <label>Renewal From Date:</label>
                                                   <input type="date" class="col-lg-2 form-control  " name="">&nbsp;&nbsp;&nbsp;&nbsp;
                                                   <label>Renewal To Date:</label>
                                                   <input type="date" class="col-lg-2 form-control" name="">&nbsp;&nbsp;
									                <button type="submit" class="btn btn-primary report-btn" value="">Search</button>
									                </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area"  style="padding-bottom: 0px;">
                                <!-- 	<button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                	<button class="btn btn-secondary" onclick="window.pdf()"><i class="fa fa-file"></i> Save</button> -->
                                    <div class="table-responsive" style="margin-top: 5px;">
                                        <table class="table mb-4">
                                          <thead>
                                                <tr>
                                                    <th class="text-center">Emp Code</th>
                                                    <th>Emp. Name</th>
                                                    <th>Designation</th>
                                                    <th class="">Department</th>
                                                    <th class="">Category</th>
                                                    <th class="">DOJ</th>
                                                    <th class="">Sl. No</th>
                                                    <th class="">Contract From Date</th>
                                                    <th class="">Contract To Date</th>
                                                    <th class="">Basic Salary</th>
                                                    <th class="">Remarks</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center">006</td>
                                                    <td class="text-primary">BAMAPADA TRIPATHY</td>
                                                    <td>Editor</td>
                                                    <td class="">Editorial</td>
                                                    <td>Working Journalists</td>
                                                    <td>07/10/2019</td>
                                                    <td><span>01</span><br>
                                                        <span>02</span><br>
                                                        <span>03</span><br>
                                                        <span>04</span>
                                                    </td>
                                                    <td><span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span>
                                                    </td>
                                                    <td><span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span>
                                                    </td>
                                                    <td><span>7500.00</span><br>
                                                        <span>8500.00</span><br>
                                                        <span>7500.00</span><br>
                                                        <span>8500.00</span>
                                                    </td>
                                                    <td><span>1st Term</span><br>
                                                        <span>2nd Term</span><br>
                                                        <span>3rd Term</span><br>
                                                        <span>4th Term</span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">006</td>
                                                    <td class="text-primary">RAKESH KUMAR PADHI</td>
                                                    <td>Sub-Editor</td>
                                                    <td class="">Editorial</td>
                                                    <td>Working Journalists</td>
                                                    <td>07/10/2019</td>
                                                    <td><span>01</span><br>
                                                        <span>02</span><br>
                                                        <span>03</span><br>
                                                        <span>04</span>
                                                    </td>
                                                    <td><span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span>
                                                    </td>
                                                    <td><span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span>
                                                    </td>
                                                    <td><span>7500.00</span><br>
                                                        <span>8500.00</span><br>
                                                        <span>7500.00</span><br>
                                                        <span>8500.00</span>
                                                    </td>
                                                    <td><span>1st Term</span><br>
                                                        <span>2nd Term</span><br>
                                                        <span>3rd Term</span><br>
                                                        <span>4th Term</span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">006</td>
                                                    <td class="text-primary">DEBEN KUMAR PATEL</td>
                                                    <td>Reporter</td>
                                                    <td class="">Editorial</td>
                                                    <td>Working Journalists</td>
                                                    <td>07/10/2019</td>
                                                    <td><span>01</span><br>
                                                        <span>02</span><br>
                                                        <span>03</span><br>
                                                        <span>04</span>
                                                    </td>
                                                    <td><span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span>
                                                    </td>
                                                    <td><span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span>
                                                    </td>
                                                    <td><span>7500.00</span><br>
                                                        <span>8500.00</span><br>
                                                        <span>7500.00</span><br>
                                                        <span>8500.00</span>
                                                    </td>
                                                    <td><span>1st Term</span><br>
                                                        <span>2nd Term</span><br>
                                                        <span>3rd Term</span><br>
                                                        <span>4th Term</span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">006</td>
                                                    <td class="text-primary">PRATAP CHANDRA PRADHAN</td>
                                                    <td>Editor</td>
                                                    <td class="">Editorial</td>
                                                    <td>Working Journalists</td>
                                                    <td>07/10/2019</td>
                                                    <td><span>01</span><br>
                                                        <span>02</span><br>
                                                        <span>03</span><br>
                                                        <span>04</span>
                                                    </td>
                                                    <td><span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span>
                                                    </td>
                                                    <td><span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span><br>
                                                        <span>10/03/2008</span>
                                                    </td>
                                                    <td><span>7500.00</span><br>
                                                        <span>8500.00</span><br>
                                                        <span>7500.00</span><br>
                                                        <span>8500.00</span>
                                                    </td>
                                                    <td><span>1st Term</span><br>
                                                        <span>2nd Term</span><br>
                                                        <span>3rd Term</span><br>
                                                        <span>4th Term</span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                              
                                    </div>


                                </div>
                                 <div class="widget-header" style="padding: 20px;">
                                    <div class="row">
                                    	<div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<a href="#">Page 1 of 17</a>
                                        </div>
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<div class="pagination">
											  <a href="#">&laquo;</a>
											  <a href="#">1</a>
											  <a href="#" class="active">2</a>
											  <a href="#">3</a>
											  <a href="#">4</a>
											  <a href="#">5</a>
											  <a href="#">6</a>
											  <a href="#">&raquo;</a>
											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

        </div>
        <!--  END CONTENT AREA  -->

      
</html>