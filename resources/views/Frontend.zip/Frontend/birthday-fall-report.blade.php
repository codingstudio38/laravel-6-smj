@extends('Frontend.employee-report-header')
@extends('Frontend.employee-report-footer')
<body>


        <!--  BEGIN CONTENT AREA  -->
        <div  class="main-content">
                <div class="">
                    <div class="row layout-top-spacing">
                        <div id="tableCaption" class="col-lg-12 col-12 layout-spacing">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                    	<div class="col-xl-12 col-md-12 col-sm-12 col-12 text-center">
                                    		<h5 class="data-heading1">The Samaj<span>Report run on: November 23, 2020 2:14 PM</span></h5>
                                            <h3 class="data-heading">BIRTHDAY FALL REPORT</h3>
                                        </div>

                                         <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12" >
                                                  
                                                    <form method="get" action="/" class="form-inline report-area">
                                                    	<label>From Month:</label>
									               <select class="col-lg-4 form-control">
                                                        <option value="January">January</option>
                                                        <option value="Febuary">Febuary</option>
                                                        <option value="March">March</option>
                                                        <option value="April">April</option>
                                                        <option value="May">May</option>
                                                        <option value="June">June</option>
                                                        <option value="July">July</option>
                                                        <option value="August">August</option>
                                                        <option value="September">September</option>
                                                        <option value="October">October</option>
                                                        <option value="November">November</option>
                                                        <option value="December">December</option>
                                                   </select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									                <label>To Month:</label>
									                <select class="col-lg-4 form-control">
                                                        <option value="January">January</option>
                                                        <option value="Febuary">Febuary</option>
                                                        <option value="March">March</option>
                                                        <option value="April">April</option>
                                                        <option value="May">May</option>
                                                        <option value="June">June</option>
                                                        <option value="July">July</option>
                                                        <option value="August">August</option>
                                                        <option value="September">September</option>
                                                        <option value="October">October</option>
                                                        <option value="November">November</option>
                                                        <option value="December">December</option>
                                                   </select>
									               	  &nbsp;&nbsp;
									                <button type="submit" class="btn btn-primary report-btn" value="">Search</button>
									                </form>
                                        </div>
                                    </div>
                                </div>
                                  
                                <div class="widget-content widget-content-area"  style="padding-bottom: 0px;">

                                	<!-- <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                	<button class="btn btn-secondary" onclick="window.pdf()"><i class="fa fa-file"></i> Save</button> -->
                                    <div class="table-responsive" style="margin-top: 5px;">
                                        <table class="table mb-4">
                                          <thead>
                                                <tr>
                                                    <th class="text-center">Emp. Code</th>
                                                    <th>Employee Name</th>
                                                    <th>Designation</th>
                                                    <th class="">Department</th>
                                                    <th>DOB</th>
                                                    <th>DOJ</th>
                                                    <th>Birth Day</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center">200</td>
                                                    <td class="text-primary">RANJIT MOHANTY</td>
                                                    <td>Sub-Editor</td>
                                                    <td class="">News Portal</td>
                                                    <td>01/11/1966</td>
                                                    <td>28/12/2007</td>
                                                    <td>01/Nov</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">504</td>
                                                    <td class="text-primary">BALARAM BEHERA</td>
                                                    <td>Peon</td>
                                                    <td class="">Administration</td>
                                                    <td>04/01/1969</td>
                                                    <td>01/07/2003</td>
                                                    <td>03/Nov</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">310</td>
                                                    <td class="text-primary">JATINDRA KUMAR BEHERA</td>
                                                    <td>DTP Operator</td>
                                                    <td class="">DTP</td>
                                                    <td>01/11/1966</td>
                                                    <td>28/12/2007</td>
                                                    <td>04/Nov</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">200</td>
                                                    <td class="text-primary">RANJIT MOHANTY</td>
                                                    <td>Sub-Editor</td>
                                                    <td class="">News Portal</td>
                                                    <td>01/11/1966</td>
                                                    <td>28/12/2007</td>
                                                    <td>05/Nov</td>
                                                </tr>
                                            </tbody>
                                        </table>
                              
                                    </div>


                                </div>
                                 <div class="widget-header" style="padding: 20px;">
                                    <div class="row">
                                    	<div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<a href="#">Page 1 of 17</a>
                                        </div>
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<div class="pagination">
											  <a href="#">&laquo;</a>
											  <a href="#">1</a>
											  <a href="#" class="active">2</a>
											  <a href="#">3</a>
											  <a href="#">4</a>
											  <a href="#">5</a>
											  <a href="#">6</a>
											  <a href="#">&raquo;</a>
											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

        </div>
      