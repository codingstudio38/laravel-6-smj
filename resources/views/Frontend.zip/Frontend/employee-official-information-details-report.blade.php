@extends('Frontend.employee-report-header')
@extends('Frontend.employee-report-footer')
<body>

        <!--  BEGIN CONTENT AREA  -->
        <div  class="main-content">
                <div class="">
                    <div class="row layout-top-spacing">
                        <div id="tableCaption" class="col-lg-12 col-12 layout-spacing">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                    	<div class="col-xl-12 col-md-12 col-sm-12 col-12 text-center">
                                    		<h5 class="data-heading1">The Samaj<span>Report run on: November 23, 2020 2:14 PM</span></h5>
                                            <h3 class="data-heading">EMPLOYEE OFFICIAL INFORMATION DETAILS REPORT</h3>
                                        </div>

                                           <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12" >
                                                  
                                                    <form method="get" action="/" class="form-inline report-area">
                                                        <label>Employee Type:</label>
                                                    <select class="col-lg-4 form-control">
                                                      <option>All </option>
                                                      <option>Permanent </option>
                                                      <option>Probation </option>
                                                    </select>
                                                      &nbsp;&nbsp;
                                                    	<label>Category:</label>
                                                   <select class="col-lg-4 form-control">
                                                      <option>All Category</option>
                                                      <option>All Category</option>
                                                      <option>All Category</option>
                                                   </select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    
									                <button type="submit" class="btn btn-primary report-btn" value="">Search</button>
									                </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area"  style="padding-bottom: 0px;">
                                	<!-- <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                	<button class="btn btn-secondary" onclick="window.pdf()"><i class="fa fa-file"></i> Save</button> -->
                                    <div class="table-responsive" style="margin-top: 5px;">
                                        <table class="table mb-4">
                                          <thead>
                                                <tr>
                                                    <th class="text-center">Emp Code</th>
                                                    <th>Emp. Name</th>
                                                    <th>Designation</th>
                                                    <th class="">Department</th>
                                                    <th class="">Emp. Type</th>
                                                    <th class="">Category</th>
                                                    <th class="">Grade</th>
                                                    <th class="">UAN</th>
                                                    <th class="">ESI No</th>
                                                    <th class="">PAN</th>
                                                    <th>Bank A/c No</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center">006</td>
                                                    <td class="text-primary">SUSANTA KU MOHANTY</td>
                                                    <td>Executive Editor</td>
                                                    <td class="">Editorial</td>
                                                    <td>Contract</td>
                                                    <td>Working Journalists</td>
                                                    <td>1(WJ)</td>
                                                    <td>100944537490</td>
                                                    <td>Esi0005</td>
                                                    <td>ADNPT0906A</td>
                                                    <td>326569856</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">007</td>
                                                    <td class="text-primary">ALOK KUMAR PATI</td>
                                                    <td>Sub-Editor</td>
                                                    <td class="">Permanent</td>
                                                    <td>Contract</td>
                                                    <td>Working Journalists</td>
                                                    <td>5(WJ)</td>
                                                    <td>10094145896</td>
                                                    <td>Esi0005</td>
                                                    <td>ADNPT0906A</td>
                                                    <td>3265636325</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">006</td>
                                                    <td class="text-primary">DEBI PRASAD MOHANTY</td>
                                                    <td>Sub-Editor</td>
                                                    <td class="">Editorial</td>
                                                    <td>Permanent</td>
                                                    <td>Working Journalists</td>
                                                    <td>5(WJ)</td>
                                                    <td>100944537490</td>
                                                    <td>Esi0005</td>
                                                    <td>ADHPT0906A</td>
                                                    <td>326569566</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">006</td>
                                                    <td class="text-primary">MALAYA KUMAR DEY</td>
                                                    <td>O.S</td>
                                                    <td class="">Administration</td>
                                                    <td>Contract</td>
                                                    <td>Nour_JOUR(Administrative)</td>
                                                    <td>1(WJ)</td>
                                                    <td>100944537490</td>
                                                    <td>Esi0005</td>
                                                    <td>SERPT0906A</td>
                                                    <td>3265252200</td>
                                                </tr>
                                            </tbody>
                                        </table>
                              
                                    </div>


                                </div>
                                 <div class="widget-header" style="padding: 20px;">
                                    <div class="row">
                                    	<div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<a href="#">Page 1 of 17</a>
                                        </div>
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<div class="pagination">
											  <a href="#">&laquo;</a>
											  <a href="#">1</a>
											  <a href="#" class="active">2</a>
											  <a href="#">3</a>
											  <a href="#">4</a>
											  <a href="#">5</a>
											  <a href="#">6</a>
											  <a href="#">&raquo;</a>
											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

        </div>
        <!--  END CONTENT AREA  -->
