 @extends('Frontend.footer')

@extends('Frontend.inner_master')

@section('content')
<div id="content" class="main-content">
            <div class="layout-px-spacing">                
                <div class="account-settings-container layout-top-spacing">
                    <div class="account-content">
                        <div class="scrollspy-example" data-spy="scroll" data-target="#account-settings-scroll" data-offset="-100">
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                                    <form id="general-info" class="section general-info" 
                                    action="{{url('/')}}/Update_User_Data"  method="post">
                                         {!! csrf_field() !!} 
                                        <div class="info">
                                            <h6 class="">USER PROFILE</h6>
                                                <div class="col-lg-6 mx-auto user-maintenance">
                                                    <div class="row">
                                                        <input type="hidden"id="id" name="user_sql_id">
                                                        <div class="col-lg-12 text-center login-type">
                                                            <h5>USER GROUP</h5>
                                                                 @foreach($Employee_fetch as $ky=>$val)
                                                            <input type="radio"  name="user_name" value="{{$val->user_type}}" checked>
                                                            <label for="vehicle1">{{$val->user_type}}<br></label>&nbsp;
                                                             @endforeach
                                                           <!--  <input type="radio"  name="user_name" value="Administrator" id="Administrator">
                                                            <label for="vehicle1">2.    Administrator </label>&nbsp;&nbsp;
                                                             <input type="radio"  name="user_name" value="Supervisor" id="Supervisor">
                                                            <label for="vehicle1">3.    Supervisor</label>&nbsp;&nbsp;
                                                            <input type="radio"  name="user_name" value="Authorizer" id="Authorizer">
                                                            <label for="vehicle1">4.    Authorizer</label>&nbsp;&nbsp;
                                                            <input type="radio"  name="user_name" value="HR Manager" id="HR Manager">
                                                            <label for="vehicle1">5.    HR Manager</label>&nbsp;&nbsp;&nbsp;<br>
                                                            <input type="radio"  name="user_name" value=" Finance Staff" id="Finance Staff">
                                                            <label for="vehicle1">6.    Finance Staff</label>&nbsp;&nbsp;
 -->
                                                        </div>

                                                        <div class="col-lg-6">
                                                            <div class="form-group">
                                                            <label>User Id</label>
                                                             <select class="form-control" id="email_id" required>
                                                                <option value=""> 
                                                                </option>
                                                            </select>
                                                        </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="form-group">
                                                            <label for="fullName">Status</label><br>
                                                          <!--   <input type="checkbox"  name="" value="yes">
                                                            <label for="vehicle1">Inactive</label>&nbsp;&nbsp; -->
                                                             <select class="form-control" id="status" name="status"required>
                                                                <option value="active">Active</option>
                                                                <option value="inactive">Inactive</option>

                                                                </select>
                                                        </div>
                                                        </div>
<!--                                                         <div class="col-lg-6">
                                                            <div class="form-group">
                                                            <label>Password</label>
                                                             <input type="password" class="form-control mb-4" name="" value="" id="user_password" required>
                                                        </div>
                                                        </div> -->
                                                        <div class="col-lg-12">
                                                            <div class="form-group">
                                                            <label for="fullName">Expiry Date(DD/MM/YY)</label><br>
                                                            <input type="date" class="form-control mb-4"  name="expiary_date" value="" id="expiary_date" required>
                                                            
                                                        </div>
                                                        </div>

                                                        <div class="col-lg-12 text-center password-type">
                                                            <h5>CHANGE PASSWORD</h5>
                                                        </div>
                                                        <div class="offset-lg-2 col-lg-8">
                                                            <label>Existing Password</label>
                                                            <input type="password" class="form-control mb-4" name="" required>
                                                        </div>
                                                        <div class="offset-lg-2 col-lg-4">
                                                            <label>New Password</label>
                                                            <input type="password" class="form-control mb-4" name="" id="password1" >
                                                        </div>
                                                         <div class="col-lg-4 eye">
                                                            <label>Re-enter New Password</label>
                                                            <input type="password" class="form-control" name="reenter_password"  id="password2" >
                                                           
                                                        </div>
                                                        <div class="offset-lg-2 col-lg-8 text-center">
                                                            <button class="btn btn-primary "type="submit"  id="butsave">Save</button>&nbsp;&nbsp;
                                                            <button class="btn btn-danger mb-2">Cancel</button>
                                                        </div>

                                                    </div>
                                                    
                                                </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!--  END CONTENT AREA  -->
    </div>
    <!-- END MAIN CONTAINER -->
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> 
    
    </script>
      <script type="text/javascript">
  $(function () {
        $("#butsave").click(function () {
            var password = $("#password1").val();
            var confirmPassword = $("#password2").val();
            if (password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
            return true;
        });
    });

   </script>
   <-- BEGIN GLOBAL MANDATORY SCRIPTS -->

    <script type="text/javascript">
      $('input[type=radio][name=user_name]').change(function() {
            let role =this.value;
              // alert(role);
            $.ajax({

                  type:'POST',
                  url: "{{url('/getEmailuser')}}",
                  dataType: "json",
                  data:{
                    '_token':$('input[name=_token]').val(),  
                 'selectedid': role
            },
             success: function(f){
                $("#email_id").html(f);
        }
});

   });

        $(document).on('change', '#email_id', function(e) { 
       e.preventDefault(); 
       var pkid = $(this).val();
      //alert(pkid);
     $.ajax({
         type:'POST',
          url: "{{url('/getEmailDetails')}}",
          dataType: "json",
         data:{
       '_token':$('input[name=_token]').val(),        
       'emailId': pkid
        },
        success: function(data){
          if(data!=""){
         $('#id').val(data[0].id);
         $('#expiary_date').val(data[0].expiary_date);
         $('#status').val(data[0].status);
         $('#user_password').val(data[0].password);
         

      }
   }
 });
           });
 </script>
 
   
</body>
</html>
@endsection