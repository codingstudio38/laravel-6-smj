@extends('Frontend.employee-report-header')
@extends('Frontend.employee-report-footer')
<body>


        <!--  BEGIN CONTENT AREA  -->
        <div  class="main-content">
                <div class="">
                    <div class="row layout-top-spacing">
                        <div id="tableCaption" class="col-lg-12 col-12 layout-spacing">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">

                                    	<div class="col-xl-12 col-md-12 col-sm-12 col-12 text-center">
                                    		<h5 class="data-heading1">The Samaj<span>Report run on: November 23, 2020 2:14 PM</span></h5>
                                            <h3 class="data-heading">EMPLOYEE YEAR OF SERVICE, QUALIFICATION AND PAY GRADE DETAILS REPORT</h3>
                                        </div>

                                        </div>
                                             <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                    <form style="padding-left: 15px;">
                                        <div class="row">
                                        <div class="col-lg-2 col-sm-12">
                                            <div class="form-group">
                                                <label>Employee Type:</label>
                                                <select class="form-control">
                                                      <option>All </option>
                                                      <option>Permanent </option>
                                                      <option>Probation </option>
                                                    </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-2 col-sm-12">
                                            <div class="form-group">
                                                <label>Category:</label>
                                                <select class="form-control">
                                                      <option>All Category</option>
                                                      <option>All Category</option>
                                                      <option>All Category</option>
                                                   </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-sm-12">
                                            <div class="form-group">
                                                <label>As On Date:</label>
                                                <input type="date" class="form-control" name="">
                                            </div>
                                        </div>
                                        <div class="col-lg-2 col-sm-12">
                                            <div class="form-group">
                                                <label>Yr. Of Service From:</label>
                                                <input type="number" class="form-control" name="">
                                            </div>
                                        </div>

                                        <div class="col-lg-1 col-sm-12">
                                            <div class="form-group">
                                                <label>To:</label>
                                                <input type="number" class="form-control" name="">
                                            </div>
                                        </div>

                                        <div class="col-lg-2 col-sm-12">
                                            <div class="form-group">
                                                <label>Search</label>
                                                <button type="submit" class="btn btn-primary report-btn" value="">Search</button>
                                            </div>
                                        </div>
                                    </div>
                                    </form>
                 
                                    
                                </div>
                                <div class="widget-content widget-content-area"  style="padding-bottom: 0px;">
                                	<!-- <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                	<button class="btn btn-secondary" onclick="window.pdf()"><i class="fa fa-file"></i> Save</button> -->
                                    <div class="table-responsive" style="margin-top: 5px;">
                                        <table class="table mb-4">
                                          <thead>
                                                <tr>
                                                <th class="t-th" rowspan="2">Emp. Code</th>
                                                <th class="t-th" rowspan="2" >Employee Name</th>
                                                <th class="t-th" rowspan="2">Designation</th>
                                                <th class="t-th" rowspan="2">Department</th>
                                                <th class="t-th" rowspan="2">DOB</th>
                                                <th class="t-th" rowspan="2">DOJ</th>
                                                <th class="t-th" rowspan="2">Date Of Confirmation</th>
                                                <th class="t-th" rowspan="2">Year Of Service</th>
                                                <th class="t-th" colspan="2" style="horizontal-align : middle;text-align:center; width: 50%;">Educational  Qualification</th>
                                                <th class="t-th" rowspan="2">Grade In Majithia WageBoard</th>
                                                <th class="t-th" rowspan="2">Remarks</th>
                                            
                                            </tr>

                                            <tr>
                                                <th class="t-th" scope="col">Academic</th>
                                                <th class="t-th" scope="col">Technical/Professional</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center">009</td>
                                                    <td class="text-primary">ALOK KUMAR PATI</td>
                                                    <td>Sub-Editor</td>
                                                    <td class="">Editorial</td>
                                                    <td>05/01/1967</td>
                                                    <td>31/10/2003</td>
                                                    <td>01/04/2006</td>
                                                    <td>14.7</td>
                                                    <td>M.A(Oriya)</td>
                                                    <td>D.C.A</td>
                                                    <td>5(WJ)</td>
                                                    <td>#</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">008</td>
                                                    <td class="text-primary">AJAYA KUMAR PATTANAIK</td>
                                                    <td>Software Engineer</td>
                                                    <td class="">IT</td>
                                                    <td>05/01/1967</td>
                                                    <td>31/10/2003</td>
                                                    <td>01/04/2006</td>
                                                    <td>14.7</td>
                                                    <td>B.sc</td>
                                                    <td>MCA</td>
                                                    <td>1(Admin)</td>
                                                    <td>#</td>
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                              
                                    </div>


                                </div>
                                 <div class="widget-header" style="padding: 20px;">
                                    <div class="row">
                                    	<div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<a href="#">Page 1 of 17</a>
                                        </div>
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<div class="pagination">
											  <a href="#">&laquo;</a>
											  <a href="#">1</a>
											  <a href="#" class="active">2</a>
											  <a href="#">3</a>
											  <a href="#">4</a>
											  <a href="#">5</a>
											  <a href="#">6</a>
											  <a href="#">&raquo;</a>
											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

        </div>
        <!--  END CONTENT AREA  -->
     
</body>
</html>