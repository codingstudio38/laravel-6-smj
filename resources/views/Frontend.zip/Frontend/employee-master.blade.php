@extends('Frontend.footer')

@extends('Frontend.inner_master')

@section('content')
<link rel="stylesheet" type="text/css" href="{{url('/')}}/public/plugins/table/datatable/datatables.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/plugins/table/datatable/custom_dt_html5.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/public/plugins/table/datatable/dt-global_style.css">

<style type="text/css">
    #bank
{
    font-size: 13px;
    color: black;
}
#wrong-egn{
  display: none;
  font-size: 12px;
  color: red;
}
#wrong-egn1{
  display: none;
  font-size: 12px;
  color: red;
}
#wrong-egn2{
  display: none;
  font-size: 12px;
  color: red;
}
#wrong-egn3{
  display: none;
  font-size: 12px;
  color: red;
}
.employeemaster{
    color: #f70c0c;
}
</style>

        <!--  BEGIN CONTENT AREA  -->
<div id="content" class="main-content">
<div class="layout-px-spacing">                

<div class="account-settings-container layout-top-spacing">

<div class="account-content">
<div class="scrollspy-example" data-spy="scroll" data-target="#account-settings-scroll" data-offset="-100">
<div class="row">
<div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
<form id="general-info" class="section general-info"
 action="{{url('/')}}/add-employee-master" method="post" enctype="multipart/form-data">
<div class="form-group" style="text-align: right;color: white;" >
                          <button type="submit" class="btn btn button1"
                           style="background-color: #1b55e2;">
                         Save</button>
                        </div> 
    
{!! csrf_field() !!}  

    <div class="info">

    <h6 class="">EMPLOYEE MASTER</h6>

    <div class="row">
    <div class="col-lg-11 mx-auto">
        <div class="row">
             <div class="col-xl-2 col-lg-12 col-md-4">
                <div class="upload mt-4" >
                    <input type="file" id="input-file-max-fs" class="dropify" data-default-file="{{url('/')}}/public/assets/img/download.jpg" data-max-file-size="2M"  name="image"/ >
                    <!-- <p class="mt-2"><i class="flaticon-cloud-upload mr-1"></i> </p> -->
                </div>
            </div>

            <div class="col-xl-10 col-lg-10 col-md-10 mt-md-0 mt-4">
            
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Employee no<span class="employeemaster">*</span></label>
                                <input type="text" class="form-control mb-4"  name="emp_no"  value="" required >
                            </div>
                        </div>
                       <div class="col-sm-2">
                            <div class="form-group">
                                <label for="fullName">Employee List</label>
                               <button type="button" class="btn btn-primary mb-2" data-toggle="modal" data-target=".bd-example-modal-xl">List</button>

                            </div>
                        </div>
                        <div class="col-sm-6 ">
                            <label class="dob-input">Active Type<span class="employeemaster">*</span></label>
                      
                                <div class="form-group mr-1" >
                                    <select class="form-control" id="exampleFormControlSelect1" name="type" onchange="showfield(this.options[this.selectedIndex].value)" required>
                                      <option value="active">Active</option>
                                      <option value="inactive">Inactive</option>
                         
                                    </select>
                                  <div class="form-group mt-2">
                                     <div class="row">
                                       <div class="col-6 r_class " style="display: none">
                                          <select class="form-control" name="inactive_reason" id="reason" >
                                             <option>Select</option>
                                            <option value="Superannuation">Superannuation</option>
                                            <option value= "Resignation">Resignation</option>
                                            <option value= "Termination">Termination</option>
                                            <option value= "Death">Death</option>
                                            <option value= "Illness">Illness</option>
                                            <option value= "Others">Others</option>
                                          </select>
                                       </div>
                                       <div class="col-6 r_class"  style="display: none">
                                          <input type="date" class="form-control mb-4"  name="inactive_date" value="" id="r_dob">
                                       </div>
                                       <div class="col-12 r_class" style="display: none">
                                         <textarea  class="form-control mb-4" id="r_txtReason" name="reason_desc" rows="2" cols="54" placeholder="describe your reason"></textarea>
                                       </div>
                                     </div>
                                  </div>
                                  </div>
                           </div>


                         <div class="col-sm-6">
                            <div class="form-group">
                                <label for="fullName">Employee Name<span class="employeemaster">*</span></label>
                                <input type="text" class="form-control mb-4" name="emp_name"  value=""required>

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="fullName">Employee Code<span class="employeemaster">*</span></label>
                                <input type="text" class="form-control mb-4" name="emp_code"   value=""required>

                            </div>
                        </div>


                         <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Department<span class="employeemaster">*</span></label>
                             <select class="form-control" name="department" id="selectdepartment"required>
                                      <option>Select</option>
                                           @foreach($Department_fetch as $ky=>$val)
                                              <option value="{{$val->dept_no}}">{{$val->dept_name}}</option>
                                           @endforeach
                                      </select>
                            </div>
                        </div>


                         <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Employeement Type<span class="employeemaster">*</span></label>
                                <select class="form-control mb-4" id="exampleFormControlSelect1" name="emp_type"required>
                                       <option>Select</option>
                                @foreach($Employee_type_fetch as $ky=>$val)
                                              <option value="{{$val->id}}">{{$val->employee_type_name}}</option>
                                           @endforeach>
                         
                                    </select>

                            </div>
                        </div>

                          <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Designation<span class="employeemaster">*</span></label>
                                <select class="form-control mb-4" id="selectdesignation" name="designation"required>
                                       <option>Select</option>
                                    @foreach($Designation as $ky=>$val)
                                              <option value="{{$val->desg_code}}">{{$val->desg_name}}</option>
                                           @endforeach
                                    </select>

                            </div>
                        </div>



                         <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Category<span class="employeemaster">*</span></label>
                                <select class="form-control mb-4" id="exampleFormControlSelect1" name="category"required>
                                  <option>Select</option>
                                @foreach($Category_fetch as $ky=>$val)
                                              <option value="{{$val->id}}">{{$val->category_name}}</option>
                                           @endforeach
                                    </select>

                            </div>
                        </div>
                            <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Workplace<span class="employeemaster">*</span></label>
                                <select class="form-control mb-4" id="selectWorkplace" name="workplace"required>
                                    <option>Select</option>
                                       @foreach($Workplace_fetch as $ky=>$val)
                                              <option value="{{$val->id}}">{{$val->workplace_name}}</option>
                                           @endforeach
                         
                                    </select>


                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="fullName">Date Of Birth<span class="employeemaster">*</span></label>
                                <input type="date" class="form-control mb-4"  name="DOB" value=""required>

                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="fullName">Date Of Joining<span class="employeemaster">*</span></label>
                                <input type="date" class="form-control mb-4" name="DOJ"  value=""required>

                            </div>
                        </div>
                           <div class="col-sm-3">
                            <div class="form-group">
                                <label for="fullName">Date Of Probation<span class="employeemaster">*</span></label>
                                <input type="date" class="form-control mb-4" name="DOP"  value=""required>

                            </div>
                        </div>
                           <div class="col-sm-3">
                            <div class="form-group">
                                <label for="fullName">Date of Confirmation</label>
                                <input type="date" class="form-control mb-4" name="DOC"  value="">
                          </div>
                                </div>
                    <div class="col-sm-3">
                            <div class="form-group">
                                <label for="fullName">Retirement Date</label>
                                <input type="date" class="form-control mb-4" name="retirement_date"  value="">
                          </div>
                                </div>
                              
                               </div>
                            </div>
                        </div>
                    </div>
                </div>
             </div>


                                <div class="statbox widget box box-shadow">
                                  <div class="widget-content widget-content-area border-tab">
                                    
                                    <ul class="nav nav-tabs" id="border-tabs" role="tablist">
                                   
                                        <li class="nav-item">
                                            <a class="nav-link active" id="border-home-tab" data-toggle="tab" href="#tab1" role="tab" aria-controls="border-home" aria-selected="true"> OFFICIAL DETAILS</a>
                                        </li>
                                      
                                        <li class="nav-item">
                                            <a class="nav-link" id="border-profile-tab" data-toggle="tab" href="#tab2" role="tab" aria-controls="border-profile" aria-selected="false"> PERSONNEL DETAILS</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab3" role="tab" aria-controls="border-contact" aria-selected="false"> DEPENDENT</a>
                                        </li>
<!--                                                               <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab4" role="tab" aria-controls="border-contact" aria-selected="false"> NOMINEE</a>
                                        </li> -->
                                                              <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab4" role="tab" aria-controls="border-contact" aria-selected="false"> QUALIFICATION</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab5" role="tab" aria-controls="border-contact" aria-selected="false">EXPERIENCE</a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab6" role="tab" aria-controls="border-contact" aria-selected="false"> TRANSFER</a>
                                        </li>

                                         <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab7" role="tab" aria-controls="border-contact" aria-selected="false"> PROMOTION</a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab8" role="tab" aria-controls="border-contact" aria-selected="false"> PROBATION</a>
                                        </li>


                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab9" role="tab" aria-controls="border-contact" aria-selected="false"> CONTRACT</a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab10" role="tab" aria-controls="border-contact" aria-selected="false"> ANTECEDENT</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab11" role="tab" aria-controls="border-contact" aria-selected="false"> REVOCATION</a>
                                        </li>
                                         <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab12" role="tab" aria-controls="border-contact" aria-selected="false">APPRECIATION</a>
                                        </li>
                                         <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab13" role="tab" aria-controls="border-contact" aria-selected="false"> REWARD </a>
                                        </li>
                                         <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab14" role="tab" aria-controls="border-contact" aria-selected="false"> INITIATION</a>
                                        </li>
                                         <li class="nav-item">
                                            <a class="nav-link" id="border-contact-tab" data-toggle="tab" href="#tab15" role="tab" aria-controls="border-contact" aria-selected="false"> ACHIEVEMENT</a>
                                        </li>
                                    </ul>
                <div class="tab-content mb-4 p-sec" id="border-tabsContent">
 <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="border-home-tab">

    <div class="col-lg-12">
      <div class="row">
        <div class="col-sm-12">
            <h4 class="mb-4">Pay Scale Details</h4>
         </div>
      

                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label for="fullName"> Grade</label>

                                        <select class="form-control"     id="packageid"  name="pay_grade_code_hdn">
                                           <option value=0>--Select--</option>
                                           @foreach($pay_grade_view as $ky=>$val)
                                              <option value="{{$val->id}}">{{$val->pay_grade_desc}}
                                              </option>
                                           @endforeach

                                      </select>
                               <!--       <input type="hidden" name="pay_grade_code_hdn" id="pay_grade_code_hdn"> -->
                                    
                                </div>
                            </div>

                        <div class="col-sm-2">
                                <div class="form-group">

                                    <label for="fullName">Pay Grade</label>
                                    <input type="text" class="form-control mb-4"   value="" name ="pay_grade" id='catch_value' style="font-size: 13px;color: #404644" readonly="readonly">

                                </div>
                            </div>
                             <div class="col-sm-2">
                                <div class="form-group">

                                    <label for="fullName">PF A/C No</label>
                                    <input type="text" class="form-control mb-4"   value="" name="pf">

                                </div>
                            </div>

                        <div class="col-sm-2">
                                <div class="form-group">

                                    <label for="fullName">VPF %</label>
                                    <input type="text" class="form-control mb-4"   value="" name ="vpf">

                                </div>
                            </div>


                        <div class="col-sm-2">
                                <div class="form-group">

                                    <label for="fullName">ESI A/C No</label>
                                    <input type="text" class="form-control mb-4"   value="" name ="esi">

                                </div>
                            </div>

                        <div class="col-sm-2">
                                <div class="form-group">

                                    <label for="fullName">PAN No</label>
                                    <input type="text" class="form-control mb-4"   value="" name="PAN">

                                </div>
                            </div>


                        <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">UAN</label>
                                    <input type="text" class="form-control mb-4"   value="" name="uan">

                                </div>
                            </div>

                             <div class="col-sm-4">
                                <div class="form-group">
                                   <label for="fullName">Aadhaar No</label>
                                    <input type="number" maxlength="" name="adhar" value="" placeholder="Adhara number" id="input-payment-egn3" class="form-control"/>
                                   <div id="wrong-egn3">Please provide 12 digit  adhara number.</div>
                                </div>
                            </div>
                       
                               <div class="col-sm-4">
                                <div class="form-group">
                    
                                    <label for="fullName">Initial Special Allowance</label>
                                    <input type="number" id="initial_allowance" class="form-control mb-4"   name ="intial" readonly="readonly" >

                                </div>
                            </div>
                              <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">Current  Special Allowance</label>
                                    <input type="number" class="form-control mb-4"   value="" 
                                    id="current_allowance" name ="current" readonly="readonly" >

                                </div>
                            </div>
                              <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">Initial Other Special Allowance</label>
                                    <input type="number" class="form-control mb-4"   value="" name ="initial_other" id="initial_other" readonly="readonly">

                                </div>
                            </div>
                              <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">Current Other Special  Allowance</label>
                                    <input type="number" class="form-control mb-4"   value="" name="current_other" id="cuurent_other" readonly="readonly">

                                </div>
                            </div>

                            
                           
                              <div class="col-sm-2">
                                <div class="form-group">
                               <label for="fullName">PF Deduction</label><br>
                                     <label class="radio-inline">
                                          <input type="radio" name="optradio" value="yes"> Yes
                                        </label>
                                        <label class="radio-inline">
                                          <input type="radio" name="optradio" value="no"> No
                                        </label>
   

                                </div>
                            </div>

                             <div class="col-sm-2">
                                <div class="form-group">

                                    <label for="fullName">ESI Deduction</label><br>
                                    <label class="radio-inline">
                                          <input type="radio" name="optradio1" value="yes"> Yes
                                        </label>
                                        <label class="radio-inline">
                                          <input type="radio" name="optradio1" value="no"> No
                                        </label>

                                </div>
                            </div>
                                 <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">Initial Basic</label>
                                    <input type="number" class="form-control mb-4"   value="" name="intial_basic" id="intial_basic" >

                                </div>
                            </div>
                                <div class="col-sm-4">
                                <div class="form-group">

                                    <label for="fullName">Current Basic</label>
                                    <input type="number" class="form-control mb-4"   value="" name="current_basic" id="current_basic">

                                </div>
                            </div>

                            <div class="user-info">
                               
                                    
                           </div>
             
                          </div>

                        </div>

       <div class="col-lg-12"> 
      <div class="row b-sec">
   <div class="col-lg-6 "> 
    <div class="card component-card_4">
            <div class="card-body">
              
                <div class="user-info">
                    <h5 class="card-user_name" style="font-size: 25px;">Bank Details</h5>
                      <div class="col-sm-12">
                                <div class="form-group">

                                    <label for="fullName">Payment Mode </label>
                                    <input type="text" class="form-control mb-4"   value="" name="payment_bank_mode" id="current_basic">

                                </div>
                            </div>
               
                                <div class="col-sm-12">
                                    <div class="form-group">
                                    <label for="fullName">Bank: </label>
                                       <lable for="fullName" id="bank"></lable>
                                     <input type="text" class="form-control mb-4"   value="" name="bank_name" id="current_basic">

                                </div>
                              </div>
                               <div class="col-sm-12">
                                <div class="form-group">

                                    <label for="fullName">Bank A/C No: </label>
                                    <lable for="fullName" id="bank"></lable>
                                    <input type="text" class="form-control mb-4"   value="" \
                                    name="account_num" id="current_basic">

                                </div>
                              </div>
                </div>
            </div>
        </div>
    </div>
     <div class="col-lg-6 "> 
         <div class="card component-card_4">
            <div class="card-body">
              
                <div class="user-info">
                    <h5 class="card-user_name" style="font-size: 25px;">Increment Details</h5>
                                      <div class="col-sm-12">
                                      <div class="form-group">
                                    <label for="fullName">Increment Due Date :</label>
                                   <lable for="fullName" id="bank"> </lable>
                                    <input type="date" class="form-control mb-4"   value="" name="incr_date" id="current_basic">
                                 </div>

                                </div>
                                   <div class="col-sm-12">
                                    <div class="form-group">
                                    <label for="fullName">Increment Amount: </label>
                                       <lable for="fullName" id="bank"></lable>
                                       <input type="number" class="form-control mb-4"   value="" name="incr_amount" id="current_basic">
                                    </select>

                                </div>
                              </div>
                </div>
            </div>
        </div>
    </div>

                           

             </div>
        </div>



    </div>
    <div class="tab-pane fade" id="tab2" role="tabpanel" aria-labelledby="border-profile-tab">
    <div class="col-lg-12 emp-sec">
    <div class="row">
    <div class="col-sm-2">
        <div class="form-group">
            <label for="fullName">Gender</label><br>
            <input type="radio"  name="sex" value="male" checked>
            <label for="vehicle1">Male</label>&nbsp;&nbsp;
            <input type="radio" name="sex" value="female">
            <label for="vehicle1">Female</label>

        </div>
    </div>

    <div class="col-sm-3">
        <div class="form-group">
            <label for="fullName">Marital Status</label>
             <select class="form-control" name="marital" id="ddlModels">
            <option value="Married" onclick="married()">Married</option>
            <option value="UnMarried" onclick="Unmarried()">UnMarried</option>
            </select>
        </div>
    </div>


                                              
    <div class="col-sm-3">
        <div class="form-group">
            <label for="fullName">Blood Group</label>
            <select class="form-control" name="blood">
                <option>O+</option>
                <option>A+</option>
                <option>A-</option>
                <option>B-</option>
                <option>B+</option>
                <option>AB+</option>
                <option>AB-</option>
                <option>O-</option>
            </select>
        </div>
    </div>
   <div class="col-sm-4">
      <div class="form-group">
        <label for="fullName">Identification Mark</label>
        <input type="text" class="form-control mb-4" name="id"   value="">

      </div>
   </div>
                                 
   <div class="col-sm-2">
      <div class="form-group">
        <label for="fullName">Spouse Name</label>
        <input type="text" class="form-control mb-4" name="spouse"  id="spouseName"  value="">

       </div>
    </div>
    <div class="col-sm-2">
        <div class="form-group">
            <label for="fullName">Spouse's Date Of Birth</label>
            <input type="date" class="form-control mb-4" name="spouse_dob" id="spouseDOB"  value="">
        </div>
    </div>

    <div class="col-sm-2">
       <div class="form-group">
        <label for="fullName">Father Name</label>
        <input type="text" class="form-control mb-4" name="father"   value="">
        </div>
   </div>


 <div class="col-sm-2">
        <div class="form-group">

            <label for="fullName">Father's Date Of Birth</label>
            <input type="date" class="form-control mb-4" name="father_dob"  value="">

        </div>
 </div>

 <div class="col-sm-2">
        <div class="form-group">

            <label for="fullName">Mother Name</label>
            <input type="text" class="form-control mb-4" name="mother"   value="">

        </div>
    </div>


    <div class="col-sm-2">
            <div class="form-group">

                <label for="fullName">Mother's Date Of Birth</label>
                <input type="date" class="form-control mb-4" name="mother_dob"  value="">

            </div>
    </div>

 <div class="col-sm-3">
    <div class="form-group">

        <label for="fullName">Present Address</label>
        <input type="text" class="form-control mb-4"  placeholder="line1"  name="line_11" value="">
        <input type="text" class="form-control mb-4" placeholder="line2" name="line_22"  value="">
        <input type="text" class="form-control mb-4" placeholder="line3" name="line_33"  value="">

    </div>
</div>

 <div class="col-sm-3">
    <div class="form-group">

        <label for="fullName">Permanent Address</label>
        <input type="text" class="form-control mb-4"  placeholder="per_line1" name="per_line1" value="">
        <input type="text" class="form-control mb-4" placeholder="per_line2" name="per_line2"  value="">
        <input type="text" class="form-control mb-4" placeholder="per_line3" name="per_line3"  value="">

    </div>
</div>

 <div class="col-sm-3">
    <div class="form-group">
        <label for="fullName">Contact No</label><br>

<input type="number" maxlength="" name="contactnumber"  placeholder="contact no" id="input-payment-egn" class="form-control"/>
<div id="wrong-egn">Please provide 10digit number.</div>
</div>
</div>
 <div class="col-sm-3">
    <div class="form-group">
        <label for="fullName">Email</label><br>
        <input type="email"   class="form-control" value="" name="email">
    </div>
</div>
</div>
</div>
</div>
<div class="tab-pane fade" id="tab3" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<div class="offset-lg-11 col-lg-1 new" id="add_new">ADD NEW</div>
<table class="table table-bordered table-hover e-table" id="maintable">
<thead class="e-head">
<tr>

<th>Dependent Name:</th>
<th>Type</th>
<th>Date Of Birth:</th>
<th>Age:</th>
<th>Relationship:</th>
<th>Aadhaar No:</th>
<th>Address</th>
<th>Upload Adhara</th>
<th>Cancel</th>
</tr>
</thead>
<tbody id="e-body">

@for ($i=0;$i<5;$i++)
<tr>
<td class="td2"><input type="text" class="form-control width" name="name[]" placeholder=""  ></td>
<td><select class="form-control" name="dependent_type[] "style="width: 124px" id="one{{$i}}" onchange="nominee_select(this.value,{{$i}})" >
    <option value="Dependent">Dependent</option>
    <option value="Nominee" >Nominee</option></select></td>
<td><input type="date" class="form-control" name="dob1[]" placeholder="enter DOB"></td>
<td><input type="number" class="form-control  td1"  name="age[]" ></td>
<td class="td2"><input type="text" class="form-control width" name="relation[]" placeholder="enter your relation"></td>
<td  class="td2"><input type="number" class="form-control width" name="num[]" placeholder="enter adhara"  ></td>
<td><textarea rows="3" cols="40" class="form-control"  name="dependent_addr[]" style="width:200px;"></textarea></td>
<td><input type="file" class="" placeholder="67%" name="dependent_file[]" multiple></td>

<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>

</tr>
@endfor

</tbody>
</table>

</div>
</div> 

<!-- <div class="tab-pane fade" id="tab4" role="tabpanel" aria-labelledby="border-profile-tab">
<div class="col-lg-12 emp-sec">

</div>
</div> --> 


<div class="tab-pane fade show" id="tab4" role="tabpanel" aria-labelledby="border-home-tab">
    <div class="col-lg-12 emp-sec">
      <div class="row">
        <div class="col-sm-6" style="margin-right: 520px;">
<h4 class="mb-4">Academic</h4>
</div>
  <div class="col-lg-1 new" id="add_newqualification" >ADD NEW</div>
        </div>
         
        <div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">

<table class="table table-bordered table-hover" id="new_qualification">
<thead>
<tr>

<th>Academic Qualification:</th>
<th>Stream/ Subject:</th>
<th style="padding-left: 22px;"> Board/University </th>
<th>Year Of Passing:</th>
<th>% Of Mark:</th>
<th>Division</th>
<th>Remark</th>
<th>Upload Document:</th>
<th>Cancel</th>
</tr>
</thead>

<tbody>

@for ($i=0;$i<5;$i++)
<tr>
<td><select class="form-control width" name="academic[]">
    <option>Primary</option>
    <option>Upper Primary</option>
    <option>Minor</option>
    <option>Under Matric</option>
    <option>Intermediate</option>
    <option>Graduate</option>
    <option>Post-Graduate</option>
    <option>M-Phill </option>
    <option>PHD</option>
    <option>MS</option>
    <option>Certificate</option>
    <option>Diploma</option>
    <option>Post-Diploma</option>
    <option>PG-Diploma</option>
    <option>Others</option>

    </select></td>
<td><input type="text" class="form-control width" placeholder="Arts" name="stream[]"></td>
<td> 
      <div class="container box">

 <input type="text" class="form-control" name="board_name_ajax1[]" value="" style="width: 409px;">
    <div id="boardList">

  </div>
     </td>
<td><input type="number" class="form-control" placeholder="1890" name="year[]"></td>
<td><input type="number" class="form-control" placeholder="67" name="per_mark[]" style="    width: 68px;"></td>
<td><input type="text" class="form-control width2" placeholder="" name="division_qualification[]"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="remark_qualification[]" style="width:200px;"></textarea></td>
<td><input type="file" class="" placeholder="67" name="qualification_file[]"></td>
<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>
</tr>
@endfor


</tbody>
</table>

     

</div>
</div>
</div>


<div class="tab-pane fade" id="tab5" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<div class="offset-lg-11 col-lg-1 new" id="add_newexperience">ADD NEW</div>
<table class="table table-bordered table-hover" id="tablexperience">
<thead>
<tr>

<th>Organisation Name:</th>
<th>Sector:</th>
<th>Position:</th>
<th>From Date:</th>
<th>To Date:</th>
<th>Reason For Leave</th>
<th>Remark</th>
<th>Upload Document:</th>
<th>Cancel</th>
</tr>
</thead>
<tbody>

@for ($i=0;$i<5;$i++)
<tr>

<td><input type="text" class="form-control" placeholder="The Samad"  name="orgn[]" style="width: 255px;"></td>
<td><input type="text" class="form-control width2" placeholder="Media" name="sect[]"></td>
<td><input type="text" class="form-control width2" placeholder="Editor" name="pos[]"></td>
<td><input type="date" class="form-control" placeholder="01/03/2015" name="from[]"></td>
<td><input type="date" class="form-control" placeholder="01/03/2017" name="to[]"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="area[]" style="width:200px;"></textarea></td>
<td><textarea rows="3" cols="40" class="form-control"  name="remark_area[]" style="width:250px;"></textarea></td>
<td><input type="file" name="e_file[]"></td>
<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>
</tr>
@endfor


</tbody>
</table>

     
</div>
</div>  

<div class="tab-pane fade" id="tab6" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<div class="offset-lg-11 col-lg-1 new" id="add_newtransferno">ADD NEW</div>
<table class="table table-bordered table-hover" id="table_transfer">
<thead>
<tr>

<th>Transfer Order No.</th>
<th>Type</th>
<th>Transfer Date:</th>
<th>From Date:</th>
<th>To Date:</th>
<th>From Department:</th>
<th>To Department:</th>
<th>From Workplace</th>
<th>To Workplace</th>
<th>Reason</th>
<th>Remarks:</th>
<th>Upload Document</th>
<th>Cancel</th>


</tr>
</thead>
<tbody  id="table_transfer">

@for ($i=0;$i<5;$i++)
<tr>

<td><input type="text" class="form-control width" width="130px" name="trans_order[]"></td>
<td> <select class="form-control width" name="order_type[]" >
        <option>Transfer</option>
        <option>Deputation</option>
    </select></td>
<td><input type="date"  class="form-control" placeholder="05/03/2009" width="130px" name="transfer_ord_date[]"></td>
<td><input type="date"  class="form-control" placeholder="13/03/2008" name="from_date[]"></td>
<td><input type="date" class="form-control" placeholder="13/03/2008" name="to_date[]" ></td>
<td> <select class="form-control width"  name="f_dept[]">
<option>Select</option>
     @foreach($Department_fetch as $ky=>$val)
    <option value="{{$val->dept_no}}">{{$val->dept_name}}</option>
        @endforeach
  </select>
</td>
<td><select class="form-control width" name="t_dept[]" onchange="transfer({{$i}})"  id="transferid{{$i}}">
<option>Select</option>
     @foreach($Department_fetch as $ky=>$val)

    <option value="{{$val->dept_no}}">{{$val->dept_name}}</option>
        @endforeach
  </select></td>
<td><select class="form-control width" name="from_work[]">
<option>Select</option>
@foreach($Workplace_fetch as $ky=>$val)

     <option value="{{$val->id}}">{{$val->workplace_name}}</option>
 @endforeach
</select></td>
<td><select class="form-control width" name="to_work[]"  onchange="transferWork({{$i}})"  id="transferWorkid{{$i}}">
<option>Select</option>
@foreach($Workplace_fetch as $ky=>$val)
     <option value="{{$val->id}}">{{$val->workplace_name}}</option>
 @endforeach
</select></td>

<td> <select class="form-control width"   name="ord_rea[]">
        <option>Select</option>
        <option>Reward</option>
        <option>Routine</option>
        <option>Displinary</option>
        <option>Other</option>
    </select></td>
<td><textarea rows="3" cols="40" class="form-control width" name="reamrks[]"></textarea></td>
<td><input type="file" name="trans_file[]" ></td>
<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>

</tr> 

@endfor


</tbody>
</table>

     
</div>
</div>
<div class="tab-pane fade" id="tab7" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">

<table class="table table-bordered table-hover"  id="table_promotion">
<thead>
<tr>

<th>Promotion order no</th>
<th>Promotion Date:</th>
<th>Promotion Effect Date:</th>
<th>From grade</th>
<th>From Designation/Position</th>
<th>From Basic pay</th>
<th>From special allowance</th>
<th>From Other allowance</th>
<th>To Grade:</th>
<th>To Designation/Position</th>
<th>To Basicpay</th>
<th>To special allowance</th>
<th>To Other Allowance</th>
<th>Remark</th>
<th>Upload Document</th>
<th>Cancel</th>

</tr>
</thead>
<tbody id="promo_tbl">
<div class="offset-lg-11 col-lg-1 new" id="add_newpromotion">ADD NEW</div>
@for ($i=0;$i<5;$i++)
<tr>

<td><input type="text" class="form-control width" name="promo_order_no[]"></td>
<td><input type="date" class="form-control" name="promo_date[]"></td>
<td><input type="date" class="form-control" placeholder="13/03/2008" name="effect_date[]"></td>
<td>
<select class="form-control " onchange="promotion({{$i}})"  id="promotionid{{$i}}" name="from_grade[]" style="width: 202px;">
   <option value="">--Select--</option>
       @foreach($pay_grade_view as $ky=>$val)
        <option value="{{$val->id}}">{{$val->pay_grade_desc}}
        </option>
       @endforeach
</select>
</td>
<td><select class="form-control width"   name="from_design[]">
<option value="">--Select--</option>
                                    @foreach($Designation as $ky=>$val)
                                              <option value="{{$val->desg_code}}">{{$val->desg_name}}</option>
                                           @endforeach
</select></td>

<td><input type="text" class="form-control width" name="from_basic[]" id='catch_paygrade_value{{$i}}' style="    width: 202px;" readonly="readonly"></td>
<td><input type="number" class="form-control width3" name="from_special[]" id="promtion_current_allowance{{$i}}" readonly="readonly" ></td>
<td><input type="number" class="form-control width3" name="from_other_special[]"  id="promtion_currentother_allowance{{$i}}" readonly="readonly" ></td>
<td> <select class="form-control "  onchange="topromotion({{$i}})" id="promotiontoid{{$i}}" name="to_grade[]" style="width: 202px;">
   <option value="">--Select--</option>
       @foreach($pay_grade_view as $ky=>$val)
        <option value="{{$val->id}}">{{$val->pay_grade_desc}}
        </option>
       @endforeach
</select>
</td>
<td>
<select class="form-control width"   name="to_portion[]" onchange="portionDropdown({{$i}})"  id="portionDropdownid{{$i}}">
<option value="">--Select--</option>
                                    @foreach($Designation as $ky=>$val)
                                              <option value="{{$val->desg_code}}">{{$val->desg_name}}</option>
                                           @endforeach
</select></td>
<td><input type="text" class="form-control width" name="to_basic[]" id='catch_topaygrade_value{{$i}}' readonly="readonly"></td>
<td><input type="number" class="form-control width3" name="total_allow[]" id="promtion_tocurrent_allowance{{$i}}" readonly="readonly" ></td>
<td><input type="number" class="form-control width3" name="to_other_allowance[]" id="promtion_tocurrentother_allowance{{$i}}" readonly="readonly"></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remark[]"></textarea></td>
<td><input type="file" name="upload_promo[]"></td>
<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>
</tr>
@endfor

</tbody>
</table>     
</div>
</div>  
<div class="tab-pane fade" id="tab8" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<div class="offset-lg-11 col-lg-1 new" id="add_newprobation">ADD NEW</div>
<table class="table table-bordered table-hover" >
<thead>
<tr>

<th>Probation Order No:</th>
<th>Probation Start Date:</th>
<th>Probation End Date:</th>
<th>Pay Grade:</th>
<th>Initial Basic:</th>
<th>Special Allowance:</th>
<th>Other Allowance:</th>
<th>Remarks:</th>
<th>Upload Document:</th>
<th>Cancel</th>
</tr>
</thead>
<tbody id="probationtable">

@for ($i=0;$i<5;$i++)
<tr>

<td><input type="text" class="form-control width" name="prob_order[]"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="prob_start[]"></td>
<td><input type="date" class="form-control"  placeholder="13/07/2008" name="prob end[]"></td>
<td>
<select class="form-control " onchange="probation({{$i}})"  id="probationid{{$i}}" name="pay_grade1[]" style="width: 202px;">
   <option value="">--Select--</option>
       @foreach($pay_grade_view as $ky=>$val)
        <option value="{{$val->id}}">{{$val->pay_grade_desc}}
        </option>
       @endforeach
</select></td>
<td><input type="text" class="form-control width2" name="initial[]" id="promotion_catch_topaygrade_value{{$i}}"  readonly="readonly" style="width: 219px;"></td>
<td><input type="number" class="form-control width2" name="special_allowance[]"id="probation_current_allowance{{$i}}" readonly="readonly"></td>
<td><input type="number" class="form-control width2" name="other_allownace[]"id="probation_tocurrentother_allowance{{$i}}" readonly="readonly" ></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remark_prob[]"></textarea></td>
<td><input type="file" name="prob_upload[]"></td>
<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>
</tr>
@endfor


</tbody>
</table>     
</div>
</div>  

<div class="tab-pane fade" id="tab9" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<div class="offset-lg-11 col-lg-1 new" id="addBtn1">ADD NEW</div>
<table class="table table-bordered table-hover" id="tablecontract">
<thead>
<tr>

<th>Contract Order No.</th>
<th>Contract Start Date:</th>
<th>Contract End Date:</th>
<th>Consolidated Pay</th>
<th>Special Allowance</th>
<th>Other Allowance</th>
<th>Remarks:</th>
<th>Upload Document:</th>
<th>Cancel</th>
</tr>
</thead>
<tbody id="e-body">

@for ($i=0;$i<5;$i++)
<tr>

<td><input type="text" class="form-control width" name="cont_order[]"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="cont_start_date[]"></td>
<td><input type="date" class="form-control" value="13/03/2008" name="cont_end_date[]"></td>
<td><input type="number" class="form-control width2" name="con_pay[]"></td>
<td><input type="number" class="form-control width2" name="special[]"></td>
<td><input type="number" class="form-control width2" name="other[]"></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remarks[]"></textarea></td>
<td><input type="file" name="cont_file[]"></td>
<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>
</tr>
@endfor
</tbody>
</table>     
</div>
</div>  
<div class="tab-pane fade" id="tab10" role="tabpanel" aria-labelledby="border-contact-tab" >
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<table class="table table-bordered table-hover" id="maintable1" width="50%" cellpadding="0" cellspacing="0" class="pdzn_tbl1" border="#729111 1px solid" >
<thead>
<tr>

<th>Order No</th>
<th>Order Date</th>
<th>Type</th>
<th>W.E.F Date</th>
<th>W.E.T Date</th>
<th>Remarks</th>
<th>Uploads</th>
<th>Cancel</th>
</tr>
</thead>

<tbody>

@for ($i=0;$i<5;$i++)
<tr>
<td><input type="text" class="form-control width" name="ante_order_no[]"></td>
<td><input type="date" class="form-control" value="13/03/2008" name="ante_order_date[]"></td>
<td>   <select class="form-control  width" name="ante_type[]">
        <option>Explanation</option>
        <option>Termination</option>
        <option>Warning</option>
        <option>Salary Deduction</option>
        <option>Demotion</option>
        <option>Charge Sheet</option>
        <option>Suspension</option>
        <option>Others</option>
    </select></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="ante_w_e_e[]"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="ante_w_e_t[]"></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="ante_remarks[]"></textarea></td>
<td><input type="file" name="antecedent_upload[]"></td>
<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>
</tr>
@endfor
<div class="offset-lg-11 col-lg-1 new" id="add_new1">ADD NEW</div>

</tbody>
</table>     
</div>
</div>  


<div class="tab-pane fade" id="tab11" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<div class="offset-lg-11 col-lg-1 new" id="add_new4">ADD NEW</div>
<table class="table table-bordered table-hover" id="tablerevocation">
<thead>
<tr>

<th>Revocation Order No:</th>
<th>Revocation Order Date:</th>
<th>Antecedent Order no:</th>
<th>Antecedent Order Date:</th>
<th>Antecedent Type:</th>
<th>Antecedent W.E.F date:</th>
<th>Antecedent W.E.T Date:</th>
<th>Revocation Effected date:</th>
<th>Remarks:</th>
<th>Uploads</th>
<th>Cancel</th>

</tr>
</thead>
<tbody>

@for ($i=0;$i<5;$i++)
<tr>

<td><input type="text" class="form-control width" name="revo_order_no[]"></td>
<td><input type="date" class="form-control width" value="13/03/2008" name="revo_order_date[]"></td>
<td><select class="form-control width" name="ant_ord_no[]">
  <option>--select--</option>
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->id}}">{{$val->order_no}}</option>
      @endforeach
</select></td>
<td><select class="form-control width" name="ant_ord_dat[]">
  <option>--select--</option>
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->order_date}}">{{$val->order_date}}</option>
      @endforeach
</select></td>
<td><select class="form-control width" name="ant_ord_type[]">
  <option>--select--</option>
   <option>Explanation</option>
        <option>Termination</option>
        <option>Warning</option>
        <option>Salary Deduction</option>
        <option>Demotion</option>
        <option>Charge Sheet</option>
        <option>Suspension</option>
        <option>Others</option>
    </select>
</select></td>
<td><select class="form-control width" name="ant_WEF[]">
  <option>--select--</option>
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->WEE_date}}">{{$val->WEE_date}}</option>
      @endforeach
</select></td>
<td><select class="form-control width" name="ant_WET[]">
  <option>--select--</option>
      @foreach($antecendent_fetch as $ky=>$val)
        <option value="{{$val->WET_date}}">{{$val->WET_date}}</option>
      @endforeach
</select></td>
<td><input type="date" class="form-control" name="revo_effected_date[]" ></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="revo_remark[]"></textarea></td>
<td><input type="file" name="revocation_upload[]"></td>
<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>
</tr>
@endfor




   </tbody>
 </table>     
</div>
</div>                    

<div class="tab-pane fade" id="tab12" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<div class="offset-lg-11 col-lg-1 new" id="add_new5">ADD NEW</div>
<table class="table table-bordered table-hover"  id="tableappriciation">
<thead>
<tr>

<th>Order No:</th>
<th>Order Date:</th>
<th>Appriciation Type:</th>
<th>Recommended By</th>
<th>Description</th>
<th>Remarks</th>
<th>Uploads</th>
<th>Cancel</th>
</tr>
</thead>
<tbody>

@for ($i=0;$i<5;$i++)
<tr>

<td><input type="text" class="form-control width" name="app_order_no[]"></td>
<td><input type="date" class="form-control width"  name="app_order_date[]"></td>
<td><select class="form-control width" name="appreciation_type[]">
    <option>--select--</option>
    <option value="Cost-saving">Cost Saving</option>
    <option value="Process_Improvemnt">Process Improvemnt</option>
 
</select></td>
<td><input type="text" class="form-control width" name="recommended_by[]"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="app_description[]" style="width:200px;"></textarea></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="app_remarks[]"></textarea></td>
<td><input type="file" name="appriciation_upload[]"></td>
<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>
</tr>
@endfor




   </tbody>
 </table>     
</div>
</div> 

<div class="tab-pane fade" id="tab13" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<div class="offset-lg-11 col-lg-1 new" id="add_new6">ADD NEW</div>
<table class="table table-bordered table-hover" id="tablereward">
<thead>
<tr>

<th>Order No:</th>
<th>Order Date:</th>
<th>Reward Type:</th>
<th>Recommended By</th>
<th>Description</th>
<th>Remarks</th>
<th>Uploads</th>
<th>Cancel</th>
</tr>
</thead>
<tbody>

@for ($i=0;$i<5;$i++)
<tr>

<td><input type="text" class="form-control width" name="reorder_no[]"></td>
<td><input type="date" class="form-control width"  name="reorder_date[]"></td>
<td><select class="form-control width" name="reward_type[]">
     <option>--select--</option>
    <option value="Cost-saving">Cost Saving</option>
    <option value="Process_Improvemnt">Process Improvemnt</option>
 
</select></td>
<td><input type="text" class="form-control width" name="re_recommended_by[]"></td>
<td><textarea rows="3" cols="40" class="form-control"  name="re_description[]" style="width:200px;"></textarea></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="re_remarks[]"></textarea></td>
<td><input type="file" name="remark_upload[]"></td>
<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>
</tr>
@endfor




   </tbody>
 </table>     
</div>
</div> 

<div class="tab-pane fade" id="tab14" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<div class="offset-lg-11 col-lg-1 new" id="add_new7">ADD NEW</div>
<table class="table table-bordered table-hover" id="tableintiation">
<thead>
<tr>


<th>Initiative Date</th>
<th>Type</th>
<th>Description</th>
<th>Remarks</th>
<th>Uploads</th>
<th>Cancel</th>

</tr>
</thead>
<tbody>

@for ($i=0;$i<5;$i++)
<tr>


<td><input type="date" class="form-control width" value="13/03/2008" name="initiative_date[]"></td>
<td><select class="form-control width" name="inti_type[]">
    <option>--select--</option>
    <option>Cost Saving</option>
    <option>Process Improvemnt</option>
 
</select></td>

<td><textarea rows="3" cols="40" class="form-control"  name="inti_description[]" style="width:200px;"></textarea></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="inti_remark[]"></textarea></td>
<td><input type="file" name="Initiative_upload[]"></td>
<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>
</tr>
@endfor
</tbody>
 </table>     
</div>
</div>

<div class="tab-pane fade" id="tab15" role="tabpanel" aria-labelledby="border-contact-tab">
<div class="col-lg-12" style="overflow-y: auto;
height: 400px;position: relative;">
<div class="offset-lg-11 col-lg-1 new" id="add_new8">ADD NEW</div>
<table class="table table-bordered table-hover" id="tableachievemnt">
<thead>
<tr>


<th>Achievement Date</th>
<th>Achievement Type</th>
<th>Achivement Period</th>
<th>Remarks</th>
<th>Uploads</th>
<th>Cancel</th>

</tr>
</thead>
<tbody>

@for ($i=0;$i<5;$i++)
<tr>


<td><input type="date" class="form-control width" value="13/03/2008" name="achievement_date[]"></td>
<td><select class="form-control width" name="achievement_type[]">
    <option>--select--</option>
    <option>Cost Saving</option>
    <option>Process Improvemnt</option>
 
</select></td>

<td><input type="text" class="form-control width"  name="achievement_period[]"></td>

<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="achievement_remark[]"></textarea></td>
<td><input type="file" name="achievement_upload[]"></td>
<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>
</tr>
@endfor
</tbody>
 </table>     
</div>
</div>





 <div id="modalOptionalSizes" class="col-lg-12 layout-spacing">
                            <div class="statbox box box-shadow">
                                <div class="widget-content">
                                    <div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
                                      <div class="modal-dialog modal-xl" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myExtraLargeModalLabel">Employee List</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                  <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                                </button>
                                            </div>
                          <div class="layout-px-spacing">

                <div class="row layout-top-spacing" id="cancel-row">
                    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                        <div class="widget-content widget-content-area br-6">
                            <div class="table-responsive mb-4 mt-4">
                                <div class="offset-xl-8 col-xl-4 col-lg-4 col-sm-4" style="text-align: right;">
                                <input class="form-control" id="myInput" type="text" placeholder="Search..">
                              </div>

                                <br><br>
                                <table id="html5-extension" class="table" style="width:100%">
                                    <thead>
                                        <tr>
                                        
                                            <th>Employee No</th>
                                            <th>Employee Name</th>
                                            <th>Employee Code</th>
                                            <th>Edit</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody  id="myTable">
                                    @foreach($Employee_fetch as $ky=>$val)
                                           <tr>
                                         
                                               <td>{{$val->emp_no}}</td>
                                                <td>{{$val->emp_name}}</td> 
                                                <td>{{$val->employee_code}}</td>
                                                <td>    <a href="{{url('/')}}/employee_edit_master/?search_emp={{ $val->emp_no }}"  title="Edit" class="editbtn" class="btn btn-success editbtn" ><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-2 text-success"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg></a></td>
                                            </tr>
                                             @endforeach
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>

                </div>

                </div>
                                            <!-- <div class="modal-footer">
                                                <button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Discard</button>
                                                <button type="button" class="btn btn-primary">Save</button>
                                            </div> -->
                                        </div>
                                      </div>
                                    </div>
        
       
                                </div>
                            </div>
                        </div>




            <div id="modalOptionalSizes" class="col-lg-6 layout-spacing">
                            <div class="statbox box box-shadow">
                                <div class="widget-content">
                                    <div class="modal fade bd-example-modal" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
                                      <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                               <!--  <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                                                  <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                                </button> -->
                                    
                                                    <div class="modal-body">
                       <form action=""  method="post">
                   
                   <div class="form-group">
                            
                              <input type="hidden" class="form-control" name="pro_id" id="pro_id" aria-describedby="textHelp">
                              
                            </div>
                            <div class="form-group">
                              <label for="exampleInputtext1">Board/University Name</label>
                              <input type="text" class="form-control" id="pro_name" name="pro_name" aria-describedby="textHelp">
                              
                            </div>
                           
                             <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Add</button>
                      </div>
                          
                          
                       
                          </form>
                      
                      </div>
                                       
                                        </div>
                                      </div>
                                    </div>
        
       
                                </div>
                            </div>
                        </div></div></div>
                        </form>
        <!--  END CONTENT AREA  -->
</div>



 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>    
<script>


  var p = 0;  
    function portionDropdown(id){
    var portion_id = $('#portionDropdownid'+id).val();
    console.log(portion_id);
    if(id>=p){
        $('#selectdesignation').val(portion_id);
        p=id;
    }
}

var dept_select = ""; 
  function nominee_select(dependent_type,dept_selector)
  {
    if(dept_select=="" && dependent_type=="Nominee")
    {
       $("#one"+dept_selector+" option[value='Nominee']").attr('selected',true);
       dept_select = "Nominee";
    }
    else if(dept_select!="" && dependent_type=="Nominee")
    {
      alert("Nominee has already selected");
      $("#one"+dept_selector+" option[value='Dependent']").attr('selected',true);
    }
    else if(dept_select!="" && $("#one"+dept_selector+" :selected").text()=="Nominee")
    {
        $("#one"+dept_selector+" option[value='Dependent']").attr('selected',true);
        dept_select = "";
    }
    

    //alert(dependent_type);
    // if( $("#one"+id).val() == "nominee"){
    //     $("#one"+id).val('Nominee');
    //     $(".nominee").html("Dependent");
    //}


  }
  $(document).on('change', '#packageid', function(e) { 
       e.preventDefault(); 
       var pkid = $(this).val();
       //alert(pkid);
     $.ajax({
         type:'POST',
          url: "{{url('/getPackage')}}",
          dataType: "json",
         data:{
       '_token':$('input[name=_token]').val(),        
       'selectedid': pkid
        },
        success: function(data){
          if(data!=""){
         $('#catch_value').val(data[0].pay_scale);
         $('#current_allowance').val(data[0].special_allowance);
         $('#initial_allowance').val(data[0].special_allowance);
         $('#initial_other').val(data[0].other_special_allowance);
         $('#cuurent_other').val(data[0].other_special_allowance);
           }
          else{
           $('#catch_value').val("");
           $('#current_allowance').val("");
           $('#initial_allowance').val("");
           $('#initial_other').val("");
           $('#cuurent_other').val("");
           }

      }
   });
 });



function probation(id)
{
      var pkid = $('#probationid'+id).val();
       //alert(pkid);
      $('#probationid'+id).val(pkid);
     $.ajax({
         type:'POST',
          url: "{{url('/getProbation')}}",
          dataType: "json",
         data:{
       '_token':$('input[name=_token]').val(),        
       'selectedid': pkid
        },
        success: function(data){
         // console.log(data);
         $('#promotion_catch_topaygrade_value'+id).val(data[0].pay_scale);
         $('#probation_current_allowance'+id).val(data[0].special_allowance);
         $('#probation_tocurrentother_allowance'+id).val(data[0].other_special_allowance);
          }

      });
 // alert(id);
}  

function promotion(id)
{
      var pkid = $('#promotionid'+id).val();
      // alert(pkid);
      $('#promotionid'+id).val(pkid);
     $.ajax({
         type:'POST',
          url: "{{url('/getPromotion')}}",
          dataType: "json",
         data:{
       '_token':$('input[name=_token]').val(),        
       'selectedid': pkid
        },
        success: function(data){
         // console.log(data);
         $('#catch_paygrade_value'+id).val(data[0].pay_scale);
         $('#promtion_current_allowance'+id).val(data[0].special_allowance);
         $('#promtion_currentother_allowance'+id).val(data[0].other_special_allowance);
          }

      });
 // alert(id);
}
function topromotion(id)
{
   var pkid = $('#promotiontoid'+id).val();
    $.ajax({
         type:'POST',
          url: "{{url('/gettoPromotion')}}",
          dataType: "json",
         data:{
       '_token':$('input[name=_token]').val(),        
       'selectedid': pkid
        },
        success: function(data){
         // console.log(data);
         $('#catch_topaygrade_value'+id).val(data[0].pay_scale);
         $('#promtion_tocurrent_allowance'+id).val(data[0].special_allowance);
         $('#promtion_tocurrentother_allowance'+id).val(data[0].other_special_allowance);
          }

      });
}



   $(function () {
        $("#ddlModels").change(function () {
            if ($(this).val() == 'Married') {
                $("#spouseName").prop("disabled", false).focus();
                $("#spouseDOB").prop("disabled", false);
            } else {
                $("#spouseName").prop("disabled", true);
                $("#spouseDOB").prop("disabled", true);
            }
        });
    });

function showfield(name){
  //alert(name);
    if(name != 'active') {
      $(".r_class").show();
       $("#reason,#r_dob,#r_txtReason").prop("disabled",false);  
    }else{
       $(".r_class").hide();  
       $("#reason,#r_dob,#r_txtReason").prop("disabled",true);
    }
 
}

</script>
<script type="text/javascript">
  let i=5;
$("#add_newprobation").click(function () { 
  i++;
  $("#probationtable").append(`<tr>

<td><input type="text" class="form-control width" name="prob_order[]"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="prob_start[]"></td>
<td><input type="date" class="form-control"  placeholder="13/07/2008" name="prob end[]"></td>
<td>
<select class="form-control " onchange="probation(${i})"  id="probationid${i}" name="pay_grade1[]" style="width: 202px;">
   <option value="">--Select--</option>
       @foreach($pay_grade_view as $ky=>$val)
        <option value="{{$val->id}}">{{$val->pay_grade_desc}}
        </option>
       @endforeach
</select></td>
<td><input type="text" class="form-control width2" name="initial[]" id="promotion_catch_topaygrade_value${i}"  readonly="readonly" style="width: 219px;"></td>
<td><input type="number" class="form-control width2" name="special_allowance[]"id="probation_current_allowance${i}" readonly="readonly"></td>
<td><input type="number" class="form-control width2" name="other_allownace[]"id="probation_tocurrentother_allowance${i}" readonly="readonly" ></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remark_prob[]"></textarea></td>
<td><input type="file" name="prob_upload[]"></td>
</tr>`);

});
</script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
<script type="text/javascript">
  let l=5;
$("#add_new").click(function () { 
  l++;
  $("#e-body").append(`<tr>
<td class="td2"><input type="text" class="form-control width" name="name[]" placeholder=""  ></td>
<td><select class="form-control" name="dependent_type[] "style="width: 124px" id="one${l}" onchange="nominee_select(this.value,${l})" >
    <option value="Dependent">Dependent</option>
    <option value="Nominee" >Nominee</option></select></td>
<td><input type="date" class="form-control" name="dob1[]" placeholder="enter DOB"></td>
<td><input type="number" class="form-control  td1"  name="age[]" ></td>
<td class="td2"><input type="text" class="form-control width" name="relation[]" placeholder="enter your relation" style="width: 207px;"></td>
<td  class="td2"><input type="number" class="form-control width " name="num[]" placeholder="enter adhara" style="width: 206px;"  ></td>
<td><textarea rows="3" cols="40" class="form-control"  name="dependent_addr[]" style="width:200px;"></textarea></td>
<td><input type="file" class="" placeholder="67%" name="dependent_file[]" multiple></td>

<td>
   <button type="button" class="deletebtn" title="Remove row">X</button>
</td>

</tr>`);

});
$("#add_newexperience").click(function () { 
$("#tablexperience").each(function () {
   
    var tds = '<tr>';
    jQuery.each($('tr:last td', this), function () {
        tds += '<td>' + $(this).html() + '</td>';
    });
    tds += '</tr>';
    if ($('tbody', this).length > 0) {
        $('tbody', this).append(tds);
    } else {
        $(this).append(tds);
    }
});
});
 var j=4;
      $("#add_newtransferno").click(function () {  
        j++;
    $("#table_transfer").append(`<tr>
    <td><input type="text" class="form-control width" width="130px" name="trans_order[]"></td>
<td> <select class="form-control width" name="order_type[]" >
        <option>Transfer</option>
        <option>Deputation</option>
    </select></td>
<td><input type="date"  class="form-control" placeholder="05/03/2009" width="130px" name="transfer_ord_date[]"></td>
<td><input type="date"  class="form-control" placeholder="13/03/2008" name="from_date[]"></td>
<td><input type="date" class="form-control" placeholder="13/03/2008" name="to_date[]" ></td>
<td> <select class="form-control width"  name="f_dept[]">
<option>Select</option>
     @foreach($Department_fetch as $ky=>$val)
    <option value="{{$val->dept_no}}">{{$val->dept_name}}</option>
        @endforeach
  </select>
</td>
<td><select class="form-control width" name="t_dept[]" onchange="transfer(${j})"  id="transferid${j}">
<option>Select</option>
     @foreach($Department_fetch as $ky=>$val)

    <option value="{{$val->dept_no}}">{{$val->dept_name}}</option>
        @endforeach
  </select></td>
<td><select class="form-control width" name="from_work[]">
<option>Select</option>
@foreach($Workplace_fetch as $ky=>$val)

     <option value="{{$val->id}}">{{$val->workplace_name}}</option>
 @endforeach
</select></td>
<td><select class="form-control width" name="to_work[]"  onchange="transferWork(${j})"  id="transferWorkid${j}">
<option>Select</option>
@foreach($Workplace_fetch as $ky=>$val)
     <option value="{{$val->id}}">{{$val->workplace_name}}</option>
 @endforeach
</select></td>

<td> <select class="form-control width"   name="ord_rea[]">
        <option>Select</option>
        <option>Reward</option>
        <option>Routine</option>
        <option>Displinary</option>
        <option>Other</option>
    </select></td>
<td><textarea rows="3" cols="40" class="form-control width" name="reamrks[]"></textarea></td>
<td><input type="file" name="trans_file[]" ></td>
              
                </tr>`);
                j++;
             
});
var v = 0;  
    function transfer(id){
    var transfer_id = $('#transferid'+id).val();
    if(id>=v){
        $('#selectdepartment').val(transfer_id);
        v=id;
    }
    }
    var w = 0;  
    function transferWork(id){
    var work_id = $('#transferWorkid'+id).val();
    console.log(work_id);
    if(id>=w){
        $('#selectWorkplace').val(work_id);
        w=id;
    }
} 
 
var k=4;
$("#add_newpromotion").click(function () {
k++; 
//alert(k);
  $("#promo_tbl").append(`<tr>

<td><input type="text" class="form-control width" name="promo_order_no[]"></td>
<td><input type="date" class="form-control" name="promo_date[]"></td>
<td><input type="date" class="form-control" placeholder="13/03/2008" name="effect_date[]"></td>
<td>
<select class="form-control " onchange="promotion(${k})"  id="promotionid${k}" name="from_grade[]" style="width: 202px;">
   <option value="">--Select--</option>
       @foreach($pay_grade_view as $ky=>$val)
        <option value="{{$val->id}}">{{$val->pay_grade_desc}}
        </option>
       @endforeach
</select>
</td>
<td><input type="text" class="form-control" name="from_design[]"></td>

<td><input type="text" class="form-control width" name="from_basic[]" id='catch_paygrade_value${k}' style="    width: 202px;" readonly></td>
<td><input type="number" class="form-control width3" name="from_special[]" id="promtion_current_allowance${k}" readonly ></td>
<td><input type="number" class="form-control width3" name="from_other_special[]"  id="promtion_currentother_allowance${k}" readonly ></td>
<td> <select class="form-control "  onchange="topromotion(${k})" id="promotiontoid${k}" name="to_grade[]" style="width: 202px;">
   <option value="">--Select--</option>
       @foreach($pay_grade_view as $ky=>$val)
        <option value="{{$val->id}}">{{$val->pay_grade_desc}}
        </option>
       @endforeach
</select>
</td>
<td><input type="text" class="form-control " name="to_portion[]"></td>
<td><input type="text" class="form-control width" name="to_basic[]" id='catch_topaygrade_value${k}'readonly></td>
<td><input type="number" class="form-control width3" name="total_allow[]" id="promtion_tocurrent_allowance${k}" readonly></td>
<td><input type="number" class="form-control width3" name="to_other_allowance[]" id="promtion_tocurrentother_allowance${k}"readonly></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remark[]"></textarea></td>
<td><input type="file" name="upload_promo[]"></td>
</tr>`);
});
// $("#add_newprobation").click(function () { 

// $("#probationtable").each(function () {
   
//     var tds = '<tr>';
//     jQuery.each($('tr:last td', this), function () {
//         tds += '<td>' + $(this).html() + '</td>';
//     });
//     tds += '</tr>';
//     if ($('tbody', this).length > 0) {
//         $('tbody', this).append(tds);
//     } else {
//         $(this).append(tds);
//     }
// });
// });
$("#add_newqualification").click(function () { 
$("#new_qualification").each(function () {
   
    var tds = '<tr>';
    jQuery.each($('tr:last td', this), function () {
        tds += '<td>' + $(this).html() + '</td>';
    });
    tds += '</tr>';
    if ($('tbody', this).length > 0) {
        $('tbody', this).append(tds);
    } else {
        $(this).append(tds);
    }
});
});

$("#add_new1").click(function () { 

    $("#maintable1").each(function () {
       
        var tds = '<tr>';
        jQuery.each($('tr:last td', this), function () {
            tds += '<td>' + $(this).html() + '</td>';
        });
        tds += '</tr>';
        if ($('tbody', this).length > 0) {
            $('tbody', this).append(tds);
        } else {
            $(this).append(tds);
        }
    });
});
$("#add_newcontract").click(function () { 
  $("#tablecontract").each(function () {
       
       var tds = '<tr>';
       jQuery.each($('tr:last td', this), function () {
           tds += '<td>' + $(this).html() + '</td>';
       });
       tds += '</tr>';
       if ($('tbody', this).length > 0) {
           $('tbody', this).append(tds);
       } else {
           $(this).append(tds);
       }
   });
});
$("#add_new4").click(function () { 
$("#tablerevocation").each(function () {
   
    var tds = '<tr>';
    jQuery.each($('tr:last td', this), function () {
        tds += '<td>' + $(this).html() + '</td>';
    });
    tds += '</tr>';
    if ($('tbody', this).length > 0) {
        $('tbody', this).append(tds);
    } else {
        $(this).append(tds);
    }
});
});
$("#add_new5").click(function () { 
$("#tableappriciation").each(function () {
   
    var tds = '<tr>';
    jQuery.each($('tr:last td', this), function () {
        tds += '<td>' + $(this).html() + '</td>';
    });
    tds += '</tr>';
    if ($('tbody', this).length > 0) {
        $('tbody', this).append(tds);
    } else {
        $(this).append(tds);
    }
});
});
$("#add_new6").click(function () { 
$("#tablereward").each(function () {
   
    var tds = '<tr>';
    jQuery.each($('tr:last td', this), function () {
        tds += '<td>' + $(this).html() + '</td>';
    });
    tds += '</tr>';
    if ($('tbody', this).length > 0) {
        $('tbody', this).append(tds);
    } else {
        $(this).append(tds);
    }
});
});
$("#add_new7").click(function () { 
$("#tableintiation").each(function () {
   
    var tds = '<tr>';
    jQuery.each($('tr:last td', this), function () {
        tds += '<td>' + $(this).html() + '</td>';
    });
    tds += '</tr>';
    if ($('tbody', this).length > 0) {
        $('tbody', this).append(tds);
    } else {
        $(this).append(tds);
    }
});
});
$("#add_new8").click(function () { 
$("#tableachievemnt").each(function () {
   
    var tds = '<tr>';
    jQuery.each($('tr:last td', this), function () {
        tds += '<td>' + $(this).html() + '</td>';
    });
    tds += '</tr>';
    if ($('tbody', this).length > 0) {
        $('tbody', this).append(tds);
    } else {
        $(this).append(tds);
    }
});
});
</script>
            <script>
                 

$(document).ready(function(){
$("#myInput").on("keyup", function() {
var value = $(this).val().toLowerCase();
$("#myTable tr").filter(function() {
$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
});
});
});

    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
 
  <script type="text/javascript">
document.getElementById("one").onchange = function () {
  document.getElementById("two").setAttribute("disabled", "disabled");
  if (this.value == 'Nominee')
    document.getElementById("two").removeAttribute("disabled");
};
</script>
<script>

 $(document).on('click', 'button.deletebtn', function () {
     $(this).closest('tr').remove();
     return false;
 });

 

</script>

<script type = "text/javascript">
$('#input-payment-egn').keyup(function(e){
  if($(this).val().length === 10){
    e.preventDefault();
    $('#wrong-egn').slideUp();
  } else {
    $('#wrong-egn').slideDown();
  }   
});
$('#input-payment-egn1').keyup(function(e){
  if($(this).val().length === 10){
    e.preventDefault();
    $('#wrong-egn1').slideUp();
  } else {
    $('#wrong-egn1').slideDown();
  }   
});
$('#input-payment-egn2').keyup(function(e){
  if($(this).val().length === 12){
    e.preventDefault();
    $('#wrong-egn2').slideUp();
  } else {
    $('#wrong-egn2').slideDown();
  }   
});
$('#input-payment-egn3').keyup(function(e){
  if($(this).val().length === 12){
    e.preventDefault();
    $('#wrong-egn3').slideUp();
  } else {
    $('#wrong-egn3').slideDown();
  }   
});
    // function fetch_payscale(pay_scale) {
    //   //alert(pay_scale);

    //   var thisvalue = $("select#pay_grade option:selected").text();
    //   $('#catch_value').val(pay_scale);
    //   $('#pay_grade_code_hdn').val(thisvalue);
    //    $('#initial_allowance').val(thisvalue);



    //   // $('#catch_value').val(pay_scale);
    //   //$('#payGrade_id_hdn').val();
    // }
    $(document).ready(function () {
  
  // Denotes total number of rows
  var rowIdx = 0;

  // jQuery button click event to add a row
  $('#addBtn1').on('click', function () {

    // Adding a row inside the tbody.
    $('#e-body').append(`<tr id="R${++rowIdx}">
             <p>Row ${rowIdx}</p>

<td><input type="text" class="form-control width" name="cont_order[]"></td>
<td><input type="date" class="form-control" placeholder="13/07/2008" name="cont_start_date[]"></td>
<td><input type="date" class="form-control" value="13/03/2008" name="cont_end_date[]"></td>
<td><input type="number" class="form-control width2" name="con_pay[]"></td>
<td><input type="text" class="form-control width2" name="special[]"></td>
<td><input type="text" class="form-control width2" name="other[]"></td>
<td><textarea rows="3" cols="40" class="form-control width" maxlength="150" name="remarks[]"></textarea></td>
<td><input type="file" name="cont_file[]"></td>

</tr>`
          );
  });

  // jQuery button click event to remove a row.
  $('#e-body').on('click', '.remove', function () {

    // Getting all the rows next to the row
    // containing the clicked button
    var child = $(this).closest('tr').nextAll();

    // Iterating across all the rows 
    // obtained to change the index
    child.each(function () {

      // Getting <tr> id.
      var id = $(this).attr('id');

      // Getting the <p> inside the .row-index class.
      var idx = $(this).children('.row-index').children('p');

      // Gets the row number from <tr> id.
      var dig = parseInt(id.substring(1));

      // Modifying row index.
      idx.html(`Row ${dig - 1}`);

      // Modifying row id.
      $(this).attr('id', `R${dig - 1}`);
    });


  });
});

</script>


    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="{{url('/')}}/public/assets/js/libs/jquery-3.1.1.min.js"></script>
    <script src="{{url('/')}}/public/bootstrap/js/popper.min.js"></script>
    <script src="{{url('/')}}/public/bootstrap/js/bootstrap.min.js"></script>
    <script src="{{url('/')}}/public/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="{{url('/')}}/public/assets/js/app.js"></script>
    
    <script>
        $(document).ready(function() {
            App.init();
        });
    </script>
    <script src="{{url('/')}}/public/assets/js/custom.js"></script>
    <!-- END GLOBAL MANDATORY SCRIPTS -->
    <script src="{{url('/')}}/public/plugins/table/datatable/button-ext/dataTables.buttons.min.js"></script>
    <script src="{{url('/')}}/public/plugins/table/datatable/button-ext/jszip.min.js"></script>    
    <script src="{{url('/')}}/public/plugins/table/datatable/button-ext/buttons.html5.min.js"></script>
    <script src="{{url('/')}}/public/plugins/table/datatable/button-ext/buttons.print.min.js"></script>
    <script>
        $('#html5-extension').DataTable( {
            dom: '<"row"<"col-md-12"<"row"<"col-md-6"B><"col-md-6"f> > ><"col-md-12"rt> <"col-md-12"<"row"<"col-md-5"i><"col-md-7"p>>> >',
            buttons: {
                buttons: [
                    { extend: 'copy', className: 'btn' },
                    { extend: 'csv', className: 'btn' },
                    { extend: 'excel', className: 'btn' },
                    { extend: 'print', className: 'btn' }
                ]
            },
            "oLanguage": {
                "oPaginate": { "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>', "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>' },
                "sInfo": "Showing page _PAGE_ of _PAGES_",
                "sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
                "sSearchPlaceholder": "Search...",
               "sLengthMenu": "Results :  _MENU_",
            },
            "stripeClasses": [],
            "lengthMenu": [7, 10, 20, 50],
            "pageLength": 7 
        } );
    </script>

    <!-- BEGIN PAGE LEVEL SCRIPTS -->
    <script src="plugins/table/datatable/datatables.js"></script>
    <script>
        $('#zero-config').DataTable({
            "oLanguage": {
                "oPaginate": { "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>', "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>' },
                "sInfo": "Showing page _PAGE_ of _PAGES_",
                "sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
                "sSearchPlaceholder": "Search...",
               "sLengthMenu": "Results :  _MENU_",
            },
            "stripeClasses": [],
            "lengthMenu": [7, 10, 20, 50],
            "pageLength": 7 
        });
    </script>
    <!-- END PAGE LEVEL SCRIPTS -->
    <!--  BEGIN CUSTOM SCRIPTS FILE  -->

    <script src="{{url('/')}}/public/plugins/dropify/dropify.min.js"></script>
    <script src="{{url('/')}}/public/plugins/blockui/jquery.blockUI.min.js"></script>
    <!-- <script src="plugins/tagInput/tags-input.js"></script> -->
    <script src="{{url('/')}}/public/assets/js/users/account-settings.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A==" crossorigin="anonymous"></script>

</body>
</html>

                 <script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }

  </script>

@endsection