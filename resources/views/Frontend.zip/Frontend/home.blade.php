@extends('Frontend.footer')
@extends('Frontend.master')
@section('content')

 <div id="content" class="main-content">
            <div class="layout-px-spacing">                
                    
                <div class="account-settings-container layout-top-spacing">

                    <div class="account-content">
                        <div class="scrollspy-example" data-spy="scroll" data-target="#account-settings-scroll" data-offset="-100">
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                                  <div class="banner-sec">
                                       <img src="{{url('/')}}/public/assets/img/samaj-banner-100yr.jpg" class="img-fluid" alt="Snow">
                                      <div class="centered"> <span>P</span>ersonnel <span>M</span>anagement <span>S</span>ystem</div>
                                   </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                </div>
        </div>
@endsection

