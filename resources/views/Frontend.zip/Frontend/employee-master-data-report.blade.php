@extends('Frontend.employee-report-header')
@extends('Frontend.employee-report-footer')
<body>


        <!--  BEGIN CONTENT AREA  -->
        <div  class="main-content">
                <div class="">
                    <div class="row layout-top-spacing">
                        <div id="tableCaption" class="col-lg-12 col-12 layout-spacing">
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                    	<div class="col-xl-12 col-md-12 col-sm-12 col-12 text-center">
                                    		<h5 class="data-heading1">The Samaj<span>Report run on: November 23, 2020 2:14 PM</span></h5>
                                            <h3 class="data-heading">EMPLOYEE MASTER DATA REPORT</h3>
                                        </div>
                                           <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12" >
                                                  
                                                    <form method="get" action="/" class="form-inline report-area">
                                                        <label>Employee Type:</label>
                                                    <select class="col-lg-4 form-control">
                                                      <option>All </option>
                                                      <option>Permanent </option>
                                                      <option>Probation </option>
                                                    </select>
                                                      &nbsp;&nbsp;
                                                    	<label>Category:</label>
                                                   <select class="col-lg-4 form-control">
                                                      <option>All Category</option>
                                                      <option>All Category</option>
                                                      <option>All Category</option>
                                                   </select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    
									                <button type="submit" class="btn btn-primary report-btn" value="">Search</button>
									                </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area"  style="padding-bottom: 0px;">
                                	<!-- <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
                                	<button class="btn btn-secondary" onclick="window.pdf()"><i class="fa fa-file"></i> Save</button> -->
                                    <div class="table-responsive" style="margin-top: 5px;">
                                        <table class="table mb-4">
                                          <thead>
                                                <tr>
                                                    <th class="text-center">Sl No</th>
                                                    <th>Employee. Name</th>
                                                    <th>Address</th>
                                                    <th class="">Contact No</th>
                                                    <th class="">Emp. Code
                                                    </th>
                                                    <th class="">Designation</th>
                                                    <th class="">Department</th>
                                                    <th class="">Type Of Employee</th>
                                                    <th class="">Category</th>
                                                    <th class="">DOJ</th>
                                                    <th class="">Date Of Confirmation</th>
                                                    <th>DOB</th>
                                                    <th>Date Of Retirement</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center">01  </td>
                                                    <td class="text-primary">SUSANTA KUMAR MOHANTY</td>
                                                    <td> Bhubaneswar</td>
                                                    <td class="">9437053330</td>
                                                    <td>006</td>
                                                    <td>Reporter</td>
                                                    <td>Editorial</td>
                                                    <td>Contract</td>
                                                    <td>Working Jounalists</td>
                                                    <td>07/10/1998</td>
                                                    <td>01/10/1999</td>
                                                    <td>15/05/1664</td>
                                                    <td>14/08/2022</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">01  </td>
                                                    <td class="text-primary">SASHI RANJAN MALLIK</td>
                                                    <td>At-Ganga Mandir, Po-Buxibazar, Cuttack</td>
                                                    <td class="">9437053330</td>
                                                    <td>003</td>
                                                    <td>Editor</td>
                                                    <td>Editorial</td>
                                                    <td>Contract</td>
                                                    <td>Working Jounalists</td>
                                                    <td>07/10/1998</td>
                                                    <td>01/10/1999</td>
                                                    <td>15/05/166</td>
                                                    <td>14/08/2022</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">01  </td>
                                                    <td class="text-primary">DEBI PRASAD MOHANTY</td>
                                                    <td>At-Ganga Mandir, Po-Buxibazar, Cuttack</td>
                                                    <td class="">9437053330</td>
                                                    <td>007</td>
                                                    <td>Editor</td>
                                                    <td>Balasore Ofice</td>
                                                    <td>Contract</td>
                                                    <td>Working Jounalists</td>
                                                    <td>07/10/1998</td>
                                                    <td>01/10/1999</td>
                                                    <td>15/05/1789</td>
                                                    <td>14/08/2022</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center">01  </td>
                                                    <td class="text-primary">ASIS KU. MOHANTY</td>
                                                    <td>At-Ganga Mandir, Po-Buxibazar, Cuttack</td>
                                                    <td class="">9437053330</td>
                                                    <td>008</td>
                                                    <td>Editor</td>
                                                    <td>Editorial</td>
                                                    <td>Contract</td>
                                                    <td>Working Jounalists</td>
                                                    <td>07/10/1998</td>
                                                    <td>01/10/1999</td>
                                                    <td>15/05/1894</td>
                                                    <td>14/08/2022</td>
                                                </tr>
                                            </tbody>
                                        </table>
                              
                                    </div>


                                </div>
                                 <div class="widget-header" style="padding: 20px;">
                                    <div class="row">
                                    	<div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<a href="#">Page 1 of 17</a>
                                        </div>
                                        <div class="col-xl-6 col-md-12 col-sm-12 col-12 ">
                                    		<div class="pagination">
											  <a href="#">&laquo;</a>
											  <a href="#">1</a>
											  <a href="#" class="active">2</a>
											  <a href="#">3</a>
											  <a href="#">4</a>
											  <a href="#">5</a>
											  <a href="#">6</a>
											  <a href="#">&raquo;</a>
											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

        </div>
        <!--  END CONTENT AREA  -->
       