<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use DB;
class Employee_Master extends Model
{
    //
    protected $table = 'emp_mst';
    protected $fillable = ['emp_no','emp_name','emp_type','dept_no','desg_code',
    'DOB','DOJ','DOP','retirement_date','emp_type','active_type','inactive_reason','catg','wrok_place','image'];

  public static function Employee_Master_view()
    {
        $Employee_view = DB::table('emp_mst')
                        ->orderBy('id','DESC')
                        ->get();

        return $Employee_view;
  }

  public static function Employee_Master_Last_record_view()
    {
        $Employee_Last_record_view = DB::table('emp_mst')
                        ->orderBy('id','DESC')
                        ->limit(1)
                        ->first();
        $emp_no =  $Employee_Last_record_view->emp_no;            
        return $emp_no;
  }
  public static function Employee_Master_first_record_view()
    {
        $Employee_first_record_view = DB::table('emp_mst')
                        ->orderBy('id','ASC')
                        ->limit(1)
                        ->first();
        $empfirst_no =  $Employee_first_record_view->emp_no;            
        return $empfirst_no;
  }
    public static function Employee_Master_delete_record_view($request)
    {
        $empno = $request->input('search_emp');
     
        $Employee_id =DB::table('emp_mst')
                      ->select('id')
                      ->where('emp_no',$empno)
                      ->first();
       $empdlt_no =  $Employee_id->id;    
       $empnext_no = DB::table('emp_mst')
                     ->select('id')                      
                     ->where('id',$empdlt_no) 
                     ->delete();  
       $empnext_no = DB::table('empmst_official')
                     ->select('id')                      
                     ->where('id',$empdlt_no) 
                     ->delete();  
       $empnext_no = DB::table('emp_dependent_dtl')
                     ->select('id')                      
                     ->where('emp_no',$empdlt_no) 
                     ->delete(); 
       $empnext_no = DB::table('emp_nominee_dtl')
                     ->select('id')                      
                     ->where('emp_no',$empdlt_no) 
                     ->delete();
       $empnext_no = DB::table('emp_qualification_dtl')
                     ->select('id')                      
                     ->where('emp_no',$empdlt_no) 
                     ->delete();
       $empnext_no = DB::table('emp_experience_dtl')
                 ->select('id')                      
                 ->where('emp_no',$empdlt_no) 
                 ->delete(); 
       $empnext_no = DB::table('emp_trnasfer_dtl')
                 ->select('id')                      
                 ->where('emp_no',$empdlt_no) 
                 ->delete();
       $empnext_no = DB::table('employee_promotion_dtl')
                 ->select('id')                      
                 ->where('emp_no',$empdlt_no) 
                 ->delete();   
       $empnext_no = DB::table('emp_probation_dtl')
                 ->select('id')                      
                 ->where('emp_no',$empdlt_no) 
                 ->delete();
       $empnext_no = DB::table('emp_contract_dtl')
                 ->select('id')                      
                 ->where('emp_no',$empdlt_no) 
                 ->delete();
        $empnext_no = DB::table('emp_antecedent_dtl')
                 ->select('id')                      
                 ->where('emp_no',$empdlt_no) 
                 ->delete();
       $empnext_no = DB::table('emp_revocation_dtl')
       ->select('id')                      
       ->where('emp_no',$empdlt_no) 
       ->delete();                                       
                                                                
        return $empdlt_no;
  }
    public static function Employee_Master_next_record_view($request)
    {
        $empno = $request->input('search_emp');
     
        $Employee_id =DB::table('emp_mst')
                                    ->select('id')
                                    ->where('emp_no',$empno)
                                    ->first();
        $id = $Employee_id->id;

       $empnext_no = DB::table('emp_mst')
                       ->where('id', '>', $id)
                       ->select('emp_no')
                       ->min('id');
      if($empnext_no>0)
       {
           $Empno_next =DB::table('emp_mst')
                            ->select('emp_no')                      
                            ->where('id',$empnext_no)
                            ->first();
           return $Empno_next->emp_no;
      }
       else
       {
            return $Empno_next="";
       }               
    }
    public static function Employee_Master_previous_record_view($request)
    {
        $empno = $request->input('search_emp');
     
        $Employee_id =DB::table('emp_mst')
                                    ->select('id')
                                    ->where('emp_no',$empno)
                                    ->first();
        $id = $Employee_id->id;
  //$previous = User::where('id', '<', $user->id)->max('id');
       $empnext_no = DB::table('emp_mst')
                       ->where('id', '<', $id)
                       ->select('emp_no')
                       ->max('id');
      if($empnext_no>0)
       {
           $Empno_next =DB::table('emp_mst')
                            ->select('emp_no')                      
                            ->where('id',$empnext_no)
                            ->first();
           return $Empno_next->emp_no;
      }
       else
       {
            return $Empno_next="";
       }               
    }
   


   public function getAllEmployeeInfo($employee_number) 
     {
 
      $employeeListing = DB::table('emp_mst')            
        ->where('emp_no',$employee_number)
        ->first();      
       //echo"<pre>";print_r($employeeListing );echo"</pre>";exit();

    return $employeeListing;
        }
    public function getAllEmployeeOfficialInfo($employee_number) 
     {
      // $OfficialListing= DB::table('emp_mst')
      //       ->select('id')            
      //       ->where('emp_no',$employee_number)
      //       ->first();
      //       $off_id = $OfficialListing->id;

      $official_user_info = DB::table('empmst_official')->where('emp_no',$employee_number)->first(); 
       // echo"<pre>";print_r($OfficialListing );echo"</pre>";exit();
      return $official_user_info;
        }
    public function getAllNomineeInfo($employee_number) 
     {
      $NomineeListing= DB::table('emp_mst')
            ->select('id')            
            ->where('emp_no',$employee_number)
            ->first();
      $nom_id = $NomineeListing->id;

      $Nominee_user_info = DB::table('emp_nominee_dtl')->where('emp_no',$nom_id)->first(); 
       // echo"<pre>";print_r($Nominee_user_info );echo"</pre>";exit();
      return $Nominee_user_info;
        }

   public function getDependentInfo($employee_number) 
      {
        $dependent_user_info = DB::table('emp_dependent_dtl')->where('emp_no',$employee_number)->get(); 
       // echo"<pre>";print_r($dependent_user_info );echo"</pre>";exit();
      return $dependent_user_info;
        }
      public function getAllQualificationInfo($employee_number) 
      {
      // $QualificationListing= DB::table('emp_mst')
      //       ->select('id')            
      //       ->where('emp_no',$employee_number)
      //       ->first();
      // $qual_id = $QualificationListing->id;

      $Qualification_user_info = DB::table('emp_qualification_dtl')->where('emp_no',$employee_number)->get(); 
        //echo"<pre>";print_r($Qualification_user_info );echo"</pre>";exit();
      return $Qualification_user_info;
        }  

     public function getExperienceInfo($employee_number) 
      {
      // $ExperienceListing= DB::table('emp_mst')
      //       ->select('id')            
      //       ->where('emp_no',$employee_number)
      //       ->first();

      // $Experience_id = $ExperienceListing->id;

      $Experience_user_info = DB::table('emp_experience_dtl')->where('emp_no',$employee_number)->get(); 
       // echo"<pre>";print_r($Experience_user_info );echo"</pre>";exit();
      return $Experience_user_info;
        }
      public function getTransferInfo($employee_number) 
      {
      // $TransferListing= DB::table('emp_mst')
      //       ->select('id')            
      //       ->where('emp_no',$employee_number)
      //       ->first();

      // $Transfer_id = $TransferListing->id;

      $Transfer_user_info = DB::table('emp_trnasfer_dtl')->where('emp_no',$employee_number)->get(); 
       // echo"<pre>";print_r($Transfer_user_info );echo"</pre>";exit();
      return $Transfer_user_info;
        }  

      public function getPromotionInfo($employee_number) 
      {
      // $PromotionListing= DB::table('emp_mst')
      //       ->select('id')            
      //       ->where('emp_no',$employee_number)
      //       ->first();

      // $Promotion_id = $PromotionListing->id;

      $Promotion_user_info = DB::table('employee_promotion_dtl')->where('emp_no',$employee_number)->get(); 
       // echo"<pre>";print_r($Promotion_user_info );echo"</pre>";exit();
      return $Promotion_user_info;
        } 


    public function getProbationInfo($employee_number) 
      {
      // $ProbationListing= DB::table('emp_mst')
      //       ->select('id')            
      //       ->where('emp_no',$employee_number)
      //       ->first();

      // $Probation_id = $ProbationListing->id;

      $Probation_user_info = DB::table('emp_probation_dtl')->where('emp_no',$employee_number)->get(); 
       // echo"<pre>";print_r($Probation_user_info );echo"</pre>";exit();
      return $Probation_user_info;
        } 



      public function getContractInfo($employee_number) 
      {
      // $ContractListing= DB::table('emp_mst')
      //       ->select('id')            
      //       ->where('emp_no',$employee_number)
      //       ->first();

      // $Contract_id = $ContractListing->id;

      $Contract_user_info = DB::table('emp_contract_dtl')->where('emp_no',$employee_number)->get(); 
       // echo"<pre>";print_r($Contract_user_info );echo"</pre>";exit();
      return $Contract_user_info;
        } 



    public function getAntecedentInfo($employee_number) 
      {
      $AntecedentListing= DB::table('emp_mst')
            ->select('id')            
            ->where('emp_no',$employee_number)
            ->first();

      $Antecedent_id = $AntecedentListing->id;

      $Antecedent_user_info = DB::table('emp_antecedent_dtl')->where('emp_no',$Antecedent_id)->get(); 
       // echo"<pre>";print_r($Antecedent_user_info );echo"</pre>";exit();
      return $Antecedent_user_info;
        } 


   public function getRevocationInfo($employee_number) 
      {
      $RevocationListing= DB::table('emp_mst')
            ->select('id')            
            ->where('emp_no',$employee_number)
            ->first();

      $Revocation_id = $RevocationListing->id;

      $Revocation_user_info = DB::table('emp_revocation_dtl')->where('emp_no',$Revocation_id)->get(); 
       // echo"<pre>";print_r($Revocation_user_info );echo"</pre>";exit();
      return $Revocation_user_info;
        } 

    /**/
       public function getIntitionInfo($employee_number) 
      {
      $IntitionListing= DB::table('emp_mst')
            ->select('id')            
            ->where('emp_no',$employee_number)
            ->first();

      $Intition_id = $IntitionListing->id;

      $Intition_user_info = DB::table('emp_initiation_dtl')->where('emp_no',$Intition_id)->get(); 
       // echo"<pre>";print_r($Intition_user_info );echo"</pre>";exit();
      return $Intition_user_info;
        }

    public function getAchievementInfo($employee_number) 
      {
      $AchievementListing= DB::table('emp_mst')
            ->select('id')            
            ->where('emp_no',$employee_number)
            ->first();

      $Achievement_id = $AchievementListing->id;

      $Achievement_user_info = DB::table('emp_achievement_dtl')->where('emp_no',$Achievement_id)->get(); 
       // echo"<pre>";print_r($Achievement_user_info );echo"</pre>";exit();
      return $Achievement_user_info;
        }
      public function getappreciationInfo($employee_number) 
        {
        $AppreciationListing= DB::table('emp_mst')
              ->select('id')            
              ->where('emp_no',$employee_number)
              ->first();
  
        $Revocation_id = $AppreciationListing->id;
  
        $appreciation_user_info = DB::table('emp_appreciation')->where('emp_no',$Revocation_id)->get(); 
         // echo"<pre>";print_r($appreciation_user_info);echo"</pre>";exit();
        return $appreciation_user_info;
          }
       public function getRewardInfo($employee_number) 
          {
          $AppreciationListing= DB::table('emp_mst')
                ->select('id')            
                ->where('emp_no',$employee_number)
                ->first();
    
          $Revocation_id = $AppreciationListing->id;
    
          $reward_user_info = DB::table('emp_reward')->where('emp_no',$Revocation_id)->get(); 
           // echo"<pre>";print_r($appreciation_user_info);echo"</pre>";exit();
          return $reward_user_info;
            }  
          
}
