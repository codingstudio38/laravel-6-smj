<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
class TemplateController extends Controller
{
    //
    public function index()
    {
    	return view('Frontend.home');
    }
   public function logout(Request $request) 
   {
    Auth::logout();
    return redirect('/');
   }
}
