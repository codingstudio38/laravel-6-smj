<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Board;
use App\Workplace;
use App\Department_master;
use App\Designation;
use App\Pay_grade_master;
use App\Bank;
use App\Employee_Master;
use App\emp_official;
use App\Category;
use App\Employee_type;
use App\Nominee;
use App\Dependent;
use App\Qualification;
use App\Experience;
use App\Promotion;
use App\Transfer;
use App\Probation;
use App\Contract;
use App\Antecedent;
use App\Revocation;
use DB;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }
/*Department Master detail(master page)*/
    public function Department_Master_view(Request $request)
       {
        $Department_view = Department_master::Department_view();
    return view('Frontend.department-master', ['Department_view' => $Department_view ]);
       }

    public function Add_Department(Request $request)
       {
         $Add_Department1 = new Department_master();
         $Add_Department_deptno = $request->dept_no;
         $Add_Department = $request->dept_name;
         $add_dept_zero = "0{$Add_Department_deptno}";
         $Add_Department1->dept_no = $add_dept_zero;
         $Add_Department1->dept_name =$Add_Department;
         $isExist = Department_master::select("*")
                        ->where("dept_name", $Add_Department)
                        ->exists();
                if ($isExist ) {
                return redirect()->back()->with('alert', 'the department is already exsits');
                        }
                        else
                        {
                           $Add_Department1->save();
                        }
         
         return redirect('/department-master');
       }

    public function Update_Department_Data(Request $request)
     {
         $dept_id = $request->dept_id;
         $dept_no= $request->dept_no; 
         $dept_name= $request->dept_name; 
         $dept_fetch =array(
                        'dept_no' => $dept_no,
                        'dept_name' => $dept_name
                            );
         $update_Data=DB::table('dept_master')
                      ->where('id',  $dept_id)
                      ->update($dept_fetch); 
                      return redirect('/department-master');
     }
     public function Delete_Department_data($id)
    {
     $Department_data_all = Department_master::find($id);
     $Department_data_all->delete();
     return redirect('/department-master');
    }

  /*Designation detail(master page)*/
    public function Designation_Master_view(Request $request)
       {
        $Designation_view = Designation::Designation_Master_view();
        return view('Frontend.designation-master',["Designation_view"=>$Designation_view]);
       }

    public function Add_Designation_Master(Request $request)
       {
         $Add_Designation = new Designation();
         $Add_Designation_code = $request->desg_code;
         $Add_Designation_name = $request->desg_name;
         $Add_Designation->desg_code =  $Add_Designation_code;
         $Add_Designation->desg_name =$Add_Designation_name;
           $isExist = Designation::select("*")
                        ->where("desg_name", $Add_Designation_name)
                        ->exists();
                if ($isExist ) {
                return redirect()->back()->with('alert', 'the designation is already exsits');
                        }
                        else
                        {
                          $Add_Designation->save();
                        }
          return redirect('/designation-master');
       }
    public function Update_Designation_data(Request $request)
       {
         $desg_id = $request->desg_id;
         $desg_code = $request->desg_code;
         $desg_name= $request->desg_name; 
         $desg_fetch =array(
                        'desg_code' => $desg_code,
                        'desg_name' => $desg_name
                            );

         $update_Data=DB::table('desg_mst')
                      ->where('id',  $desg_id)
                      ->update($desg_fetch); 
                      return redirect('/designation-master');

        }
      public function Delete_Designation_data($id)
          {
           $Designation_data_all = Designation::find($id);
           $Designation_data_all->delete();
           return redirect('/designation-master');
          }




  /*Board/university detail(master page)*/

  public function Board_view(Request $request)
  {
  $Board_view = DB::table('board')->paginate(10);

   return view('Frontend.board-university',["Board_view"=>$Board_view]);
  }

    public function AddBoard(Request $request)
       {
         $AddBoard = new Board();
         $AddBoardName = $request->board_name;
         $AddBoard->board_name =  $AddBoardName;
         $isExist = Board::select("*")
                        ->where("board_name", $AddBoardName)
                        ->exists();
                if ($isExist ) {
                return redirect()->back()->with('alert', 'the Board/University is already exsits');
                        }
                        else
                        {
                          $AddBoard->save();
                        }
        
         return redirect('/board-university');
       }

    public function Update_Board_data(Request $request)
    {

         $board_id = $request->board_id;
         $board_name= $request->board_name; 
         $board_fetch =array(
                        'board_name' => $board_name,
                            );

         $update_Data=DB::table('board')
                      ->where('id',  $board_id)
                      ->update($board_fetch); 
                      return redirect('/board-university');

    }
    
    public function Delete_Board_data($id)
    {
     $Board_data_all = Board::find($id);
     $Board_data_all->delete();
     return redirect('/board-university');
    }

/*Workplace detail(master page)*/

    public function Work_place_view(Request $request)
       {
        $workplace_master_view = Workplace::workplace_master_view();
        return view('Frontend.workplace',["workplace_master_view"=>$workplace_master_view]);
       }

    public function AddWorkplace(Request $request)
       {
         $Workplace = new Workplace();
         $Workplace_name  = $request->workplace_name;
         $Workplace->workplace_name =  $Workplace_name;
         $isExist = Workplace::select("*")
                        ->where("workplace_name", $Workplace_name)
                        ->exists();
                if ($isExist )
                 {
                return redirect()->back()->with('alert', 'the workplace is already exsits');
                        }
                        else
                        {
                              $Workplace->save();
                        }
        
   
         return redirect('/workplace');
       }

    public function Update_WorkPlace_data(Request $request)
    {

         $work_id = $request->work_id;
         $workplace_name= $request->workplace_name; 
         $workplace_fetch =array(
                        'workplace_name' => $workplace_name,
                            );

         $update_Data=DB::table('workplace')
                      ->where('id',  $work_id)
                      ->update($workplace_fetch); 
                      return redirect('/workplace');

    }
    public function Delete_WorkPlace_data($id)
      {
       $workplace_data_all = Workplace::find($id);
       $workplace_data_all->delete();
       return redirect('/workplace');
      }

  /*Paygrade detail(master page)*/
    public function Paygrade_view(Request $request)
       {
        $Paygrade_view = Pay_grade_master::Pay_grade_Master_view();
        return view('Frontend.pay-grade-master',["Paygrade_view"=>$Paygrade_view]);
       }
     public function AddPaygrade(Request $request)
       {
         $Paygrade = new Pay_grade_master();
         $grade_code  = $request->grade_code;
         $pay_grade_desc  = $request->pay_grade_desc;
         $pay_scale  = $request->pay_scale;
         $Paygrade->pay_grade_code =  $grade_code;
         $Paygrade->pay_grade_desc =  $pay_grade_desc;
         $Paygrade->pay_scale =  $pay_scale;
         $Paygrade->save();
         return redirect('/pay-grade-master');
       }
      public function Update_Paygrade_Data(Request $request)
       {
         $Paygrade_id = $request->scale_id;
         $gradecode = $request->grade_code;
         $description= $request->description; 
         $payscale_detail= $request->pay_scale; 
         $Paygrade_fetch =array(
                        'pay_grade_code' => $gradecode,
                        'pay_grade_desc' => $description,
                        'pay_scale' => $payscale_detail,
                            );

         $update_Data=DB::table('pay_grade_mst')
                      ->where('id',  $Paygrade_id)
                      ->update($Paygrade_fetch); 
                      return redirect('/pay-grade-master');

        }
     public function Delete_Paygrade_data($id)
      {
       $Paygrade_data_all = Pay_grade_master::find($id);
       $Paygrade_data_all->delete();
       return redirect('/pay-grade-master');
      }

  /*Bank detail(master page)*/

    public function Bank_view(Request $request)
       {
        $Bank_view = Bank::Bank_view();
        return view('Frontend.bank',["Bank_view"=>$Bank_view]);
       }
    public function AddBank(Request $request)
       {
         $Bank = new Bank();
         $bank_code  = $request->bank_code;
         $bank_name = $request->bank_name;
         $ifsc_code  = $request->ifsc_code;
         $bank_address  = $request->address;
         $Bank->bank_code =  $bank_code;
         $Bank->bank_name =  $bank_name;
         $Bank->ifsc_code =  $ifsc_code;
         $Bank->address =  $bank_address;
         $Bank->save();
         return redirect('/bank');
       }
      public function Update_Bank_Data(Request $request)
       {
         $Bank_id = $request->bank_id;
         $Bankcode = $request->bank_code;
         $Bankname= $request->bank_name; 
         $Bank_ifsc= $request->bank_ifsc; 
         $Bank_address= $request->address; 
         $Bank_fetch =array(
                        'bank_code' => $Bankcode,
                        'bank_name' => $Bankname,
                        'ifsc_code' => $Bank_ifsc,
                        'address' => $Bank_address,
                            );

         $update_Data=DB::table('bank_mst')
                      ->where('id',  $Bank_id)
                      ->update($Bank_fetch); 
                      return redirect('/bank');

        }
      public function Delete_Bank_data($id)
      {
       $Bank_data_all = Bank::find($id);
       $Bank_data_all->delete();
       return redirect('/bank');
      }

/*Employee Master Page*/

    public function Employee_view(Request $request)
       {
        //$Employee_master_fetch = Employee_Master::Employee_Master_view();
         $Board_view = Board::Board_view();
        $Employee_fetch = Employee_Master::Employee_Master_view();
        $Department_fetch = Department_master::all();
        $Designation_fetch = Designation::all();
        $Workplace_fetch = Workplace::all();
        $Category_fetch = Category::all();
        $pay_grade_view = Pay_grade_master::Pay_grade_Master_view();
        $Employee_type_fetch =Employee_type::all();
        $Board_University_fetch =Board::all();
        $antecendent_fetch = Antecedent::all(); 
              $qualification_view = Qualification::Qualification_view();
        return view('Frontend.employee-master',["Employee_fetch" =>$Employee_fetch,"Department_fetch"=>$Department_fetch,"Designation"=>$Designation_fetch,"Workplace_fetch" => $Workplace_fetch,"Category_fetch"=> $Category_fetch,"Employee_type_fetch"=>$Employee_type_fetch,'pay_grade_view' => $pay_grade_view,"Board_University_fetch"=>$Board_University_fetch,"antecendent_fetch" => $antecendent_fetch, "Board_view"=> $Board_view,"qualification_view"=>$qualification_view]);
       }

       public function AddEmployeeMaster(Request $request)
       {
         $Employee_Master = new Employee_Master();
         $Employee_Master_Official = new emp_official();
         $Employee_Master_Nominee = new Nominee();
         
         $employee_number = $request->emp_no;
         $active_type= $Employee_Master->active_type = $request->type; 
         /*   $this->validate($request, [
                    'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                ]);*/
            //$name="";
           if ($request->hasFile('image')) 
                {
                    $image = $request->file('image');
                    $name = rand().time().'.'.$image->getClientOriginalExtension();
                    $destinationPath = public_path('/image/');
                    $image->move($destinationPath, $name);




                    $img = file_get_contents(public_path().'/image/'.$name);

                    //force_download($img, $img);
                    $im = imagecreatefromstring($img);

                    $width = imagesx($im);
                    $height = imagesy($im);

                    $newwidth1 = 200;
                    $newheight1 = 205;

                    $old_x          =   $width;
                    $old_y          =   $height;

                    if($old_x > $old_y)
                    {
                        $thumb_w    =   $newwidth1;
                        $thumb_h    =   $old_y*($newheight1/$old_x);
                    }

                    if($old_x < $old_y)
                    {
                        $thumb_w    =   $old_x*($newwidth1/$old_y);
                        $thumb_h    =   $newheight1;
                    }

                    if($old_x == $old_y)
                    {
                        $thumb_w    =   $newwidth1;
                        $thumb_h    =   $newheight1;
                    }

                    if($width<200 && $height>205)
                    {
                        $thumb_w    =   $old_x*($newwidth1/$old_y);
                        $thumb_h    =   $newheight1;

                    }

                    if($width>200 && $height<205)
                    {
                        $thumb_w    =   $newwidth1;
                        $thumb_h    =   $old_y*($newheight1/$old_x);

                    }
                    if($width<200 && $height<205)
                    {
                        $thumb_w    =   $width;
                        $thumb_h    =   $height;

                    }

                    $thumb1 = imagecreatetruecolor($thumb_w, $thumb_h);
                    imagecopyresized($thumb1, $im, 0, 0, 0, 0, $thumb_w, $thumb_h, $width, $height);
                    imagepng($thumb1,public_path().'/image/'.$name); //save image as jpg
                    imagedestroy($thumb1);
                }
                else

                {
                  $name=null;
                }
             if($active_type=="inactive")
             {
             $Employee_Master->image  =  $name;
            $emp_no = $Employee_Master->emp_no  = $request->emp_no;
             $Employee_Master->emp_name = $request->emp_name;
             $Employee_Master->dept_no  = $request->department;
             $Employee_Master->desg_code  = $request->designation;      
             $Employee_Master->catg  = $request->category;
             $Employee_Master->work_place = $request->workplace;
             $Employee_Master->DOB  = $request->DOB;
             $Employee_Master->DOJ  = $request->DOJ;
             $Employee_Master->DOP  = $request->DOP;
             $Employee_Master->retirement_date  = $request->retirement_date;     
             $Employee_Master->employee_code  = $request->emp_code;
             $Employee_Master->emp_type = $request->emp_type;
             $Employee_Master->pf_ded = $request->optradio;
             $Employee_Master->esi_ded = $request->optradio1;
             $Employee_Master->grade_code = $request->pay_grade_code_hdn;
             $Employee_Master->pf_ac_no = $request->pf;
             $Employee_Master->vpf_perc = $request->vpf;
             $Employee_Master->esi_ac_no = $request->esi;
             $Employee_Master->pan_no = $request->PAN;
             $Employee_Master->UAN = $request->uan;
             $Employee_Master->adhara_no = $request->adhar;
             $Employee_Master->sex = $request->sex;
             $Employee_Master->marital_status = $request->marital;
             $Employee_Master->blood_group = $request->blood;
             $Employee_Master->id_mark = $request->id;
             $Employee_Master->spouse_name = $request->spouse;
             $Employee_Master->father_name = $request->father;
             $Employee_Master->present_address1 = $request->line_11;
             $Employee_Master->present_address2 = $request->line_22;
             $Employee_Master->present_address3 = $request->line_33;
             $Employee_Master->permanent_address1 = $request->per_line1;
             $Employee_Master->permanent_address2 = $request->per_line2;
             $Employee_Master->permanent_address3 = $request->per_line3;
             $Employee_Master->ph_no = $request->contactnumber;
             $Employee_Master->email = $request->email;
             $Employee_Master->mother_name = $request->mother;
             $Employee_Master->spouse_dob = $request->spouse_dob;
             $Employee_Master->father_dob = $request->father_dob;
             $Employee_Master->mother_dob = $request->mother_dob;
             $Employee_Master->reason_desc=$request->inactive;
             $Employee_Master->inactive_reason =$request->reason;
             $isExist = Employee_Master::select("*")
                            ->where("emp_no",  $emp_no )
                            ->exists();
                    if ($isExist ) {
               return redirect()->back()->with('alert', 'the employee number is already exsits');
                            }
                            else
                            {
                               $Employee_Master->save( );
                            }
            
             
             $LastEmpId = DB::getPdo()->lastInsertId();
//official table add//  
        $Employee_Master_Official->emp_no=$LastEmpId;
        $Employee_Master_Official->pay_grade=$request->pay_grade;
        $Employee_Master_Official->intial_special=$request->intial;
        $Employee_Master_Official->current_special=$request->current;
        $Employee_Master_Official->intial_other_special=$request->initial_other;
        $Employee_Master_Official->current_other_special=$request->current_other;
        $Employee_Master_Official->save();//
   
//nominee table add//
        $Employee_Master_Nominee->emp_no=$LastEmpId;
        $Employee_Master_Nominee->nominee_name=$request->nominee_name;
        $Employee_Master_Nominee->relationship=$request->relationship;
        $Employee_Master_Nominee->address1=$request->line1;
        $Employee_Master_Nominee->address2=$request->line2;
        $Employee_Master_Nominee->address3=$request->line3;
        $Employee_Master_Nominee->contact_ph_no=$request->phonenumber;
        $Employee_Master_Nominee->adhara_number=$request->adhara;
        $Employee_Master_Nominee->nominee_dob=$request->dob;
        $Employee_Master_Nominee->save();

//dependent table add//
        $name_arr=$request->name;
        $relation_arr = $request->relation;
        $age_arr = $request->age;
        $dob_arr = $request->dob1;
        $adhar_num_arr = $request->num;
         $images=array();
            if($files=$request->file('dependent_file'))
            {  $ctr_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                    $new_filename =$emp_no.date('ymdhis').$ctr_img.'.png';
                    $file->move(public_path().'/dependent/',$new_filename );  
                    $images[$key]=$new_filename;

                    $ctr_img++;
                }
            }

            //print_r($images);exit;
            if(count($name_arr)>0)
            {

                foreach($name_arr as $ky=>$val)
                {
                    if($name_arr[$ky]!="")
                    {//echo $name_arr[$ky].'<br>';

                       $Employee_Master_Dependent = new Dependent();
                       $Employee_Master_Dependent->emp_no= $LastEmpId ;
                       $Employee_Master_Dependent->depd_name= $name_arr[$ky];
                       $Employee_Master_Dependent->relationship=$relation_arr[$ky];
                       $Employee_Master_Dependent->age=$age_arr[$ky];
                       $Employee_Master_Dependent->depd_dob=$dob_arr[$ky];
                       $Employee_Master_Dependent->depd_adhara_no=$adhar_num_arr[$ky];
                       //$count = count($data);
                       if (!empty($images[$ky])) {
                          $Employee_Master_Dependent->upload_adhara =  $images[$ky];
                       }
                       else
                       {
                         $Employee_Master_Dependent->upload_adhara = null;
                       }
                     
                      

                       $Employee_Master_Dependent->save(); 
                     // echo   $Employee_Master_Dependent->upload_adhara;
                      //exit();
                    }

                }
            }
//qualification table add//
            $quali_arr=$request->academic;
           // print_r($quali_arr);exit();
            $stream_arr = $request->stream;
            $board_arr = $request->board_name_ajax1;
            $year_arr = $request->year;
            $per_mark_arr = $request->per_mark;
            $data_qual=array();
            if($files=$request->file('qualification_file'))
            {$ctr_qual_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                     $new_file_qual_name =$emp_no.date('ymdhis').$ctr_qual_img.'.png';
                    $file->move(public_path().'/qualification/', $new_file_qual_name);  
                    $data_qual[$key]=$new_file_qual_name;

                    $data_qual++;
                }
            }

             if(count($quali_arr)>0)
            {
                foreach($quali_arr as $ky=>$val)
                {
                    if($stream_arr[$ky]!="")
                    {
                  $Employee_Master_Qualification = new Qualification();
                       
                  $Employee_Master_Qualification->emp_no =   $LastEmpId;
                  $Employee_Master_Qualification->qualification_type = $quali_arr[$ky];
                  $Employee_Master_Qualification->stream_subject =$stream_arr[$ky];
                  $Employee_Master_Qualification->institution =$board_arr[$ky];
                  $Employee_Master_Qualification->year_passing =$year_arr[$ky];
                  $Employee_Master_Qualification->mark_perc =$per_mark_arr[$ky]; 
                  if (!empty($data_qual[$ky])) {
                         $Employee_Master_Qualification->upload  =  $data_qual[$ky];
                       }
                       else
                       {
                         $Employee_Master_Qualification->upload = null;
                       }
                  //$Employee_Master_Qualification->upload =$upload[$ky];  
                  $Employee_Master_Qualification->save(); 

                    }
                    

                }

             }
//experience table add//
            $org_arr=$request->orgn;
            $sector_arr = $request->sect;
            $position_arr = $request->pos;
            $start_date_arr = $request->from;
            $end_date_arr = $request->to;
            $reson_arr =$request->area;
            $upload_pic=array();
            if($files=$request->file('e_file'))
            { $ctr_exper_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                     $new_exper_filename =$emp_no.date('ymdhis').$ctr_exper_img.'.png';
                    $file->move(public_path().'/experience/', $new_exper_filename);  
                    $upload_pic[$key]=$new_exper_filename;

                     $ctr_exper_img++;
                }
            }

            if(count($org_arr)>0)
            {
                foreach($org_arr as $ky=>$val)
                {
                    if($org_arr[$ky]!="")
                    {
                  $Employee_Master_Experience = new Experience();
                       
                  $Employee_Master_Experience->emp_no =   $LastEmpId;
                  $Employee_Master_Experience->orgn_name = $org_arr[$ky];
                  $Employee_Master_Experience->sector =$sector_arr[$ky];
                  $Employee_Master_Experience->position =$position_arr[$ky];
                  $Employee_Master_Experience->start_date =$start_date_arr[$ky];
                  $Employee_Master_Experience->end_date =$end_date_arr[$ky];
                  $Employee_Master_Experience->reason =$reson_arr[$ky];  
                  if (!empty($upload_pic[$ky])) {
                     $Employee_Master_Experience->upload  =  $upload_pic[$ky];
                   }
                   else
                   {
                     $Employee_Master_Experience->upload = null;
                   }
                  //$Employee_Master_Experience->upload =$upload_pic[$ky];  

                  $Employee_Master_Experience->save(); 

                    }
                    

                }

             }

//transfer table add//

            $trans_order_arr=$request->trans_order;
            $type_arr = $request->order_type;
            $transfer_ord_date_arr = $request->transfer_ord_date;
            $from_date_arr = $request->from_date;
            $to_date_arr = $request->to_date;
            $from_dept_arr =$request->f_dept;
            $to_dept_arr = $request->t_dept;
            $from_work_arr = $request->from_work;
            $to_work_arr = $request->to_work;
            $reson_arr =$request->ord_rea;
            $reamrks_arr = $request->reamrks;
            $upload_transfer=array();
            if($files=$request->file('trans_file'))
            {$ctr_trans_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                     $new_trans_filename =$emp_no.date('ymdhis').$ctr_trans_img.'.png';
                    $file->move(public_path().'/transfer/', $new_trans_filename);  
                    $upload_transfer[$key]=$new_trans_filename;

                  $ctr_trans_img++;
                }
            }
            if(count($trans_order_arr)>0)
            {
                foreach($trans_order_arr as $ky=>$val)
                {
                    if($trans_order_arr[$ky]!="")
                    {
                  $Employee_Master_Transfer = new Transfer();
                       
                  $Employee_Master_Transfer->emp_no =   $LastEmpId;
                  $Employee_Master_Transfer->tranfer_order_no = $trans_order_arr[$ky];
                  $Employee_Master_Transfer->type =$type_arr[$ky];
                  $Employee_Master_Transfer->trans_date =$transfer_ord_date_arr[$ky];
                  $Employee_Master_Transfer->from_date =$from_date_arr[$ky];
                  $Employee_Master_Transfer->to_date =$to_date_arr[$ky];
                  $Employee_Master_Transfer->from_dept =$from_dept_arr[$ky];  
                  $Employee_Master_Transfer->to_dept =$to_dept_arr[$ky];
                  $Employee_Master_Transfer->from_work =$from_work_arr[$ky];
                  $Employee_Master_Transfer->to_work =$to_work_arr[$ky];
                  $Employee_Master_Transfer->remark =$reamrks_arr[$ky];
                  $Employee_Master_Transfer->reason =$reson_arr[$ky];  
                     if (!empty($upload_transfer[$ky])) 
                     {
                       $Employee_Master_Transfer->upload  =  $upload_transfer[$ky];
                     }
                     else
                     {
                       $Employee_Master_Transfer->upload = null;
                     } 
                   $Employee_Master_Transfer->save(); 

                    }
                    

                }

             }
//promotion table
            $promo_order_arr=$request->promo_order_no;
            $promo_date_arr = $request->promo_date;
            $effect_date_arr = $request->effect_date;
            $from_grade_arr = $request->from_grade;
            $from_design_arr = $request->from_design;
            $from_basic_arr =$request->from_basic;
            $from_special_arr = $request->from_special;
            $from_other_special_arr = $request->from_other_special;
            $other_allowance_arr = $request->from_special;
            $to_grade_arr =$request->to_grade;
            $to_portion_arr = $request->to_portion;
            $to_basic_arr = $request->to_basic;
            $total_allow_arr = $request->total_allow;
            $to_other_allow_arr = $request->to_other_allowance;
            $remark_arr =$request->remark;
            $upload_promotion=array();
            if($files=$request->file('upload_promo'))
            {$ctr_promo_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                     $new_promo_filename =$emp_no.date('ymdhis').$ctr_promo_img.'.png';
                    $file->move(public_path().'/promotion/', $new_promo_filename);  
                    $upload_promotion[$key]=$new_promo_filename;

                    $ctr_promo_img++;
                }
            }

            if(count($promo_order_arr)>0)
            {
                foreach($promo_order_arr as $ky=>$val)
                {
                    if($promo_order_arr[$ky]!="")
                    {
                  $Employee_Master_Promotion = new Promotion();
                       
                  $Employee_Master_Promotion->emp_no =   $LastEmpId;
                  $Employee_Master_Promotion->promotion_order_no = $promo_order_arr[$ky];
                  $Employee_Master_Promotion->promotion_date =$promo_date_arr[$ky];
                  $Employee_Master_Promotion->promotion_effect_date =$effect_date_arr[$ky];
                  $Employee_Master_Promotion->from_grade_code =$from_grade_arr[$ky];
                  $Employee_Master_Promotion->from_desg_code =$from_design_arr[$ky];
                  $Employee_Master_Promotion->from_basic_pay =$from_basic_arr[$ky];
                  $Employee_Master_Promotion->special_allownace =$from_special_arr[$ky];
            $Employee_Master_Promotion->other_special_allownace =$from_other_special_arr[$ky];
                  $Employee_Master_Promotion->to_grade_code =$to_grade_arr[$ky];  
                  $Employee_Master_Promotion->to_portion =$to_portion_arr[$ky];  
                  $Employee_Master_Promotion->to_basic_pay =$to_basic_arr[$ky];
                  $Employee_Master_Promotion->total_allowance =$total_allow_arr[$ky];
                  $Employee_Master_Promotion->other_allowance =$to_other_allow_arr[$ky];
                  $Employee_Master_Promotion->remark =$remark_arr[$ky];
                   if (!empty($upload_promotion[$ky])) 
                     {
                       $Employee_Master_Promotion->upload  =  $upload_promotion[$ky];
                     }
                     else
                     {
                       $Employee_Master_Promotion->upload = null;
                     } 
                  //$Employee_Master_Promotion->upload =$upload_promotion[$ky];  
  

                  $Employee_Master_Promotion->save(); 

                    }
                    

                }

             }
//probation table//
            $prob_order_arr=$request->prob_order;
            $prob_start_date_arr = $request->prob_start;
            $prob_end_date_arr = $request->prob_end;
            $pay_grade_arr = $request->pay_grade1;
            $initial_basic_arr = $request->initial;
            $special_allowance_arr =$request->special_allowance;
            $other_allownace_arr = $request->other_allownace;
            $remark_prob_arr =$request->remark_prob;

           $upload_prob=array();
            if($files=$request->file('prob_upload'))
            {$ctr_prob_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                    $new_prob_filename =$emp_no.date('ymdhis').$ctr_prob_img.'.png';
                    $file->move(public_path().'/probation/', $new_prob_filename);  
                    $upload_prob[$key]=$new_prob_filename;
                    $ctr_prob_img++;
                }
            }

      
            if(count($prob_order_arr)>0)
            {
                foreach($prob_order_arr as $ky=>$val)
                {
                    if($prob_order_arr[$ky]!="")
                    {
                  $Employee_Master_Probation = new Probation();
                       
                  $Employee_Master_Probation->emp_no =   $LastEmpId;
                  $Employee_Master_Probation->prob_order_no = $prob_order_arr[$ky];
                  $Employee_Master_Probation->prob_start_date =$prob_start_date_arr[$ky];
                  $Employee_Master_Probation->prob_end_date =$prob_end_date_arr[$ky];
                  $Employee_Master_Probation->pay_grade =$pay_grade_arr[$ky];
                  $Employee_Master_Probation->intial_basic =$initial_basic_arr[$ky];
                  $Employee_Master_Probation->special_allowance =$special_allowance_arr[$ky];
                  $Employee_Master_Probation->other_allowance = $other_allownace_arr[$ky];
                  $Employee_Master_Probation->remarks =$remark_prob_arr[$ky]; 

                  if (!empty($upload_prob[$ky])) 
                     {
                       $Employee_Master_Probation->upload  =  $upload_prob[$ky];
                     }
                     else
                     {
                       $Employee_Master_Probation->upload = null;
                     } 
                

                  $Employee_Master_Probation->save(); 

                    }
                    

                }

            }
//contract table//
            $contract_order_arr=$request->cont_order;
            $contract_start_date_arr = $request->cont_start_date;
            $contract_end_date_arr = $request->cont_end_date;
            $con_pay_arr = $request->con_pay;
            $special_arr = $request->special;
            $other_arr =$request->other;
            $remarks_cont_arr = $request->remarks;

            $upload_cont=array();
            if($files=$request->file('cont_file'))
            {$ctr_cont_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                    $new_cont_filename =$emp_no.date('ymdhis').$ctr_cont_img.'.png';
                    $file->move(public_path().'/contract/', $new_cont_filename);  
                    $upload_cont[$key]=$new_cont_filename;


                    $ctr_cont_img++;
                }
            }
          if(count($contract_order_arr)>0)
            {
                foreach($contract_order_arr as $ky=>$val)
                {
                    if($contract_order_arr[$ky]!="")
                    {
                  $Employee_Master_Contract = new Contract();
                       
                  $Employee_Master_Contract->emp_no =   $LastEmpId;
                  $Employee_Master_Contract->cont_order_no = $contract_order_arr[$ky];
                  $Employee_Master_Contract->cont_start_date =$contract_start_date_arr[$ky];
                  $Employee_Master_Contract->cont_end_date =$contract_end_date_arr[$ky];
                  $Employee_Master_Contract->consolidated_pay =$con_pay_arr[$ky];
                  $Employee_Master_Contract->special_allowance =$special_arr[$ky];
                  $Employee_Master_Contract->other_allowance =$other_arr[$ky];
                  $Employee_Master_Contract->remarks =$remarks_cont_arr[$ky];  

                  if (!empty($upload_cont[$ky])) 
                     {
                       $Employee_Master_Contract->upload  =  $upload_cont[$ky];
                     }
                     else
                     {
                       $Employee_Master_Contract->upload = null;
                     } 
                
                  //$Employee_Master_Contract->upload =$upload_cont[$ky];  

                  $Employee_Master_Contract->save(); 

                    }
                    

                }

            }
//antecendent table//
            $antecedent_order_arr=$request->ante_order_no;
            $antecedent_order_date_arr = $request->ante_order_date;
            $antecedent_type_arr = $request->ante_type;
            $w_e_e_arr = $request->ante_w_e_e;
            $w_e_t_arr = $request->ante_w_e_t;
            $remarks_ante_arr = $request->ante_remarks;
          if(count($antecedent_order_arr)>0)
            {
                foreach($antecedent_order_arr as $ky=>$val)
                {
                    if($antecedent_order_arr[$ky]!="")
                    {
                  $Employee_Master_antecedent = new Antecedent();
                       
                  $Employee_Master_antecedent->emp_no =   $LastEmpId;
                  $Employee_Master_antecedent->order_no = $antecedent_order_arr[$ky];
                  $Employee_Master_antecedent->order_date =$antecedent_order_date_arr[$ky];
                  $Employee_Master_antecedent->type =$antecedent_type_arr[$ky];
                  $Employee_Master_antecedent->WEE_date =$w_e_e_arr[$ky];
                  $Employee_Master_antecedent->WET_date =$w_e_t_arr[$ky];
                  $Employee_Master_antecedent->remarks =$remarks_ante_arr[$ky]; 
                  $Employee_Master_antecedent->save(); 

                    }
                    

                }

            }
//Revocation table add//  
            $revocation_order_arr=$request->revo_order_no;
            $revocation_order_date_arr = $request->revo_order_date;
            $ant_ord_no_arr = $request->ant_ord_no;
           $ant_ord_dat_arr = $request->ant_ord_dat; 
            $ant_ord_type_arr = $request->ant_ord_type;
            $ant_WEF_arr = $request->ant_WEF;
            $ant_WET_arr = $request->ant_WET;
            $revo_effected_date_arr = $request->revo_effected_date;
            $revo_remark_arr = $request->revo_remark;
            
          if(count($revocation_order_arr)>0)
            {
                foreach($revocation_order_arr as $ky=>$val)
                {
                    if($revocation_order_arr[$ky]!="")
                    {
                  $Employee_Master_revocation = new Revocation();
                       
          $Employee_Master_revocation->emp_no =   $LastEmpId;
          $Employee_Master_revocation->revocation_order_no = $revocation_order_arr[$ky];
          $Employee_Master_revocation->revocation_order_date =$revocation_order_date_arr[$ky]; 
          $Employee_Master_revocation->antecedent_order_no =$ant_ord_no_arr[$ky];
          $Employee_Master_revocation->antecedent_order_date =$ant_ord_dat_arr[$ky];
          $Employee_Master_revocation->antecedent_type =$ant_ord_type_arr[$ky];
          $Employee_Master_revocation->antecedent_WEE_date =$ant_WEF_arr[$ky]; 
          $Employee_Master_revocation->antecedent_WET_date =$ant_WET_arr[$ky];
          $Employee_Master_revocation->revocation_effected_date =$revo_effected_date_arr[$ky];
          $Employee_Master_revocation->remarks =$revo_remark_arr[$ky]; 
          $Employee_Master_revocation->save(); 

                    }
                    

                }

            }          
        }
        else
        {
          $Employee_Master->image  =  $name;
          $emp_no = $Employee_Master->emp_no  = $request->emp_no;
           $Employee_Master->emp_name = $request->emp_name;
           $Employee_Master->dept_no  = $request->department;
           $Employee_Master->desg_code  = $request->designation;      
           $Employee_Master->catg  = $request->category;
           $Employee_Master->work_place = $request->workplace;
           $Employee_Master->DOB  = $request->DOB;
           $Employee_Master->DOJ  = $request->DOJ;
           $Employee_Master->DOP  = $request->DOP;
           $Employee_Master->retirement_date  = $request->retirement_date;     
           $Employee_Master->employee_code  = $request->emp_code;
           $Employee_Master->emp_type = $request->emp_type;
           $Employee_Master->pf_ded = $request->optradio;
           $Employee_Master->esi_ded = $request->optradio1;
           $Employee_Master->grade_code = $request->pay_grade_code_hdn;
           $Employee_Master->pf_ac_no = $request->pf;
           $Employee_Master->vpf_perc = $request->vpf;
           $Employee_Master->esi_ac_no = $request->esi;
           $Employee_Master->pan_no = $request->PAN;
           $Employee_Master->UAN = $request->uan;
           $Employee_Master->adhara_no = $request->adhar;
           $Employee_Master->sex = $request->sex;
           $Employee_Master->marital_status = $request->marital;
           $Employee_Master->blood_group = $request->blood;
           $Employee_Master->id_mark = $request->id;
           $Employee_Master->spouse_name = $request->spouse;
           $Employee_Master->father_name = $request->father;
           $Employee_Master->present_address1 = $request->line1;
           $Employee_Master->present_address2 = $request->line2;
           $Employee_Master->present_address3 = $request->line3;
           $Employee_Master->permanent_address1 = $request->per_line1;
           $Employee_Master->permanent_address2 = $request->per_line2;
           $Employee_Master->permanent_address3 = $request->per_line3;
           $Employee_Master->ph_no = $request->contact;
           $Employee_Master->email = $request->email;
           $Employee_Master->mother_name = $request->mother;
           $Employee_Master->spouse_dob = $request->spouse_dob;
           $Employee_Master->father_dob = $request->father_dob;
           $Employee_Master->mother_dob = $request->mother_dob;
           $Employee_Master->reason_desc=$request->inactive;
           $Employee_Master->inactive_reason =$request->reason;
           $isExist = Employee_Master::select("*")
                          ->where("emp_no",  $emp_no )
                          ->exists();
                  if ($isExist ) {
             return redirect()->back()->with('alert', 'the employee number is already exsits');
                          }
                          else
                          {
                             $Employee_Master->save( );
                          }
          
           
           $LastEmpId = DB::getPdo()->lastInsertId();
  //official table add//  
          $Employee_Master_Official->emp_no=$LastEmpId;
          $Employee_Master_Official->pay_grade=$request->pay_grade;
          $Employee_Master_Official->intial_special=$request->intial;
          $Employee_Master_Official->current_special=$request->current;
          $Employee_Master_Official->intial_other_special=$request->initial_other;
          $Employee_Master_Official->current_other_special=$request->current_other;
          $Employee_Master_Official->save();//
     
  //nominee table add//
          $Employee_Master_Nominee->emp_no=$LastEmpId;
          $Employee_Master_Nominee->nominee_name=$request->nominee_name;
          $Employee_Master_Nominee->relationship=$request->relationship;
          $Employee_Master_Nominee->address1=$request->line1;
          $Employee_Master_Nominee->address2=$request->line2;
          $Employee_Master_Nominee->address3=$request->line3;
          $Employee_Master_Nominee->contact_ph_no=$request->contact;
          $Employee_Master_Nominee->adhara_number=$request->adhara;
          $Employee_Master_Nominee->nominee_dob=$request->dob;
          $Employee_Master_Nominee->save();
  
 //dependent table add//
        $name_arr=$request->name;
        $relation_arr = $request->relation;
        $age_arr = $request->age;
        $dob_arr = $request->dob1;
        $adhar_num_arr = $request->num;
         $images=array();
            if($files=$request->file('dependent_file'))
            {  $ctr_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                    $new_filename =$emp_no.date('ymdhis').$ctr_img.'.png';
                    $file->move(public_path().'/dependent/',$new_filename );  
                    $images[$key]=$new_filename;

                    $ctr_img++;
                }
            }

            //print_r($images);exit;
            if(count($name_arr)>0)
            {

                foreach($name_arr as $ky=>$val)
                {
                    if($name_arr[$ky]!="")
                    {//echo $name_arr[$ky].'<br>';

                       $Employee_Master_Dependent = new Dependent();
                       $Employee_Master_Dependent->emp_no= $LastEmpId ;
                       $Employee_Master_Dependent->depd_name= $name_arr[$ky];
                       $Employee_Master_Dependent->relationship=$relation_arr[$ky];
                       $Employee_Master_Dependent->age=$age_arr[$ky];
                       $Employee_Master_Dependent->depd_dob=$dob_arr[$ky];
                       $Employee_Master_Dependent->depd_adhara_no=$adhar_num_arr[$ky];
                       //$count = count($data);
                       if (!empty($images[$ky])) {
                          $Employee_Master_Dependent->upload_adhara =  $images[$ky];
                       }
                       else
                       {
                         $Employee_Master_Dependent->upload_adhara = null;
                       }
                     
                      

                       $Employee_Master_Dependent->save(); 
                     // echo   $Employee_Master_Dependent->upload_adhara;
                      //exit();
                    }

                }
            }
//qualification table add//
            $quali_arr=$request->academic;
            $stream_arr = $request->stream;
            $board_arr = $request->board_name_ajax1;
            $year_arr = $request->year;
            $per_mark_arr = $request->per_mark;
            $data_qual=array();
            if($files=$request->file('qualification_file'))
            {$ctr_qual_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                     $new_file_qual_name =$emp_no.date('ymdhis').$ctr_qual_img.'.png';
                    $file->move(public_path().'/qualification/', $new_file_qual_name);  
                    $data_qual[$key]=$new_file_qual_name;

                    $data_qual++;
                }
            }

             if(count($quali_arr)>0)
            {
                foreach($quali_arr as $ky=>$val)
                {
                    if($stream_arr[$ky]!="")
                    {
                  $Employee_Master_Qualification = new Qualification();
                       
                  $Employee_Master_Qualification->emp_no =   $LastEmpId;
                  $Employee_Master_Qualification->qualification_type = $quali_arr[$ky];
                  $Employee_Master_Qualification->stream_subject =$stream_arr[$ky];
                  $Employee_Master_Qualification->institution =$board_arr[$ky];
                  $Employee_Master_Qualification->year_passing =$year_arr[$ky];
                  $Employee_Master_Qualification->mark_perc =$per_mark_arr[$ky]; 
                  if (!empty($data_qual[$ky])) {
                         $Employee_Master_Qualification->upload  =  $data_qual[$ky];
                       }
                       else
                       {
                         $Employee_Master_Qualification->upload = null;
                       }
                  //$Employee_Master_Qualification->upload =$upload[$ky];  
                  $Employee_Master_Qualification->save(); 

                    }
                    

                }

             }
//experience table add//
            $org_arr=$request->orgn;
            $sector_arr = $request->sect;
            $position_arr = $request->pos;
            $start_date_arr = $request->from;
            $end_date_arr = $request->to;
            $reson_arr =$request->area;
            $upload_pic=array();
            if($files=$request->file('e_file'))
            { $ctr_exper_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                     $new_exper_filename =$emp_no.date('ymdhis').$ctr_exper_img.'.png';
                    $file->move(public_path().'/experience/', $new_exper_filename);  
                    $upload_pic[$key]=$new_exper_filename;

                     $ctr_exper_img++;
                }
            }

            if(count($org_arr)>0)
            {
                foreach($org_arr as $ky=>$val)
                {
                    if($org_arr[$ky]!="")
                    {
                  $Employee_Master_Experience = new Experience();
                       
                  $Employee_Master_Experience->emp_no =   $LastEmpId;
                  $Employee_Master_Experience->orgn_name = $org_arr[$ky];
                  $Employee_Master_Experience->sector =$sector_arr[$ky];
                  $Employee_Master_Experience->position =$position_arr[$ky];
                  $Employee_Master_Experience->start_date =$start_date_arr[$ky];
                  $Employee_Master_Experience->end_date =$end_date_arr[$ky];
                  $Employee_Master_Experience->reason =$reson_arr[$ky];  
                  if (!empty($upload_pic[$ky])) {
                     $Employee_Master_Experience->upload  =  $upload_pic[$ky];
                   }
                   else
                   {
                     $Employee_Master_Experience->upload = null;
                   }
                  //$Employee_Master_Experience->upload =$upload_pic[$ky];  

                  $Employee_Master_Experience->save(); 

                    }
                    

                }

             }

//transfer table add//

            $trans_order_arr=$request->trans_order;
            $type_arr = $request->order_type;
            $transfer_ord_date_arr = $request->transfer_ord_date;
            $from_date_arr = $request->from_date;
            $to_date_arr = $request->to_date;
            $from_dept_arr =$request->f_dept;
            $to_dept_arr = $request->t_dept;
            $from_work_arr = $request->from_work;
            $to_work_arr = $request->to_work;
            $reson_arr =$request->ord_rea;
            $reamrks_arr = $request->reamrks;
            $upload_transfer=array();
            if($files=$request->file('trans_file'))
            {$ctr_trans_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                     $new_trans_filename =$emp_no.date('ymdhis').$ctr_trans_img.'.png';
                    $file->move(public_path().'/transfer/', $new_trans_filename);  
                    $upload_transfer[$key]=$new_trans_filename;

                  $ctr_trans_img++;
                }
            }
            if(count($trans_order_arr)>0)
            {
                foreach($trans_order_arr as $ky=>$val)
                {
                    if($trans_order_arr[$ky]!="")
                    {
                  $Employee_Master_Transfer = new Transfer();
                       
                  $Employee_Master_Transfer->emp_no =   $LastEmpId;
                  $Employee_Master_Transfer->tranfer_order_no = $trans_order_arr[$ky];
                  $Employee_Master_Transfer->type =$type_arr[$ky];
                  $Employee_Master_Transfer->trans_date =$transfer_ord_date_arr[$ky];
                  $Employee_Master_Transfer->from_date =$from_date_arr[$ky];
                  $Employee_Master_Transfer->to_date =$to_date_arr[$ky];
                  $Employee_Master_Transfer->from_dept =$from_dept_arr[$ky];  
                  $Employee_Master_Transfer->to_dept =$to_dept_arr[$ky];
                  $Employee_Master_Transfer->from_work =$from_work_arr[$ky];
                  $Employee_Master_Transfer->to_work =$to_work_arr[$ky];
                  $Employee_Master_Transfer->reason =$reson_arr[$ky];  
                     if (!empty($upload_transfer[$ky])) 
                     {
                       $Employee_Master_Transfer->upload  =  $upload_transfer[$ky];
                     }
                     else
                     {
                       $Employee_Master_Transfer->upload = null;
                     } 
                   $Employee_Master_Transfer->save(); 

                    }
                    

                }

             }
//promotion table
            $promo_order_arr=$request->promo_order_no;
            $promo_date_arr = $request->promo_date;
            $effect_date_arr = $request->effect_date;
            $from_grade_arr = $request->from_grade;
            $from_design_arr = $request->from_design;
            $from_basic_arr =$request->from_basic;
            $from_special_arr = $request->from_special;
            $from_other_special_arr = $request->from_other_special;
            $other_allowance_arr = $request->from_special;
            $to_grade_arr =$request->to_grade;
            $to_portion_arr = $request->to_portion;
            $to_basic_arr = $request->to_basic;
            $total_allow_arr = $request->total_allow;
            $to_other_allow_arr = $request->to_other_allowance;
            $remark_arr =$request->remark;
            $upload_promotion=array();
            if($files=$request->file('upload_promo'))
            {$ctr_promo_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                     $new_promo_filename =$emp_no.date('ymdhis').$ctr_promo_img.'.png';
                    $file->move(public_path().'/promotion/', $new_promo_filename);  
                    $upload_promotion[$key]=$new_promo_filename;

                    $ctr_promo_img++;
                }
            }

            if(count($promo_order_arr)>0)
            {
                foreach($promo_order_arr as $ky=>$val)
                {
                    if($promo_order_arr[$ky]!="")
                    {
                  $Employee_Master_Promotion = new Promotion();
                       
                  $Employee_Master_Promotion->emp_no =   $LastEmpId;
                  $Employee_Master_Promotion->promotion_order_no = $promo_order_arr[$ky];
                  $Employee_Master_Promotion->promotion_date =$promo_date_arr[$ky];
                  $Employee_Master_Promotion->promotion_effect_date =$effect_date_arr[$ky];
                  $Employee_Master_Promotion->from_grade_code =$from_grade_arr[$ky];
                  $Employee_Master_Promotion->from_desg_code =$from_design_arr[$ky];
                  $Employee_Master_Promotion->from_basic_pay =$from_basic_arr[$ky];
                  $Employee_Master_Promotion->special_allownace =$from_special_arr[$ky];
            $Employee_Master_Promotion->other_special_allownace =$from_other_special_arr[$ky];
                  $Employee_Master_Promotion->to_grade_code =$to_grade_arr[$ky];  
                  $Employee_Master_Promotion->to_portion =$to_portion_arr[$ky];  
                  $Employee_Master_Promotion->to_basic_pay =$to_basic_arr[$ky];
                  $Employee_Master_Promotion->total_allowance =$total_allow_arr[$ky];
                  $Employee_Master_Promotion->other_allowance =$to_other_allow_arr[$ky];
                  $Employee_Master_Promotion->remark =$remark_arr[$ky];
                   if (!empty($upload_promotion[$ky])) 
                     {
                       $Employee_Master_Promotion->upload  =  $upload_promotion[$ky];
                     }
                     else
                     {
                       $Employee_Master_Promotion->upload = null;
                     } 
                  //$Employee_Master_Promotion->upload =$upload_promotion[$ky];  
  

                  $Employee_Master_Promotion->save(); 

                    }
                    

                }

             }
//probation table//
            $prob_order_arr=$request->prob_order;
            $prob_start_date_arr = $request->prob_start;
            $prob_end_date_arr = $request->prob_end;
            $pay_grade_arr = $request->pay_grade1;
            $initial_basic_arr = $request->initial;
            $special_allowance_arr =$request->special_allowance;
            $other_allownace_arr = $request->other_allownace;
            $remark_prob_arr =$request->remark_prob;

           $upload_prob=array();
            if($files=$request->file('prob_upload'))
            {$ctr_prob_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                    $new_prob_filename =$emp_no.date('ymdhis').$ctr_prob_img.'.png';
                    $file->move(public_path().'/probation/', $new_prob_filename);  
                    $upload_prob[$key]=$new_prob_filename;
                    $ctr_prob_img++;
                }
            }

      
            if(count($prob_order_arr)>0)
            {
                foreach($prob_order_arr as $ky=>$val)
                {
                    if($prob_order_arr[$ky]!="")
                    {
                  $Employee_Master_Probation = new Probation();
                       
                  $Employee_Master_Probation->emp_no =   $LastEmpId;
                  $Employee_Master_Probation->prob_order_no = $prob_order_arr[$ky];
                  $Employee_Master_Probation->prob_start_date =$prob_start_date_arr[$ky];
                  $Employee_Master_Probation->prob_end_date =$prob_end_date_arr[$ky];
                  $Employee_Master_Probation->pay_grade =$pay_grade_arr[$ky];
                  $Employee_Master_Probation->intial_basic =$initial_basic_arr[$ky];
                  $Employee_Master_Probation->special_allowance =$special_allowance_arr[$ky];
                  $Employee_Master_Probation->other_allowance = $other_allownace_arr[$ky];
                  $Employee_Master_Probation->remarks =$remark_prob_arr[$ky]; 

                  if (!empty($upload_prob[$ky])) 
                     {
                       $Employee_Master_Probation->upload  =  $upload_prob[$ky];
                     }
                     else
                     {
                       $Employee_Master_Probation->upload = null;
                     } 
                

                  $Employee_Master_Probation->save(); 

                    }
                    

                }

            }
//contract table//
            $contract_order_arr=$request->cont_order;
            $contract_start_date_arr = $request->cont_start_date;
            $contract_end_date_arr = $request->cont_end_date;
            $con_pay_arr = $request->con_pay;
            $special_arr = $request->special;
            $other_arr =$request->other;
            $remarks_cont_arr = $request->remarks;

            $upload_cont=array();
            if($files=$request->file('cont_file'))
            {$ctr_cont_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                    $new_cont_filename =$emp_no.date('ymdhis').$ctr_cont_img.'.png';
                    $file->move(public_path().'/contract/', $new_cont_filename);  
                    $upload_cont[$key]=$new_cont_filename;


                    $ctr_cont_img++;
                }
            }
          if(count($contract_order_arr)>0)
            {
                foreach($contract_order_arr as $ky=>$val)
                {
                    if($contract_order_arr[$ky]!="")
                    {
                  $Employee_Master_Contract = new Contract();
                       
                  $Employee_Master_Contract->emp_no =   $LastEmpId;
                  $Employee_Master_Contract->cont_order_no = $contract_order_arr[$ky];
                  $Employee_Master_Contract->cont_start_date =$contract_start_date_arr[$ky];
                  $Employee_Master_Contract->cont_end_date =$contract_end_date_arr[$ky];
                  $Employee_Master_Contract->consolidated_pay =$con_pay_arr[$ky];
                  $Employee_Master_Contract->special_allowance =$special_arr[$ky];
                  $Employee_Master_Contract->other_allowance =$other_arr[$ky];
                  $Employee_Master_Contract->remarks =$remarks_cont_arr[$ky];  

                  if (!empty($upload_cont[$ky])) 
                     {
                       $Employee_Master_Contract->upload  =  $upload_cont[$ky];
                     }
                     else
                     {
                       $Employee_Master_Contract->upload = null;
                     } 
                
                  //$Employee_Master_Contract->upload =$upload_cont[$ky];  

                  $Employee_Master_Contract->save(); 

                    }
                    

                }

            }
  //antecendent table//
              $antecedent_order_arr=$request->ante_order_no;
              $antecedent_order_date_arr = $request->ante_order_date;
              $antecedent_type_arr = $request->ante_type;
              $w_e_e_arr = $request->ante_w_e_e;
              $w_e_t_arr = $request->ante_w_e_t;
              $remarks_ante_arr = $request->ante_remarks;
            if(count($antecedent_order_arr)>0)
              {
                  foreach($antecedent_order_arr as $ky=>$val)
                  {
                      if($antecedent_order_arr[$ky]!="")
                      {
                    $Employee_Master_antecedent = new Antecedent();
                         
                    $Employee_Master_antecedent->emp_no =   $LastEmpId;
                    $Employee_Master_antecedent->order_no = $antecedent_order_arr[$ky];
                    $Employee_Master_antecedent->order_date =$antecedent_order_date_arr[$ky];
                    $Employee_Master_antecedent->type =$antecedent_type_arr[$ky];
                    $Employee_Master_antecedent->WEE_date =$w_e_e_arr[$ky];
                    $Employee_Master_antecedent->WET_date =$w_e_t_arr[$ky];
                    $Employee_Master_antecedent->remarks =$remarks_ante_arr[$ky]; 
                    $Employee_Master_antecedent->save(); 
  
                      }
                      
  
                  }
  
              }
  //Revocation table add//  
              $revocation_order_arr=$request->revo_order_no;
              $revocation_order_date_arr = $request->revo_order_date;
              $ant_ord_no_arr = $request->ant_ord_no;
             $ant_ord_dat_arr = $request->ant_ord_dat; 
              $ant_ord_type_arr = $request->ant_ord_type;
              $ant_WEF_arr = $request->ant_WEF;
              $ant_WET_arr = $request->ant_WET;
              $revo_effected_date_arr = $request->revo_effected_date;
              $revo_remark_arr = $request->revo_remark;
              
            if(count($revocation_order_arr)>0)
              {
                  foreach($revocation_order_arr as $ky=>$val)
                  {
                      if($revocation_order_arr[$ky]!="")
                      {
                    $Employee_Master_revocation = new Revocation();
                         
            $Employee_Master_revocation->emp_no =   $LastEmpId;
            $Employee_Master_revocation->revocation_order_no = $revocation_order_arr[$ky];
            $Employee_Master_revocation->revocation_order_date =$revocation_order_date_arr[$ky]; 
            $Employee_Master_revocation->antecedent_order_no =$ant_ord_no_arr[$ky];
            $Employee_Master_revocation->antecedent_order_date =$ant_ord_dat_arr[$ky];
            $Employee_Master_revocation->antecedent_type =$ant_ord_type_arr[$ky];
            $Employee_Master_revocation->antecedent_WEE_date =$ant_WEF_arr[$ky]; 
            $Employee_Master_revocation->antecedent_WET_date =$ant_WET_arr[$ky];
            $Employee_Master_revocation->revocation_effected_date =$revo_effected_date_arr[$ky];
            $Employee_Master_revocation->remarks =$revo_remark_arr[$ky]; 
            $Employee_Master_revocation->save(); 
  
                      }
                      
  
                  }
  
              }  
        }


     // echo "<pre>";print_r($addtable2); echo "</pre>"; exit();
      //$id =DB::table('empmst_official')->insertGetId($addtable2);
         return redirect('/employee_edit_master/?search_emp='.$employee_number)->withInput()->with('SuccessStatus', 'You checked');
    
     } 
     public function updateEmployeeDetails(Request $request)
     {
       $Employee_Master = new Employee_Master();
         
         $employee_number = $request->emp_no;
         $employee_id = $request->emp_id;
         $employee_name = $request->emp_name;
         $active_type= $Employee_Master->active_type = $request->type; 
         if ($request->hasFile('image')) 
         {
             $image = $request->file('image');
             $name = rand().time().'.'.$image->getClientOriginalExtension();
             $destinationPath = public_path('/image/');
             $image->move($destinationPath, $name);
             $imageinsert= $name;
         }
         else{
          $imageinsert= $request->old_empImage;
         }
            
             if($active_type=="inactive" ||  $active_type=="active")
             {
             $emp_name =$request->emp_name;
             $emp_code =$request->emp_code;
             $dept_no =$request->department;
             $emp_type =$request->emp_type;
             $designation =$request->designation;
             $category =$request->category;
             $pf_arr =$request->optradio;
             $esi_arr= $request->optradio1;
             $gradecode_arr = $request->pay_grade_code_hdn;
             $pfacc_arr= $request->pf;
             $vpf_arr= $request->vpf;
             $esi_acc_no= $request->esi;
             $pan_arr = $request->PAN;
             $uan_arr = $request->uan;
             $adhara_arr = $request->adhar;
             $per_gender = $request->sex;
             $per_marital = $request->marital;
             $per_blood= $request->blood;
             $per_identificationmark = $request->id;
             $per_spousename= $request->spouse;
             $per_father = $request->father;
             $per_line11 = $request->line_11;
             $per_line22 = $request->line_22;
             $per_line33 = $request->line_33;
             $per_linearr1 = $request->per_line1;
             $per_linearr2 = $request->per_line2;
             $per_linearr3 = $request->per_line3;
             $per_contact = $request->contactnumber;
             $per_email = $request->email;
             $per_mother = $request->mother;
             $per_sdob = $request->spouse_dob;
             $per_fdob = $request->father_dob;
             $per_mdob = $request->mother_dob;
             } 
              $employee_details_fetch =array(
                        //'emp_no' => $emp_no,
                        'emp_name' =>$emp_name,
                        'employee_code'=> $emp_code,
                        'dept_no'=>$dept_no,
                        'emp_type'=> $emp_type,
                        'desg_code'=> $designation,
                        'catg'=> $category,
                        'image'=> $imageinsert,
                        'pf_ded'=> $pf_arr,
                        'esi_ded'=> $esi_arr,
                        'grade_code'=> $gradecode_arr,
                        'pf_ac_no'=> $pfacc_arr,
                        'vpf_perc'=> $vpf_arr,
                        'esi_ac_no'=> $esi_acc_no,
                        'pan_no'=> $pan_arr,
                        'UAN'=> $uan_arr,
                        'adhara_no'=> $adhara_arr,
                        'sex'=> $per_gender,
                        'marital_status'=> $per_marital,
                        'blood_group'=> $per_blood,
                        'id_mark'=> $per_identificationmark,
                        'spouse_name'=> $per_spousename,
                        'father_name'=> $per_father,
                        'present_address1'=> $per_line11,
                        'present_address2'=> $per_line22,
                        'present_address3'=> $per_line33,
                        'permanent_address1'=> $per_linearr1,
                        'permanent_address2'=> $per_linearr2,
                        'permanent_address3'=> $per_linearr3,
                        'ph_no'=> $per_contact,
                        'email'=> $per_email,
                        'mother_name'=> $per_mother,
                        'spouse_dob'=> $per_sdob,
                        'father_dob'=> $per_fdob,
                        'mother_dob'=> $per_mdob,
                        
                    );

         $update_Data=DB::table('emp_mst')
                      ->where('id',  $employee_id)
                      ->update($employee_details_fetch); 


            $pay_arr = $request->pay_grade;
            $initial_arr = $request->intial;
            $curr_arr = $request->current;
            $other_arr = $request->initial_other;
            $cother_arr = $request->current_other;

            $employee_payscaledetails =array(
              //'emp_no' => $emp_no,
              'pay_grade' =>$pay_arr,
              'intial_special'=> $initial_arr,
              'current_special'=>$curr_arr,
              'intial_other_special'=> $other_arr,
              'current_other_special'=> $cother_arr
                  );
         $update_Data=DB::table('empmst_official')
                  ->where('emp_no',  $employee_id)
                  ->update($employee_payscaledetails); 

        $nm_name = $request->nominee_name;
        $nm_date = $request->dob;
        $nm_reltn = $request->relationship;
        $nm_phn = $request->phonenumber;
        $nm_adhara = $request->adhara;
        $nm_add1 = $request->line1;
        $nm_add2 = $request->line2;
        $nm_add3 = $request->line3;

        $employee_nomineedetails =array(
          //'emp_no' => $emp_no,
          'nominee_name' =>$nm_name,
          'nominee_dob'=> $nm_date,
          'relationship'=> $nm_reltn,
          'contact_ph_no'=>$nm_phn,
          'adhara_number'=> $nm_adhara,
          'address1'=> $nm_add1,
          'address2'=> $nm_add2,
          'address3'=> $nm_add3,
        );
        $update_Data=DB::table('emp_nominee_dtl')
        ->where('emp_no',  $employee_id)
        ->update($employee_nomineedetails); 
           
        $name_arr=$request->name;
        $relation_arr = $request->relation;
        $age_arr = $request->age;
        $dob_arr = $request->dob1;
        $adhar_num_arr = $request->num;
        $depedent_sqlId_arr = $request->depedent_sql_id;
        $images=array();
        $images_index=array();
        //////////////print_r($request->file('dependent_file'));exit;
            if($files=$request->file('dependent_file'))
            {  $ctr_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                    $new_filename =$employee_id.date('ymdhis').$ctr_img.'.png';
                    $file->move(public_path().'/dependent/',$new_filename );  
                    $images[$key]=$new_filename;
                    $images_index[]=$key;
                    $ctr_img++;
                }
            }

            //print_r($images);exit;
            if(count($name_arr)>0)
            {

                foreach($name_arr as $ky=>$val)
                {//print_r($name_arr);exit();
                    if($name_arr[$ky]!="")
                    {
                      if( $depedent_sqlId_arr[$ky]=="")
                        {
                        if (in_array($ky,$images_index))
                         {
                          $employee_dependent_details_fetch =array( 
                            'emp_no'=>  $employee_id,
                            'depd_name'=> $name_arr[$ky],
                            'relationship'=>$relation_arr[$ky],
                            'age'=> $age_arr[$ky],
                            'depd_dob'=> $dob_arr[$ky],
                            'depd_adhara_no'=> $adhar_num_arr[$ky], 
                            'upload_adhara'=> $images[$ky],   
                            ); 
                          }
                          else
                          {
                            $employee_dependent_details_fetch =array( 
                              'emp_no'=>  $employee_id,
                              'depd_name'=> $name_arr[$ky],
                              'relationship'=>$relation_arr[$ky],
                              'age'=> $age_arr[$ky],
                              'depd_dob'=> $dob_arr[$ky],
                              'depd_adhara_no'=> $adhar_num_arr[$ky], 
                               
                              ); 
                          }

                      $update_Data=DB::table('emp_dependent_dtl')
                        ->where('emp_no',  $employee_id)                      
                        ->insert( $employee_dependent_details_fetch);
                      }
                      else{
                        if (in_array($ky,$images_index)) {
                          $employee_dependent_details_fetch =array(                         
                          'depd_name'=> $name_arr[$ky],
                          'relationship'=>$relation_arr[$ky],
                          'age'=> $age_arr[$ky],
                          'depd_dob'=> $dob_arr[$ky],
                          'depd_adhara_no'=> $adhar_num_arr[$ky],
                           'upload_adhara'=>  $images[$ky]
                         );
                       }
                       else
                       {
                         $employee_dependent_details_fetch =array(                         
                          'depd_name'=> $name_arr[$ky],
                          'relationship'=>$relation_arr[$ky],
                          'age'=> $age_arr[$ky],
                          'depd_dob'=> $dob_arr[$ky],
                          'depd_adhara_no'=> $adhar_num_arr[$ky],                           
                         );
                       }
                     
                   
                          $update_Data=DB::table('emp_dependent_dtl')
                        ->where('emp_no',  $employee_id)
                        ->where('id',$depedent_sqlId_arr[$ky])
                        ->update($employee_dependent_details_fetch);  
                        } 
                    }

                }
            }
            
            //Qualification Add

            $quali_arr=$request->academic;
            $stream_arr = $request->stream;
            $board_arr = $request->board_name_ajax1;
            $year_arr = $request->year;
            $per_mark_arr = $request->per_mark;
            $qlf_hiddenSqlid_arr =   $request->qlf_hiddenSqlid;
            $ctr_qual_img=0;

            $data_qual=array();
            if($files=$request->file('qualification_file'))
            {   
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                     $new_file_qual_name =$emp_no.date('ymdhis').$ctr_qual_img.'.png';
                    $file->move(public_path().'/qualification/', $new_file_qual_name);  
                    $data_qual[$key]=$new_file_qual_name;

                    $ctr_qual_img++;
                }
            }

            if(count($quali_arr)>0)
            {
                foreach($quali_arr as $ky=>$val)
                {
                            if($quali_arr[$ky]!="")
                            {
                                  // $Employee_Master_Qualification = new Qualification();
                                      
                                  // $Employee_Master_Qualification->emp_no =   $LastEmpId;
                                  // $Employee_Master_Qualification->qualification_type = $quali_arr[$ky];
                                  // $Employee_Master_Qualification->stream_subject =$stream_arr[$ky];
                                  // $Employee_Master_Qualification->institution =$board_arr[$ky];
                                  // $Employee_Master_Qualification->year_passing =$year_arr[$ky];
                                  // $Employee_Master_Qualification->mark_perc =$per_mark_arr[$ky]; 

                                $qlf_data_arr = array( 'emp_no'=> $employee_number,
                                                        'qualification_type'=>$quali_arr[$ky],
                                                        'stream_subject'=>$stream_arr[$ky],
                                                        'institution'=>$board_arr[$ky],
                                                        'year_passing'=>$year_arr[$ky],
                                                        'mark_perc' => $per_mark_arr[$ky]
                                                        );
                                
                                if ($qlf_hiddenSqlid_arr[$ky]!="") 
                                {
                                        //  $Employee_Master_Qualification->upload  =  $data_qual[$ky];
                                      if( $ctr_qual_img>0)
                                      {
                                        $qlf_data_arr = array( 'emp_no'=> $employee_number,
                                        'qualification_type'=>$quali_arr[$ky],
                                        'stream_subject'=>$stream_arr[$ky],
                                        'institution'=>$board_arr[$ky],
                                        'year_passing'=>$year_arr[$ky],
                                        'mark_perc' => $per_mark_arr[$ky],
                                        'upload'=>$data_qual[$ky]
                                        );
                                      }
                                      else
                                      {
                                        $qlf_data_arr = array( 'emp_no'=> $employee_number,
                                        'qualification_type'=>$quali_arr[$ky],
                                        'stream_subject'=>$stream_arr[$ky],
                                        'institution'=>$board_arr[$ky],
                                        'year_passing'=>$year_arr[$ky],
                                        'mark_perc' => $per_mark_arr[$ky],
                                        'upload'=>null
                                        );
                                      }
                                        

                                        DB::table("emp_qualification_dtl")
                                        ->where('id',$qlf_hiddenSqlid_arr[$ky])
                                        ->update($qlf_data_arr);
                                }
                                else
                                {
                                        //$Employee_Master_Qualification->upload = null;

                                        $qlf_data_arr = array( 'emp_no'=> $employee_number,
                                        'qualification_type'=>$quali_arr[$ky],
                                        'stream_subject'=>$stream_arr[$ky],
                                        'institution'=>$board_arr[$ky],
                                        'year_passing'=>$year_arr[$ky],
                                        'mark_perc' => $per_mark_arr[$ky],
                                        'upload'=>null
                                        );

                                        DB::table("emp_qualification_dtl")                                        
                                            ->insert($qlf_data_arr);
                                }
                          //$Employee_Master_Qualification->upload =$upload[$ky];  
                        
                            }
                }

             }

            //antecedent
              $antecedent_order_arr=$request->ante_order_no;
              $antecedent_order_date_arr = $request->ante_order_date;
              $antecedent_type_arr = $request->ante_type;
              $w_e_e_arr = $request->ante_w_e_e;
              $w_e_t_arr = $request->ante_w_e_t;
              $remarks_ante_arr = $request->ante_remarks;
              $antecedent_sqlId_arr = $request->antecedent_sql_id;
              $antecedent_sql_empno = $request->antecedent_sql_empno;


            if(count($antecedent_order_arr)>0)
              {
                  foreach($antecedent_order_arr as $ky=>$val)
                  {
                      if($antecedent_order_arr[$ky]!="")
                      {
                  
                        if( $antecedent_sqlId_arr[$ky]=="")
                        {

                       $employee_antecedent_details_fetch =array( 
                          'emp_no'=>  $employee_id,
                          'order_no'=> $antecedent_order_arr[$ky],
                          'order_date'=>$antecedent_order_date_arr[$ky],
                          'type'=> $antecedent_type_arr[$ky],
                          'WEE_date'=> $w_e_e_arr[$ky],
                          'WET_date'=> $w_e_t_arr[$ky], 
                          'remarks'=> $remarks_ante_arr[$ky],   
                     ); 

                      $update_Data=DB::table('emp_antecedent_dtl')
                        ->where('emp_no',  $employee_id)                      
                        ->insert( $employee_antecedent_details_fetch);
                      } 
                        else
                        {
                    
                           $employee_antecedent_details_fetch =array(                         
                                    'order_no'=> $antecedent_order_arr[$ky],
                                    'order_date'=>$antecedent_order_date_arr[$ky],
                                    'type'=> $antecedent_type_arr[$ky],
                                    'WEE_date'=> $w_e_e_arr[$ky],
                                    'WET_date'=> $w_e_t_arr[$ky], 
                                    'remarks'=> $remarks_ante_arr[$ky],                            
                                   ); 
                         


                          $update_Data=DB::table('emp_antecedent_dtl')
                        ->where('emp_no',  $employee_id)
                        ->where('id',$antecedent_sqlId_arr[$ky])
                        ->update($employee_antecedent_details_fetch);
                        }
                        }
                   
                      }

                      
  
                  }
            $org_arr=$request->orgn;
            $sector_arr = $request->sect;
            $position_arr = $request->pos;
            $start_date_arr = $request->from;
            $end_date_arr = $request->to;
            $reson_arr =$request->area;
            $experience_sqlId_arr = $request->experience_sql_id;
     
            $upload_pic_index=array();
            $upload_pic=array();
            if($files=$request->file('e_file'))
            { $ctr_exper_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                    $new_exper_filename =$employee_id.date('ymdhis').$ctr_exper_img.'.png';
                    $file->move(public_path().'/experience/', $new_exper_filename);  
                    $upload_pic[$key]=$new_exper_filename;
                    $upload_pic_index[]=$key;
                    $ctr_exper_img++;
                }
            }

            if(count($org_arr)>0)
            {
                foreach($org_arr as $ky=>$val)
                {
                    if($org_arr[$ky]!="")
                    {
                      if( $experience_sqlId_arr[$ky]=="")
                        {
                          if (in_array($ky,$upload_pic_index)) 
                          {
                       $employee_experience_details_fetch =array( 
                          'emp_no'=>  $employee_id,
                           'orgn_name'=> $org_arr[$ky],
                          'sector'=>$sector_arr[$ky],
                          'position'=> $position_arr[$ky],
                          'start_date'=> $start_date_arr[$ky],
                          'end_date'=> $end_date_arr[$ky],
                           'reason'=>  $reson_arr[$ky],
                           'upload'=> $upload_pic[$ky],
                          //'upload_adhara'=> $remarks_ante_arr[$ky],   
                          ); 
                        }
                        else
                        {
                          $employee_experience_details_fetch =array( 
                            'emp_no'=>  $employee_id,
                             'orgn_name'=> $org_arr[$ky],
                            'sector'=>$sector_arr[$ky],
                            'position'=> $position_arr[$ky],
                            'start_date'=> $start_date_arr[$ky],
                            'end_date'=> $end_date_arr[$ky],
                             'reason'=>  $reson_arr[$ky],
                          );
                        }

                      $update_Data=DB::table('emp_experience_dtl')
                        ->where('emp_no',$employee_id)                      
                        ->insert( $employee_experience_details_fetch);
                      }
                      else{
                         if (in_array($ky,$upload_pic_index)) 
                         {
                          $employee_experience_details_fetch =array(                         
                          'orgn_name'=> $org_arr[$ky],
                          'sector'=>$sector_arr[$ky],
                          'position'=> $position_arr[$ky],
                          'start_date'=> $start_date_arr[$ky],
                          'end_date'=> $end_date_arr[$ky],
                           'reason'=>  $reson_arr[$ky],
                           'upload'=> $upload_pic[$ky],
                         );
                       }
                       else
                       {
                       $employee_experience_details_fetch =array(                         
                          'orgn_name'=> $org_arr[$ky],
                          'sector'=>$sector_arr[$ky],
                          'position'=> $position_arr[$ky],
                          'start_date'=> $start_date_arr[$ky],
                          'end_date'=> $end_date_arr[$ky],
                           'reason'=>  $reson_arr[$ky],
                           //'upload'=> $upload_pic[$ky],
                         );
                       }
                         $update_Exp_Data=DB::table('emp_experience_dtl')
                        ->where('emp_no',  $employee_id)
                        ->where('id',$experience_sqlId_arr[$ky])
                        ->update($employee_experience_details_fetch); 
                      }
                    


                    }
                    

                }

             }
//transfer
            $trans_order_arr=$request->trans_order;
            $type_arr = $request->order_type;
            $transfer_ord_date_arr = $request->transfer_ord_date;
            $from_date_arr = $request->from_date;
            $to_date_arr = $request->to_date;
            $from_dept_arr =$request->f_dept;
            $to_dept_arr = $request->t_dept;
            $from_work_arr = $request->from_work;
            $to_work_arr = $request->to_work;
            $reson_arr =$request->ord_rea;
            $reamrks_arr = $request->reamrks;
            $transfer_sql_id =$request->transfer_sql_id;
            $upload_transfer_index=array();
            $upload_transfer=array();
            if($files=$request->file('trans_file'))
            {$ctr_trans_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                    $new_trans_filename =$employee_id.date('ymdhis').$ctr_trans_img.'.png';
                    $file->move(public_path().'/transfer/', $new_trans_filename);  
                    $upload_transfer[$key]=$new_trans_filename;
                    $upload_transfer_index[]=$key;
                    $ctr_trans_img++;
                }
            }
            if(count($trans_order_arr)>0)
            {
                foreach($trans_order_arr as $ky=>$val)
                {
                    if($trans_order_arr[$ky]!="")
                    {
       
                     if($transfer_sql_id[$ky]=="")
                        {
                          if (in_array($ky,$upload_transfer_index)) 
                          {
                       $employee_transfer_details_fetch =array( 
                          'emp_no'=>  $employee_id,
                           'tranfer_order_no'=> $trans_order_arr[$ky],
                          'type'=>$type_arr[$ky],
                          'trans_date'=> $transfer_ord_date_arr[$ky],
                          'from_date'=> $from_date_arr[$ky],
                          'to_date'=> $to_date_arr[$ky],
                           'from_dept'=>  $from_dept_arr[$ky],
                           'to_dept'=>$to_dept_arr[$ky],
                          'from_work'=> $from_work_arr[$ky],
                          'to_work'=> $to_work_arr[$ky],
                           'reason'=>  $reson_arr[$ky],
                           'remark'=>  $reamrks_arr[$ky],
                           'upload'=> $upload_transfer[$ky],
                           'created_at'=>date('Y-m-d h:i:s'),
                           'updated_at'=>date('Y-m-d h:i:s')
                        
                          //'upload_adhara'=> $remarks_ante_arr[$ky],   
                          ); 
                        }
                        else
                        {
                          $employee_transfer_details_fetch =array( 
                          'emp_no'=>  $employee_id,
                          'tranfer_order_no'=> $trans_order_arr[$ky],
                         'type'=>$type_arr[$ky],
                         'trans_date'=> $transfer_ord_date_arr[$ky],
                         'from_date'=> $from_date_arr[$ky],
                         'to_date'=> $to_date_arr[$ky],
                          'from_dept'=>  $from_dept_arr[$ky],
                          'to_dept'=>$to_dept_arr[$ky],
                         'from_work'=> $from_work_arr[$ky],
                         'to_work'=> $to_work_arr[$ky],
                          'reason'=>  $reson_arr[$ky],
                          'remark'=>  $reamrks_arr[$ky],
                         
                          'created_at'=>date('Y-m-d h:i:s'),
                          'updated_at'=>date('Y-m-d h:i:s')
                       
                         //'upload_adhara'=> $remarks_ante_arr[$ky],   
                         ); 
                        }

                      $update_Data=DB::table('emp_trnasfer_dtl')
                        ->where('emp_no',$employee_id)                      
                        ->insert( $employee_transfer_details_fetch);
                      }
                      else{
                         if (in_array($ky,$upload_transfer_index)) 
                         {
                          $employee_transfer_details_fetch =array(                         
                          'emp_no'=>  $employee_id,
                           'tranfer_order_no'=> $trans_order_arr[$ky],
                          'type'=>$type_arr[$ky],
                          'trans_date'=> $transfer_ord_date_arr[$ky],
                          'from_date'=> $from_date_arr[$ky],
                          'to_date'=> $to_date_arr[$ky],
                           'from_dept'=>  $from_dept_arr[$ky],
                           'to_dept'=>$to_dept_arr[$ky],
                          'from_work'=> $from_work_arr[$ky],
                          'to_work'=> $to_work_arr[$ky],
                          'reason'=>  $reson_arr[$ky],
                          'remark'=>  $reamrks_arr[$ky],
                           'upload'=> $upload_transfer[$ky],
                         );
                       }
                       else
                       {
                       $employee_transfer_details_fetch =array(                         
                            'emp_no'=>  $employee_id,
                           'tranfer_order_no'=> $trans_order_arr[$ky],
                          'type'=>$type_arr[$ky],
                          'trans_date'=> $transfer_ord_date_arr[$ky],
                          'from_date'=> $from_date_arr[$ky],
                          'to_date'=> $to_date_arr[$ky],
                           'from_dept'=>  $from_dept_arr[$ky],
                           'to_dept'=>$to_dept_arr[$ky],
                          'from_work'=> $from_work_arr[$ky],
                          'to_work'=> $to_work_arr[$ky],
                          'remark'=>  $reamrks_arr[$ky],
                           'reason'=>  $reson_arr[$ky],
                           //'upload'=> $upload_pic[$ky],
                         );
                       }
                         $update_Exp_Data=DB::table('emp_trnasfer_dtl')
                        ->where('emp_no',  $employee_id)
                        ->where('id',$transfer_sql_id[$ky])
                        ->update($employee_transfer_details_fetch); 
                      }
                    


                    }
                    

                }

              
             }
               $promo_order_arr=$request->promo_order_no;
            $promo_date_arr = $request->promo_date;
            $effect_date_arr = $request->effect_date;
            $from_grade_arr = $request->from_grade;
            $from_design_arr = $request->from_design;
            $from_basic_arr =$request->from_basic;
            $from_special_arr = $request->from_special;
            $from_other_special_arr = $request->from_other_special;
            $other_allowance_arr = $request->from_special;
            $to_grade_arr =$request->to_grade;
            $to_portion_arr = $request->to_portion;
            $to_basic_arr = $request->to_basic;
            $total_allow_arr = $request->total_allow;
            $to_other_allow_arr = $request->to_other_allowance;
            $remark_arr =$request->remark;
            $promotion_sql_id=$request->promotion_sql_id;
            $upload_promotion_index=array();
            $upload_promotion=array();
            if($files=$request->file('upload_promo'))
            {$ctr_promo_img=1;
                foreach($files as $key => $file)
                {
                    $name=$file->getClientOriginalName();
                    $new_promo_filename =$employee_id.date('ymdhis').$ctr_promo_img.'.png';
                    $file->move(public_path().'/promotion/', $new_promo_filename);  
                    $upload_promotion[$key]=$new_promo_filename;
                    $upload_promotion_index[]=$key;
                    $ctr_promo_img++;
                }
            }

            if(count($promo_order_arr)>0)
            {
                foreach($promo_order_arr as $ky=>$val)
                {
                    if($promo_order_arr[$ky]!="")
                    {

                    if($promotion_sql_id[$ky]=="")
                        {
                        if (in_array($ky,$upload_promotion_index)) 
                          {
                       $employee_promotion_details_fetch =array( 
                          'emp_no'=>  $employee_id,
                          'promotion_order_no'=> $promo_order_arr[$ky],
                          'promotion_date'=>$promo_date_arr[$ky],
                          'promotion_effect_date'=> $effect_date_arr[$ky],
                          'from_grade_code'=> $from_grade_arr[$ky],
                          'from_desg_code'=> $from_design_arr[$ky],
                          'from_basic_pay'=>  $from_basic_arr[$ky],
                          'special_allownace'=>$from_special_arr[$ky],
                          'other_special_allownace'=> $from_other_special_arr[$ky],
                          'to_grade_code'=> $to_grade_arr[$ky],
                          'to_portion'=>  $to_portion_arr[$ky],
                          'to_basic_pay'=> $to_basic_arr[$ky],
                          'total_allowance'=> $total_allow_arr[$ky],
                          'other_allowance'=>  $to_other_allow_arr[$ky],
                          'remark'=>$remark_arr[$ky], 
                          'upload'=>$upload_promotion[$ky],
                          'created_at'=>date('Y-m-d h:i:s'),
                          'updated_at'=>date('Y-m-d h:i:s')
                          ); 
                        }
                        else{
                          $employee_promotion_details_fetch =array( 
                            'emp_no'=>  $employee_id,
                            'promotion_order_no'=> $promo_order_arr[$ky],
                            'promotion_date'=>$promo_date_arr[$ky],
                            'promotion_effect_date'=> $effect_date_arr[$ky],
                            'from_grade_code'=> $from_grade_arr[$ky],
                            'from_desg_code'=> $from_design_arr[$ky],
                            'from_basic_pay'=>  $from_basic_arr[$ky],
                            'special_allownace'=>$from_special_arr[$ky],
                            'other_special_allownace'=> $from_other_special_arr[$ky],
                            'to_grade_code'=> $to_grade_arr[$ky],
                            'to_portion'=>  $to_portion_arr[$ky],
                            'to_basic_pay'=> $to_basic_arr[$ky],
                            'total_allowance'=> $total_allow_arr[$ky],
                            'other_allowance'=>  $to_other_allow_arr[$ky],
                            'remark'=>$remark_arr[$ky], 
                            'created_at'=>date('Y-m-d h:i:s'),
                            'updated_at'=>date('Y-m-d h:i:s')
                            ); 
                        }

                      $update_Data=DB::table('employee_promotion_dtl')
                        ->where('emp_no',$employee_id)                      
                        ->insert( $employee_promotion_details_fetch);
                      }
                      else{
                         if (in_array($ky,$upload_promotion_index)) 
                         {
                          $employee_promotion_details_fetch =array(                         
                         'emp_no'=>  $employee_id,
                          'promotion_order_no'=> $promo_order_arr[$ky],
                          'promotion_date'=>$promo_date_arr[$ky],
                          'promotion_effect_date'=> $effect_date_arr[$ky],
                          'from_grade_code'=> $from_grade_arr[$ky],
                          'from_desg_code'=> $from_design_arr[$ky],
                          'from_basic_pay'=>  $from_basic_arr[$ky],
                          'special_allownace'=>$from_special_arr[$ky],
                          'other_special_allownace'=> $from_other_special_arr[$ky],
                          'to_grade_code'=> $to_grade_arr[$ky],
                          'to_portion'=>  $to_portion_arr[$ky],
                          'to_basic_pay'=> $to_basic_arr[$ky],
                          'total_allowance'=> $total_allow_arr[$ky],
                          'other_allowance'=>  $to_other_allow_arr[$ky],
                          'remark'=>$remark_arr[$ky], 
                          'upload'=>$upload_promotion[$ky]
                         );
                       }
                       else
                       {
                       $employee_promotion_details_fetch =array(                         
                           'emp_no'=>  $employee_id,
                          'promotion_order_no'=> $promo_order_arr[$ky],
                          'promotion_date'=>$promo_date_arr[$ky],
                          'promotion_effect_date'=> $effect_date_arr[$ky],
                          'from_grade_code'=> $from_grade_arr[$ky],
                          'from_desg_code'=> $from_design_arr[$ky],
                          'from_basic_pay'=>  $from_basic_arr[$ky],
                          'special_allownace'=>$from_special_arr[$ky],
                          'other_special_allownace'=> $from_other_special_arr[$ky],
                          'to_grade_code'=> $to_grade_arr[$ky],
                          'to_portion'=>  $to_portion_arr[$ky],
                          'to_basic_pay'=> $to_basic_arr[$ky],
                          'total_allowance'=> $total_allow_arr[$ky],
                          'other_allowance'=>  $to_other_allow_arr[$ky],
                          'remark'=>$remark_arr[$ky], 
                         );
                       }
                         $update_Exp_Data=DB::table('employee_promotion_dtl')
                        ->where('emp_no',  $employee_id)
                        ->where('id',$promotion_sql_id[$ky])
                        ->update($employee_promotion_details_fetch); 
                      }
                    
                    }
                    

                }
              }
            //Revocation table add//  
        $revocation_order_arr=$request->revo_order_no;
        $revocation_order_date_arr = $request->revo_order_date;
        $ant_ord_no_arr = $request->ant_ord_no;
        $ant_ord_dat_arr = $request->ant_ord_dat; 
        $ant_ord_type_arr = $request->ant_ord_type;
        $ant_WEF_arr = $request->ant_WEF;
        $ant_WET_arr = $request->ant_WET;
        $revo_effected_date_arr = $request->revo_effected_date;
        $revo_remark_arr = $request->revo_remark;
        $revocation_sqlId_arr = $request->revocation_sql_id; 
        if(count($revocation_order_arr)>0)
        {
        foreach($revocation_order_arr as $ky=>$val)
        {
        if($revocation_order_arr[$ky]!="")
        {
        
        if( $revocation_sqlId_arr[$ky]=="")
        {
        
        $employee_revocation_details_fetch =array(
        'emp_no'=> $employee_id,
        'revocation_order_no'=> $revocation_order_arr[$ky],
        'revocation_order_date'=>$revocation_order_date_arr[$ky],
        'antecedent_order_no'=> $ant_ord_no_arr[$ky],
        'antecedent_order_date'=> $ant_ord_dat_arr[$ky],
        'antecedent_type'=> $ant_ord_type_arr[$ky],
        'antecedent_WEE_date'=> $ant_WEF_arr[$ky],
        'antecedent_WET_date'=> $ant_WET_arr[$ky],
        'revocation_effected_date'=> $revo_effected_date_arr[$ky],
        'remarks'=> $revo_remark_arr[$ky],
        'created_at'=>date('Y-m-d h:i:s'),
        'updated_at'=>date('Y-m-d h:i:s')
        );
        
        $update_Datarevocation=DB::table('emp_revocation_dtl')
        ->where('emp_no', $employee_id)
        ->insert( $employee_revocation_details_fetch);
        }
        else
        {
        
       $employee_revocation_details_fetch =array(
            'emp_no'=> $employee_id,
            'revocation_order_no'=> $revocation_order_arr[$ky],
            'revocation_order_date'=>$revocation_order_date_arr[$ky],
            'antecedent_order_no'=> $ant_ord_no_arr[$ky],
            'antecedent_order_date'=> $ant_ord_dat_arr[$ky],
            'antecedent_type'=> $ant_ord_type_arr[$ky],
            'antecedent_WEE_date'=> $ant_WEF_arr[$ky],
            'antecedent_WET_date'=> $ant_WET_arr[$ky],
            'revocation_effected_date'=> $revo_effected_date_arr[$ky],
            'remarks'=> $revo_remark_arr[$ky],
        );   
        $update_Datarevocation=DB::table('emp_revocation_dtl')
        ->where('emp_no', $employee_id)
        ->where('id',$revocation_sqlId_arr[$ky])
        ->update($employee_revocation_details_fetch);
        }
        }
        
        }
        }
          // contract upadated
          $contract_order_arr=$request->cont_order;
          $contract_start_date_arr = $request->cont_start_date;
          $contract_end_date_arr = $request->cont_end_date;
          $con_pay_arr = $request->con_pay;
          $special_arr = $request->special;
          $other_arr =$request->other;
          $remarks_cont_arr = $request->remarks;
          $sqli_cont_arr = $request->contract_sqli_id;
          $upload_cont=array();
          $upload_contract_index=array();
          if($files=$request->file('cont_file'))
          {
            $ctr_cont_img=1;
              foreach($files as $key => $file)
              {
                  $name=$file->getClientOriginalName();
                  $new_cont_filename =$employee_id.date('ymdhis').$ctr_cont_img.'.png';
                  $file->move(public_path().'/contract/', $new_cont_filename);  
                  $upload_cont[$key]=$new_cont_filename;
                  $upload_contract_index[]=$key;


                  $ctr_cont_img++;
              }
          }
          if(count($contract_order_arr)>0)
          {
              foreach($contract_order_arr as $ky=>$val)
              {
                  if($contract_order_arr[$ky]!="")
                  {
                    if($sqli_cont_arr[$ky]=="")
                    {
                      if (in_array($ky,$upload_contract_index))
                      {
                    $employee_contract_fetch =array(
                    'emp_no'=> $employee_id,
                    'cont_order_no'=> $contract_order_arr[$ky],
                    'cont_start_date'=>$contract_start_date_arr[$ky],
                    'cont_end_date'=> $contract_end_date_arr[$ky],
                    'consolidated_pay'=> $con_pay_arr[$ky],
                    'special_allowance'=> $special_arr[$ky],
                    'other_allowance'=> $other_arr[$ky],
                    'remarks'=>$remarks_cont_arr[$ky],
                    'upload'=> $upload_cont[$ky],
                    'created_at'=>date('Y-m-d h:i:s'),
                    'updated_at'=>date('Y-m-d h:i:s')
                    );
                  }
                  else{
                    $employee_contract_fetch =array(
                      'emp_no'=> $employee_id,
                      'cont_order_no'=> $contract_order_arr[$ky],
                      'cont_start_date'=>$contract_start_date_arr[$ky],
                      'cont_end_date'=> $contract_end_date_arr[$ky],
                      'consolidated_pay'=> $con_pay_arr[$ky],
                      'special_allowance'=> $special_arr[$ky],
                      'other_allowance'=> $other_arr[$ky],
                      'remarks'=>$remarks_cont_arr[$ky],
                       'created_at'=>date('Y-m-d h:i:s'),
                      'updated_at'=>date('Y-m-d h:i:s')
                      );
                  }
    
                    $update_contractdata=DB::table('emp_contract_dtl')
                    ->where('emp_no',$employee_id)
                    ->insert( $employee_contract_fetch);
                    }
                    else{
                      if (in_array($ky,$upload_contract_index))
                      {
                      $employee_contract_fetch =array(
                        // 'emp_no'=> $employee_id,
                        'cont_order_no'=> $contract_order_arr[$ky],
                        'cont_start_date'=>$contract_start_date_arr[$ky],
                        'cont_end_date'=> $contract_end_date_arr[$ky],
                        'consolidated_pay'=> $con_pay_arr[$ky],
                        'special_allowance'=> $special_arr[$ky],
                        'other_allowance'=> $other_arr[$ky],
                        'remarks'=>$remarks_cont_arr[$ky],
                        'upload'=> $upload_cont[$ky],
                      );
                      }
                      else
                      {
                      $employee_contract_fetch =array(
                        'cont_order_no'=> $contract_order_arr[$ky],
                        'cont_start_date'=>$contract_start_date_arr[$ky],
                        'cont_end_date'=> $contract_end_date_arr[$ky],
                        'consolidated_pay'=> $con_pay_arr[$ky],
                        'special_allowance'=> $special_arr[$ky],
                        'other_allowance'=> $other_arr[$ky],
                        'remarks'=>$remarks_cont_arr[$ky],
                        // 'upload'=> $upload_cont[$ky],
                      );
                      }
                      $update_contractdata=DB::table('emp_contract_dtl')
                      ->where('emp_no', $employee_id)
                      ->where('id',$sqli_cont_arr[$ky])
                      ->update($employee_contract_fetch);
                      }

                  }
                  

              }

          }
          //contract end
           //probation updated start
           $prob_order_arr=$request->prob_order;
           $prob_start_date_arr = $request->prob_start;
           $prob_end_date_arr = $request->prob_end;
           $pay_grade_arr = $request->pay_grade1;
           $initial_basic_arr = $request->initial;
           $special_allowance_arr =$request->special_allowance;
           $other_allownace_arr = $request->other_allownace;
           $remark_prob_arr =$request->remark_prob;
           $sqliprob_arr =$request->prob_sqli_id;
           $upload_prohabation_index=array();
           $upload_prob=array();
           if($files=$request->file('prob_upload'))
           {$ctr_prob_img=1;
               foreach($files as $key => $file)
               {
                   $name=$file->getClientOriginalName();
                   $new_prob_filename =$employee_id.date('ymdhis').$ctr_prob_img.'.png';
                   $file->move(public_path().'/probation/', $new_prob_filename);  
                   $upload_prob[$key]=$new_prob_filename;
                   $upload_prohabation_index[]=$key;
                   $ctr_prob_img++;
               }
           }
 
     
           if(count($prob_order_arr)>0)
           {
               foreach($prob_order_arr as $ky=>$val)
               {
                   if($prob_order_arr[$ky]!="")
                   {
                     if($sqliprob_arr[$ky]=="")
                     {
                      if (in_array($ky,$upload_prohabation_index))
                      {
                     $employee_probation_fetch =array(
                     'emp_no'=> $employee_id,
                     'prob_order_no'=> $prob_order_arr[$ky],
                     'prob_start_date'=>$prob_start_date_arr[$ky],
                     'prob_end_date'=> $prob_end_date_arr[$ky],
                     'pay_grade'=> $pay_grade_arr[$ky],
                     'intial_basic'=> $initial_basic_arr[$ky],
                     'special_allowance'=> $special_allowance_arr[$ky],
                     'other_allowance'=>$other_allownace_arr[$ky],
                     'remarks'=>$remark_prob_arr[$ky],
                     'upload'=> $upload_prob[$ky],
                     'created_at'=>date('Y-m-d h:i:s'),
                     'updated_at'=>date('Y-m-d h:i:s')
                     );
                    }else{
                      $employee_probation_fetch =array(
                        'emp_no'=> $employee_id,
                        'prob_order_no'=> $prob_order_arr[$ky],
                        'prob_start_date'=>$prob_start_date_arr[$ky],
                        'prob_end_date'=> $prob_end_date_arr[$ky],
                        'pay_grade'=> $pay_grade_arr[$ky],
                        'intial_basic'=> $initial_basic_arr[$ky],
                        'special_allowance'=> $special_allowance_arr[$ky],
                        'other_allowance'=>$other_allownace_arr[$ky],
                        'remarks'=>$remark_prob_arr[$ky],
                        
                        'created_at'=>date('Y-m-d h:i:s'),
                        'updated_at'=>date('Y-m-d h:i:s')
                        );

                    }
     
                     $update_probationdata=DB::table('emp_probation_dtl')
                     ->where('emp_no',$employee_id)
                     ->insert( $employee_probation_fetch);
                     }
                     else{
                       if (in_array($ky,$upload_prohabation_index))
                       {
                       $employee_probation_fetch =array(
                         'prob_order_no'=> $prob_order_arr[$ky],
                         'prob_start_date'=>$prob_start_date_arr[$ky],
                         'prob_end_date'=> $prob_end_date_arr[$ky],
                         'pay_grade'=> $pay_grade_arr[$ky],
                         'intial_basic'=> $initial_basic_arr[$ky],
                         'special_allowance'=> $special_allowance_arr[$ky],
                         'other_allowance'=>$other_allownace_arr[$ky],
                         'remarks'=>$remark_prob_arr[$ky],
                         'upload'=> $upload_prob[$ky],
                       );
                       }
                       else
                       {
                       $employee_probation_fetch =array(
                         'prob_order_no'=> $prob_order_arr[$ky],
                         'prob_start_date'=>$prob_start_date_arr[$ky],
                         'prob_end_date'=> $prob_end_date_arr[$ky],
                         'pay_grade'=> $pay_grade_arr[$ky],
                         'intial_basic'=> $initial_basic_arr[$ky],
                         'special_allowance'=> $special_allowance_arr[$ky],
                         'other_allowance'=>$other_allownace_arr[$ky],
                         'remarks'=>$remark_prob_arr[$ky],
                       );
                       }
                       $update_probationdata=DB::table('emp_probation_dtl')
                       ->where('emp_no', $employee_id)
                       ->where('id',$sqliprob_arr[$ky])
                       ->update($employee_probation_fetch);
                       }
 
                   }
                   
 
               }
 
           }
           //end probation

         return redirect('/employee_edit_master/?search_emp='.$employee_number);
      }     
       public function allEmployeDetails(Request $request)
        {
          $employee_number = $request->search_emp;
          $EmployeeModel = new Employee_Master();  
          $Department_fetch = Department_master::all();
          $Designation_fetch = Designation::all();
          $Workplace_fetch = Workplace::all();
          $Category_fetch = Category::all();
          $antecendent_fetch = Antecedent::all(); 
          $Employee_fetch1 = Employee_Master::Employee_Master_view();
          $pay_grade_view = Pay_grade_master::Pay_grade_Master_view();
          $qualification_view = Qualification::Qualification_view();

          $Employee_type_fetch =Employee_type::all();
          $Board_University_fetch =Board::all();
          $EmployeeAllInfo = $EmployeeModel->getAllEmployeeInfo($employee_number);

          $EmployeeOfficialInfo = $EmployeeModel->getAllEmployeeOfficialInfo($employee_number);
          $EmployeeNomineeInfo = $EmployeeModel->getAllNomineeInfo($employee_number);
          $EmployeeDependentInfo = $EmployeeModel->getDependentInfo($employee_number);
          $EmployeeExperienceInfo = $EmployeeModel->getExperienceInfo($employee_number);
          $EmployeeTransferInfo = $EmployeeModel->getTransferInfo($employee_number);
          $EmployeePromotionInfo = $EmployeeModel->getPromotionInfo($employee_number);
          $EmployeeProbationInfo = $EmployeeModel->getProbationInfo($employee_number);
          $EmployeeContractInfo = $EmployeeModel->getContractInfo($employee_number);
          $EmployeeAntecedentInfo = $EmployeeModel->getAntecedentInfo($employee_number);
          $EmployeeRevocationInfo = $EmployeeModel->getRevocationInfo($employee_number);
          $EmployeeQualificationInfo = $EmployeeModel->getAllQualificationInfo($employee_number);
            
        // echo"<pre>";print_r($EmployeeQualificationInfo );echo"</pre>";

          return view('Frontend.edit_profile',["EmployeeAllInfo"=>$EmployeeAllInfo,"EmployeeOfficialInfo"=>$EmployeeOfficialInfo,"EmployeeNomineeInfo"=>$EmployeeNomineeInfo,"Department_fetch"=>$Department_fetch,"Designation"=>$Designation_fetch,"Workplace_fetch" => $Workplace_fetch,"Category_fetch"=> $Category_fetch,"Employee_type_fetch"=>$Employee_type_fetch,'pay_grade_view' => $pay_grade_view,"Board_University_fetch"=>$Board_University_fetch,"EmployeeDependentInfo"=>$EmployeeDependentInfo,"EmployeeExperienceInfo"=>$EmployeeExperienceInfo,"EmployeeTransferInfo"=>$EmployeeTransferInfo,"EmployeePromotionInfo"=>$EmployeePromotionInfo,"EmployeeProbationInfo"=>$EmployeeProbationInfo,"EmployeeContractInfo"=>$EmployeeContractInfo,"EmployeeAntecedentInfo"=>$EmployeeAntecedentInfo,"EmployeeRevocationInfo"=>$EmployeeRevocationInfo,"antecendent_fetch"=>$antecendent_fetch,"Employee_fetch1"=>$Employee_fetch1,"EmployeeQualificationInfo"=>$EmployeeQualificationInfo,"qualification_view"=> $qualification_view]);
        }

       /**
       * Category Master page
      * */

       public function Category_Master_view(Request $request)
        {
        $Category_view = Category::category_view();
        return view('Frontend.category', ['Category_view' => $Category_view ]);
        }
        public function AddCategory(Request $request)
        {
          $Category = new Category();
          $category_name = $request->cat_name;
          $Category->category_name =  $category_name;
          $Category->save();
          return redirect('/category');
        }
        public function Update_Category_Data(Request $request)
        {
          $category_id = $request->cat_id;
          $category_name = $request->cat_name;

          $category_fetch =array(
                        'category_name' => $category_name,
                         );
 
          $update_Data=DB::table('category')
                       ->where('id',  $category_id)
                       ->update($category_fetch); 
                       return redirect('/category');
 
         }
       public function Delete_category_data($id)
       {
        $category_data_all = category::find($id);
        $category_data_all->delete();
        return redirect('/category');
       }
      /**
       * EmployeeType Master page
      * */
      public function EmployeeType_Master_view(Request $request)
      {
      $Employee_view = Employee_type::EmployeeType_Master_view();
   
      return view('Frontend.employee_type', ['Employee_view' => $Employee_view  ]);
      }
      public function AddEmployeeType(Request $request)
      {
        $employee_type = new Employee_type();
        $employee_type_name = $request->emp_name;
        $employee_type->employee_type_name =  $employee_type_name;
        $employee_type->save();
        return redirect('/employee_type');
      }
      public function Update_EmployeeType_Data(Request $request)
      {
        $employee_type_id = $request->emp_id;
        $employee_type_name = $request->emp_name;

        $employee_type_fetch =array(
                      'employee_type_name' => $employee_type_name,
                       );

        $update_Data=DB::table('employee_type')
                     ->where('id',  $employee_type_id)
                     ->update($employee_type_fetch); 
                     return redirect('/employee_type');

       }
     public function Delete_employee_type_data($id)
     {
      $employee_type_data_all = Employee_type::find($id);
      $employee_type_data_all->delete();
      return redirect('/employee_type');
     }

      public function EmployeeType_edit_Master_view(Request $request)
      {
     // $Employee_view = Employee_type::EmployeeType_Master_view();
   
      return view('Frontend.edit_profile');
      }

    
}
